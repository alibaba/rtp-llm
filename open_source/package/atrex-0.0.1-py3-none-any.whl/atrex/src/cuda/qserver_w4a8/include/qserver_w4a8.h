#pragma once

#include <torch/all.h>
#include <torch/extension.h>

void qserve_w4a8_per_group_gemm(
    const torch::Tensor& _in_feats,
    const torch::Tensor& _kernel,
    const torch::Tensor& _zeros,
    const torch::Tensor& _scales_i8,
    const torch::Tensor& _wscales,
    const torch::Tensor& _ascales,
    torch::Tensor& _out_feats,
    int block_m,
    int block_n,
    int block_k,
    int warp_m,
    int warp_n,
    int warp_k,
    int stages);