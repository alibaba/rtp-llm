#include "qserver_w4a8.h"

PYBIND11_MODULE(TORCH_EXTENSION_NAME, m) {
  m.def("qserve_w4a8_per_group_gemm", &qserve_w4a8_per_group_gemm,
        "qserve_w4a8_per_group_gemm", 
        py::arg("_in_feats"), 
        py::arg("_kernel"), 
        py::arg("_zeros"),
        py::arg("_scales_i8"), 
        py::arg("_wscales"), 
        py::arg("_ascales"),
        py::arg("_out_feats"),
        py::arg("block_m"), 
        py::arg("block_n"), 
        py::arg("block_k"), 
        py::arg("warp_m"), 
        py::arg("warp_n"), 
        py::arg("warp_k"), 
        py::arg("stages"));
}