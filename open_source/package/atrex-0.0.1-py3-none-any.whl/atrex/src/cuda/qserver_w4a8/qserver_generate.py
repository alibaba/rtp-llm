# SPDX-License-Identifier: MIT
# Copyright (c) 2018-2024, Advanced Micro Devices, Inc. All rights reserved.
# generate kernel instances to speed up compilation

import argparse
from enum import IntEnum
from pathlib import Path
import pkgutil
import sys
import os.path as path
from typing import List, Optional

QSERVER_W4A8_PER_GROUP_FILENAME = "qserver_w4a8_api.cu"

def update_file(file_path, content):
    """Update the file at file_path with the given content if it differs from the existing content.

    It avoids unnecessary touching of the file which triggers rebuilds
    """

    existing_content = ""
    if path.exists(file_path):
        with open(file_path, "r") as file:
            existing_content = file.read()
    if existing_content == content:
        return
    with open(file_path, "w") as file:
        file.write(content)


QSERVER_W4A8_PER_GROUP_KERNEL_BODY = """
    #include <ATen/cuda/CUDAContext.h>
    #include <cuda_fp16.h>
    #include <cuda_pipeline_primitives.h>
    #include <torch/all.h>

    #include "utils.h"
    #include "qserver_w4a8_per_group_gemm.cuh"
    void qserve_w4a8_per_group_gemm_core(
        const torch::Tensor& _in_feats,
        const torch::Tensor& _kernel,
        const torch::Tensor& _zeros,
        const torch::Tensor& _scales_i8,
        const torch::Tensor& _wscales,
        const torch::Tensor& _ascales,
        torch::Tensor& _out_feats
    ) {{
    // Check input tensor
    TORCH_CHECK(_in_feats.is_cuda(), "_in_feats must be a CUDA tensor");
    TORCH_CHECK(_in_feats.dim() == 2, "_in_feats must be a 2D tensor");
    TORCH_CHECK(_in_feats.is_contiguous(), "_in_feats must be contiguous");
    TORCH_CHECK(_in_feats.scalar_type() == torch::kInt8, "_in_feats must be int8");
    // Check kernel tensor
    TORCH_CHECK(_kernel.is_cuda(), "_kernel must be a CUDA tensor");
    TORCH_CHECK(_kernel.dim() == 2, "_kernel must be a 2D tensor");
    TORCH_CHECK(_kernel.is_contiguous(), "_kernel must be contiguous");
    TORCH_CHECK(_kernel.scalar_type() == torch::kInt8, "_kernel must be int8");
    // Check output tensor
    TORCH_CHECK(_out_feats.is_cuda(), "_out_feats must be a CUDA tensor");
    TORCH_CHECK(_out_feats.is_contiguous(), "_out_feats must be contiguous");
    TORCH_CHECK(_out_feats.scalar_type() == torch::kHalf, "_out_feats must be half");

    int num_in_feats = _in_feats.size(0);
    int num_in_channels = _in_feats.size(1);
    int num_out_feats = _out_feats.size(-2);
    int num_out_channels = _out_feats.size(-1);

    // Check matmul shape
    TORCH_CHECK(num_out_channels == _kernel.size(0), "num_out_channels must be equal to _kernel.size(0)");
    TORCH_CHECK(num_in_feats == num_out_feats, "num_in_feats must be equal to num_out_feats");

    // Check _ascales
    TORCH_CHECK(_ascales.is_cuda(), "_ascales must be a CUDA tensor");
    TORCH_CHECK(_ascales.is_contiguous(), "_ascales must be contiguous");
    TORCH_CHECK(_ascales.scalar_type() == torch::kHalf, "_ascales must be half");
    TORCH_CHECK(_ascales.numel() == num_in_feats, "_ascales must have num_in_feats elements");

    // Check _wscales
    TORCH_CHECK(_wscales.is_cuda(), "_wscales must be a CUDA tensor");
    TORCH_CHECK(_wscales.is_contiguous(), "_wscales must be contiguous");
    TORCH_CHECK(_wscales.scalar_type() == torch::kHalf, "_wscales must be half");
    TORCH_CHECK(_wscales.numel() == num_out_channels, "_wscales must have num_out_channels elements");

    // Check _scales_i8
    TORCH_CHECK(_scales_i8.is_cuda(), "_scales_i8 must be a CUDA tensor");
    TORCH_CHECK(_scales_i8.dim() == 2, "_scales_i8 must be a 2D tensor");
    TORCH_CHECK(_scales_i8.is_contiguous(), "_scales_i8 must be contiguous");
    TORCH_CHECK(_scales_i8.scalar_type() == torch::kInt8, "_scales_i8 must be int8");
    TORCH_CHECK(num_in_channels % _scales_i8.size(0) == 0, "num_in_channels must be divisible by _scales_i8.size(0)");
    TORCH_CHECK(num_out_channels == _scales_i8.size(1), "num_out_channels must be equal to _scales_i8.size(1)");

    // Check _zeros
    TORCH_CHECK(_zeros.is_cuda(), "_zeros must be a CUDA tensor");
    TORCH_CHECK(_zeros.dim() == 2, "_zeros must be a 2D tensor");
    TORCH_CHECK(_zeros.is_contiguous(), "_zeros must be contiguous");
    TORCH_CHECK(_zeros.scalar_type() == torch::kInt8, "_zeros must be int8");
    TORCH_CHECK(num_in_channels % _zeros.size(0) == 0, "num_in_channels must be divisible by _zeros.size(0)");
    TORCH_CHECK(num_out_channels == _zeros.size(1), "num_out_channels must be equal to _zeros.size(1)");

    // Check group size
    auto group_size = num_in_channels / _scales_i8.size(0);
    TORCH_CHECK(group_size == 128, "group_size must be 128");

    auto in_feats = reinterpret_cast<int8_t*>(_in_feats.data_ptr<int8_t>());
    auto kernel = reinterpret_cast<int8_t*>(_kernel.data_ptr<int8_t>());
    auto zeros = reinterpret_cast<int8_t*>(_zeros.data_ptr<int8_t>());
    auto scales_i8 = reinterpret_cast<int8_t*>(_scales_i8.data_ptr<int8_t>());
    auto wscales = reinterpret_cast<half2*>(_wscales.data_ptr());
    auto ascales = reinterpret_cast<half*>(_ascales.data_ptr());
    // auto options =
    //     torch::TensorOptions().dtype(torch::kHalf).device(_in_feats.device());
    auto out_feats = reinterpret_cast<half*>(_out_feats.data_ptr<at::Half>());
    auto stream = at::cuda::getCurrentCUDAStream(_in_feats.get_device());
    auto sm_version = getSMVersion();
    if (sm_version >= 80) {{
        constexpr int G = 128;
        {QSERVER_API_BODY}
    }} else {{
        TORCH_CHECK_NOT_IMPLEMENTED(
            false, "No implemented qserve_w4a8_per_group_gemm for current compute capability: ", sm_version);
    }}
    return;
    }}
"""

QSERVER_API_CORE = """
    constexpr int CTA_M = {CTA_M_VALUE};
    constexpr int CTA_N = {CTA_N_VALUE};
    constexpr int CTA_K = {CTA_K_VALUE};
    constexpr int WARP_M = {WARP_M_VALUE};
    constexpr int WARP_N = {WARP_N_VALUE};
    constexpr int WARP_K = {WARP_K_VALUE};
    constexpr int STAGES = {STAGES_VALUE};
    KERNEL_LAUNCH_CODE
"""




def write_blobs(
        output_dir,
        CTAM,
        CTAN,
        CTAK,
        WARPM,
        WARPN,
        WARPK,
        STAGES) -> None:
    api_core = QSERVER_API_CORE.format(
        CTA_M_VALUE=CTAM,
        CTA_N_VALUE=CTAN,
        CTA_K_VALUE=CTAK,
        WARP_M_VALUE=WARPM,
        WARP_N_VALUE=WARPN,
        WARP_K_VALUE=WARPK,
        STAGES_VALUE=STAGES
    )

    content = QSERVER_W4A8_PER_GROUP_KERNEL_BODY.format(
            QSERVER_API_BODY=api_core
        )
    
    if output_dir is None:
        output_dir = Path(__file__).parent
    else:
        output_dir = Path(output_dir)
    update_file(output_dir / QSERVER_W4A8_PER_GROUP_FILENAME, content)

if __name__ == "__main__":
    parser = argparse.ArgumentParser(
        prog="generate",
        description="gen API for qserver w4a8 kernel",
    )
    parser.add_argument(
        "-o",
        "--output_dir",
        required=False,
        help="write all the blobs into a directory"
    )
    parser.add_argument(
        "-bm",
        "--block_m",
        nargs='+',
        type=int,
        default=[64],
        required=False,
        help="M block size"
    )
    parser.add_argument(
        "-bn",
        "--block_n",
        nargs='+',
        type=int,
        default=[64],
        required=False,
        help="N block size"
    )
    parser.add_argument(
        "-bk",
        "--block_k",
        nargs='+',
        type=int,
        default=[64],
        required=False,
        help="M block size"
    )
    parser.add_argument(
        "-wm",
        "--warp_m",
        nargs='+',
        type=int,
        default=[32],
        required=False,
        help="M warp size"
    )
    parser.add_argument(
        "-wn",
        "--warp_n",
        nargs='+',
        type=int,
        default=[32],
        required=False,
        help="N warp size"
    )
    parser.add_argument(
        "-wk",
        "--warp_k",
        nargs='+',
        type=int,
        default=[64],
        required=False,
        help="K warp size"
    )
    parser.add_argument(
        "-s",
        "--stages",
        nargs='+',
        type=int,
        default=[3],
        required=False,
        help="number of stages"
    )

    args = parser.parse_args()

    write_blobs(
            args.output_dir, int(args.block_m[0]), int(args.block_n[0]), int(args.block_k[0]),
            int(args.warp_m[0]), int(args.warp_n[0]), int(args.warp_k[0]), int(args.stages[0])
        )