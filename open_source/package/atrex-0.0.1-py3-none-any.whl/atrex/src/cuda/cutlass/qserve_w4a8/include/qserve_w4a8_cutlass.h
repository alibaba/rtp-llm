#pragma once

#include <torch/all.h>
#include <torch/extension.h>

void qserve_w4a8_per_group_gemm_cutlass(
    const torch::Tensor& _in_feats,
    const torch::Tensor& _kernel,
    const torch::Tensor& _zeros,
    const torch::Tensor& _scales_i8,
    const torch::Tensor& _wscales,
    const torch::Tensor& _ascales,
    const torch::Tensor& _problem_sizes_device,
    const torch::Tensor& _alpha_ptr_array,
    const torch::Tensor& _lda,
    const torch::Tensor& _ldb,
    const torch::Tensor& _ldo,
    torch::Tensor& _out_feats,
    int problem_count
);

int64_t qserve_cutlass_get_workspace_size(
    int M,
    int N,
    int K,
    int split_k_factor,
    int block_m,
    int block_n,
    int block_k,
    int warp_m,
    int warp_n,
    int warp_k,
    int stages
);

int64_t qserve_w4a8_universal_get_workspace_size(
    int M,
    int N,
    int K,
    int split_k_factor,
    int thread_block_M,
    int thread_block_N,
    int thread_block_K
);

float qserve_w4a8_universal_gemm_cutlass(
    const torch::Tensor& _in_feats,
    const torch::Tensor& _kernel,
    const torch::Tensor& _zeros,
    const torch::Tensor& _scales_i8,
    const torch::Tensor& _wscales,
    const torch::Tensor& _ascales,
    torch::Tensor& _out_feats,
    const torch::Tensor& _workspace,
    int M,
    int N,
    int K,
    int split_k_factor,
    int block_m,
    int block_n,
    int block_k,
    int warp_m,
    int warp_n,
    int warp_k,
    int stages
);

float qserve_w4a8_universal_body(
    const torch::Tensor& _in_feats,
    const torch::Tensor& _kernel,
    const torch::Tensor& _zeros,
    const torch::Tensor& _scales_i8,
    const torch::Tensor& _wscales,
    const torch::Tensor& _ascales,
    torch::Tensor& _out_feats,
    const torch::Tensor& workspace,
    int split_k_factor,
    int thread_block_M,
    int thread_block_N,
    int thread_block_K,
    int warp_count_M,
    int warp_count_N,
    int warp_count_K,
    int kStages
);