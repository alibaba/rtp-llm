/***************************************************************************************************
 * Copyright (c) 2017 - 2025 NVIDIA CORPORATION & AFFILIATES. All rights reserved.
 * SPDX-License-Identifier: BSD-3-Clause
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 *
 * 1. Redistributions of source code must retain the above copyright notice, this
 * list of conditions and the following disclaimer.
 *
 * 2. Redistributions in binary form must reproduce the above copyright notice,
 * this list of conditions and the following disclaimer in the documentation
 * and/or other materials provided with the distribution.
 *
 * 3. Neither the name of the copyright holder nor the names of its
 * contributors may be used to endorse or promote products derived from
 * this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 * DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE
 * FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
 * DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
 * CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 * OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
 * OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 *
 **************************************************************************************************/
/*! \file
    \brief Template for a pipelined GEMM kernel. Does not compute batching or support split-K.
*/

#pragma once

#include "cutlass/cutlass.h"
#include "cutlass/numeric_types.h"
#include "cutlass/arch/arch.h"
#include "cutlass/arch/wmma.h"

#include "cutlass/layout/matrix.h"
#include "cutlass/layout/permute.h"
#include "cutlass/transform/threadblock/predicated_tile_iterator.h"
#include "cutlass/transform/threadblock/predicated_tile_iterator_2dthreadtile.h"
#include "cutlass/transform/threadblock/predicated_scale_bias_vector_access_iterator.h"
#include "cutlass/transform/threadblock/regular_scale_bias_vector_access_iterator.h"
#include "cutlass/transform/threadblock/predicated_scale_bias_vector_iterator.h"
#include "cutlass/transform/threadblock/regular_tile_iterator_pitch_linear.h"

#include "cutlass/gemm/gemm.h"
// #include "cutlass/gemm/threadblock/default_mma_core_sm80.h"
#include "default_mma_core_w4a8.h"
#include "mma_multistage_w4a8.h"
#include "config.h"

////////////////////////////////////////////////////////////////////////////////

namespace cutlass {
namespace gemm {
namespace threadblock {

////////////////////////////////////////////////////////////////////////////////

template <
    /// Element type for A matrix operand
    typename ElementA_,
    /// Layout type for A matrix operand
    typename LayoutA_,
    /// Access granularity of A matrix in units of elements
    int kAlignmentA,
    /// Element type for B matrix operand
    typename ElementB_,
    /// Layout type for B matrix operand
    typename LayoutB_,
    /// Access granularity of B matrix in units of elements
    int kAlignmentB,
    /// Element type for internal accumulation
    typename ElementAccumulator_,
    /// Layout type for C and D matrix operands
    typename LayoutC_,
    /// Operator class tag
    typename OperatorClass_,
    /// Tag indicating architecture to tune for
    typename ArchTag_,
    /// Threadblock-level tile size (concept: GemmShape)
    typename ThreadblockShape_,
    /// Warp-level tile size (concept: GemmShape)
    typename WarpShape_,
    /// Instruction-level tile size (concept: GemmShape)
    typename InstructionShape_,
    /// Number of stages used in the pipelined mainloop
    int Stages,
    /// Operation performed by GEMM
    typename Operator,
    /// Store the accumulators in row major or column major.  Row major is used
    /// when output layout is interleaved.
    bool AccumulatorsInRowMajor = false,
    /// Use zfill or predicate for out-of-bound cp.async
    SharedMemoryClearOption SharedMemoryClear = SharedMemoryClearOption::kNone,
    /// Gather operand A by using an index array
    bool GatherA = false,
    /// Gather operand B by using an index array
    bool GatherB = false,
    /// Permute operand A
    typename PermuteALayout = layout::NoPermute,
    /// Permute operand B
    typename PermuteBLayout = layout::NoPermute
    >
struct DefaultMmaW4A8;

////////////////////////////////////////////////////////////////////////////////

/// Specialization for row-major output (OperatorClass TensorOp)
template <
    /// Element type for A matrix operand
    typename ElementA,
    /// Layout type for A matrix operand
    typename LayoutA,
    /// Access granularity of A matrix in units of elements
    int kAlignmentA,
    /// Element type for B matrix operand
    typename ElementB,
    /// Layout type for B matrix operand
    typename LayoutB,
    /// Access granularity of B matrix in units of elements
    int kAlignmentB,
    /// Element type for internal accumulation
    typename ElementAccumulator,
    /// Layout type for C and D matrix operand
    typename LayoutC,
    /// Tag indicating architecture to tune for
    typename ArchTag,
    /// Threadblock-level tile size (concept: GemmShape)
    typename ThreadblockShape,
    /// Warp-level tile size (concept: GemmShape)
    typename WarpShape,
    /// Instruction-level tile size (concept: GemmShape)
    typename InstructionShape,
    /// Number of stages used in the multistage mainloop
    int Stages,
    /// Operation performed by GEMM
    typename Operator,
    /// Use zfill or predicate for out-of-bound cp.async
    SharedMemoryClearOption SharedMemoryClear,
    /// Gather operand A by using an index array
    bool GatherA,
    /// Gather operand B by using an index array
    bool GatherB,
    /// Permute operand A
    typename PermuteALayout,
    /// Permute operand B
    typename PermuteBLayout
    >
struct DefaultMmaW4A8<ElementA, LayoutA, kAlignmentA, ElementB, LayoutB,
                  kAlignmentB, ElementAccumulator, LayoutC,
                  arch::OpClassTensorOp, ArchTag, ThreadblockShape, WarpShape,
                  InstructionShape, Stages, Operator, false, SharedMemoryClear,
                  GatherA, GatherB, PermuteALayout, PermuteBLayout> {

  static_assert(platform::is_same<LayoutC, layout::RowMajor>::value
             || platform::is_same<LayoutC, layout::AffineRankN<2>>::value,
             "simt epilogue must be row major");

  static cutlass::arch::CacheOperation::Kind const CacheOpA =
      ((sizeof_bits<ElementA>::value * kAlignmentA) == 128)
          ? cutlass::arch::CacheOperation::Global
          : cutlass::arch::CacheOperation::Always;

  static cutlass::arch::CacheOperation::Kind const CacheOpB =
      ((sizeof_bits<ElementB>::value * kAlignmentB) == 128)
          ? cutlass::arch::CacheOperation::Global
          : cutlass::arch::CacheOperation::Always;

  // Define the MmaCore components
  using MmaCore = typename cutlass::gemm::threadblock::DefaultMmaCoreW4A8<
      ThreadblockShape, WarpShape, InstructionShape, ElementA, LayoutA,
      ElementB, LayoutB, ElementAccumulator, LayoutC, arch::OpClassTensorOp,
      Stages, Operator, false, CacheOpA, CacheOpB>;

  // Define iterators over tiles from the A operand
  using ThreadMapA = typename MmaCore::IteratorThreadMapA;
  using AccessTypeA = cutlass::Array<ElementA, kAlignmentA>;
  using IteratorA =
      cutlass::transform::threadblock::PredicatedTileAccessIterator<
          cutlass::MatrixShape<ThreadblockShape::kM, ThreadblockShape::kK>,
          ElementA, LayoutA, 1, ThreadMapA, AccessTypeA, GatherA, PermuteALayout>;

  // Define iterators over tiles from the B operand
  using ThreadMapB = typename MmaCore::IteratorThreadMapB;
  using AccessTypeB = cutlass::Array<ElementB, kAlignmentB>;
  using IteratorB =
      cutlass::transform::threadblock::PredicatedTileAccessIterator<
          cutlass::MatrixShape<ThreadblockShape::kK, ThreadblockShape::kN/2>,
          ElementB, LayoutB, 0, ThreadMapB, AccessTypeB, GatherB, PermuteBLayout>;

//   using IteratorScale =
//       cutlass::transform::threadblock::PredicatedScaleBiasVectorIterator<
//           cutlass::MatrixShape<ThreadblockShape::kN*2, (ThreadblockShape::kK + 127) / 128>, ElementA,
//           LayoutA>;
#ifndef ENABLE_ASYNC_COPY
  static constexpr int kInstructionWarpThreadK = 4;
  static constexpr int kInstructionWarpThreadN = 32 / kInstructionWarpThreadK;
  static constexpr int ScaleElementsPerAccess =
      WarpShape::kN / kInstructionWarpThreadN;

  static_assert(ThreadblockShape::kK <= 128,
                "ThreadblockShape::kK must be <= 128.");
  static constexpr int kNumScaleNPerIteration = ThreadblockShape::kN;
  static constexpr int kNumScaleKPerIteration =
      (ThreadblockShape::kK + 127) / 128;
  static constexpr int kNumThreads =
      kNumScaleNPerIteration / ScaleElementsPerAccess;

  using ThreadMapScale = transform::PitchLinearWarpRakedThreadMap<
      layout::PitchLinearShape<kNumScaleNPerIteration /*CTA_N*/,
                               kNumScaleKPerIteration /*1*/>,
      kNumThreads,
      layout::PitchLinearShape<kNumThreads, kNumScaleKPerIteration /*1*/>,
      ScaleElementsPerAccess>;

  using IteratorScale = cutlass::transform::threadblock::PredicatedTileIterator<
          cutlass::MatrixShape<(ThreadblockShape::kK + 127) / 128, ThreadblockShape::kN>,
          ElementA, LayoutA, 0, ThreadMapScale, ScaleElementsPerAccess, false, layout::NoPermute>;
#else
  static constexpr int GroupSize = 128;
  static constexpr int NumKGroups = (ThreadblockShape::kK + 127) / GroupSize;
  static_assert(NumKGroups == 1, "NumKGroups must be 1");

  // Define a global/shared iterator and their thread map.
  static constexpr int ElementsPerAccessG2S =
      128 / cutlass::sizeof_bits<ElementA>::value;
  static constexpr int NumThreadsG2S =
      ThreadblockShape::kN / ElementsPerAccessG2S;
  static_assert(NumThreadsG2S > 1, "NumThreadsG2S must be > 1");

  using ThreadMapScaleG2S = cutlass::transform::PitchLinearWarpRakedThreadMap<
      cutlass::layout::PitchLinearShape<ThreadblockShape::kN, /*Contiguous*/
                                        NumKGroups /*Strided*/>,
      NumThreadsG2S,
      cutlass::layout::PitchLinearShape<NumThreadsG2S, NumKGroups>,
      ElementsPerAccessG2S>;

  using GmemIteratorScale =
      cutlass::transform::threadblock::PredicatedTileAccessIterator<
          cutlass::MatrixShape<NumKGroups /*row*/,
                               ThreadblockShape::kN /*col*/>,
          ElementA, LayoutA, 0 /*AdvanceRank*/, ThreadMapScaleG2S,
          cutlass::Array<ElementA, ElementsPerAccessG2S>>;
  static_assert(GmemIteratorScale::ThreadMap::Iterations::kCount == 1,
                "GmemIteratorScale::ThreadMap::Iterations::kCount must be 1");
  static_assert(GmemIteratorScale::kAccessesPerVector == 1,
                "GmemIteratorScale::kAccessesPerVector must be 1");

  static constexpr int CrosswiseBytes = 128;
  static_assert(cutlass::sizeof_bits<ElementA>::value / 8 *
                        ThreadblockShape::kN <=
                    CrosswiseBytes,
                "CTA_N * sizeof(T) width must be <= 128B");

  using SmemIteratorScale =
      cutlass::transform::threadblock::RegularTileAccessIterator<
          cutlass::MatrixShape<NumKGroups /*row*/,
                               ThreadblockShape::kN /*col*/>,
          ElementA,
          cutlass::layout::RowMajorTensorOpMultiplicandCongruous<
              cutlass::sizeof_bits<ElementA>::value,
              CrosswiseBytes * 8 /*bits*/ /
                  cutlass::sizeof_bits<ElementA>::value>,
          0 /*AdvanceRank*/, ThreadMapScaleG2S>;

  // Define a register iterator and thread map.
  // NOTE: threads on the reduction axis load the same scale
  static constexpr int NumThreadsS2R =
      8; /* threads along the MMA spatial axis */
  static constexpr int ElementsPerAccessS2R =
      WarpShape::kN /
      NumThreadsS2R; /* scale needs to be preshuffled by WARP_N*/

  // NOTE: only the intra-warp column layout matters
  // row and inter-warp offsets are handled in init
  using ThreadMapS2R = cutlass::transform::PitchLinearWarpRakedThreadMap<
      cutlass::layout::PitchLinearShape<WarpShape::kN, NumKGroups>,
      NumThreadsS2R,
      cutlass::layout::PitchLinearShape<NumThreadsS2R, NumKGroups>,
      ElementsPerAccessS2R>;

  using RegisterIteratorScale =
      cutlass::transform::threadblock::RegularTileIterator<
          cutlass::MatrixShape<NumKGroups, WarpShape::kN>, ElementA, LayoutA,
          0 /*AdvanceRank*/, ThreadMapS2R>;
#endif

  // Define the threadblock-scoped multistage matrix multiply
  using ThreadblockMma = cutlass::gemm::threadblock::MmaMultistageW4A8<
      typename MmaCore::Shape, IteratorA, typename MmaCore::SmemIteratorA,
      MmaCore::kCacheOpA, IteratorB, typename MmaCore::SmemIteratorB,
      MmaCore::kCacheOpB, ElementAccumulator, LayoutC,
      typename MmaCore::MmaPolicy, Stages,
#ifndef ENABLE_ASYNC_COPY
      IteratorScale,
#else
      GmemIteratorScale, SmemIteratorScale, RegisterIteratorScale,
#endif
      SharedMemoryClear>;
};

////////////////////////////////////////////////////////////////////////////////

/*
/// Specialization for column-major-interleaved output
template <
    /// Element type for A matrix operand
    typename ElementA,
    /// Layout type for A matrix operand
    typename LayoutA,
    /// Access granularity of A matrix in units of elements
    int kAlignmentA,
    /// Element type for B matrix operand
    typename ElementB,
    /// Layout type for B matrix operand
    typename LayoutB,
    /// Access granularity of B matrix in units of elements
    int kAlignmentB,
    /// Element type for internal accumulation
    typename ElementAccumulator,
    /// Tag indicating architecture to tune for
    typename OperatorClass,
    /// Tag indicating architecture to tune for
    typename ArchTag,
    /// Threadblock-level tile size (concept: GemmShape)
    typename ThreadblockShape,
    /// Warp-level tile size (concept: GemmShape)
    typename WarpShape,
    /// Instruction-level tile size (concept: GemmShape)
    typename InstructionShape,
    /// Number of stages used in the multistage mainloop
    int Stages,
    /// Operation performed by GEMM
    typename Operator,
    /// Number of Interleaved K
    int InterleavedK>
struct DefaultMmaW4A8<ElementA, LayoutA, kAlignmentA, ElementB, LayoutB,
                  kAlignmentB, ElementAccumulator,
                  layout::ColumnMajorInterleaved<InterleavedK>, OperatorClass,
                  ArchTag, ThreadblockShape, WarpShape, InstructionShape,
                  Stages, Operator, true, SharedMemoryClearOption::kNone, 
                  false, false, layout::NoPermute, layout::NoPermute> {
  // Define the MmaCore components
  using MmaCore = typename cutlass::gemm::threadblock::DefaultMmaCoreW4A8<
      ThreadblockShape, WarpShape, InstructionShape, ElementA, LayoutA,
      ElementB, LayoutB, ElementAccumulator,
      layout::ColumnMajorInterleaved<InterleavedK>, OperatorClass, Stages,
      Operator, true>;

  // Define iterators over tiles from the A operand
  using ThreadMapA = typename MmaCore::IteratorThreadMapA;
  using AccessTypeA = cutlass::Array<ElementA, kAlignmentA>;
  using IteratorA =
      cutlass::transform::threadblock::PredicatedTileAccessIterator<
          cutlass::MatrixShape<ThreadblockShape::kM, ThreadblockShape::kK>,
          ElementA, LayoutA, 1, ThreadMapA, AccessTypeA>;

  // Define iterators over tiles from the B operand
  using ThreadMapB = typename MmaCore::IteratorThreadMapB;
  using AccessTypeB = cutlass::Array<ElementB, kAlignmentB>;
  using IteratorB =
      cutlass::transform::threadblock::PredicatedTileAccessIterator<
          cutlass::MatrixShape<ThreadblockShape::kK, ThreadblockShape::kN>,
          ElementB, LayoutB, 0, ThreadMapB, AccessTypeB>;

  // Define the threadblock-scoped multistage matrix multiply
  using ThreadblockMma = cutlass::gemm::threadblock::MmaMultistageW4A8<
      typename MmaCore::Shape, IteratorA, typename MmaCore::SmemIteratorA,
      MmaCore::kCacheOpA, IteratorB, typename MmaCore::SmemIteratorB,
      MmaCore::kCacheOpB, ElementAccumulator, layout::RowMajor,
      typename MmaCore::MmaPolicy, Stages>;
};
*/
} // namespace threadblock
} // namespace gemm
} // namespace cutlass 

////////////////////////////////////////////////////////////////////////////////
