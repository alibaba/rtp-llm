#include <ATen/cuda/CUDAContext.h>
#include <cuda_fp16.h>
#include <cuda_pipeline_primitives.h>
#include <torch/all.h>

#include "cutlass/cutlass.h"
#include "cutlass/gemm/gemm.h"
#include "cutlass/gemm/kernel/gemm_grouped_per_group_scale.h"
#include "kernel/default_w4a8_per_group_gemm.h"
#include "cutlass/gemm/device/gemm_grouped.h"
#include "cutlass/gemm/device/gemm_universal.h"

#include "cutlass/util/device_memory.h"

#include "qserve_w4a8_cutlass.h"

void qserve_w4a8_per_group_gemm_cutlass(
    const torch::Tensor& _in_feats,
    const torch::Tensor& _kernel,
    const torch::Tensor& _zeros,
    const torch::Tensor& _scales_i8,
    const torch::Tensor& _wscales,
    const torch::Tensor& _ascales,
    const torch::Tensor& _problem_sizes_device,
    const torch::Tensor& _alpha_ptr_array,
    const torch::Tensor& _lda,
    const torch::Tensor& _ldb,
    const torch::Tensor& _ldo,
    torch::Tensor& _out_feats,
    int problem_count
) {
    using ElementA = int8_t;
    using ElementB = int8_t;//cutlass::int4b_t;
    using ElementOutput = float;
    using ElementAccumulator = int32_t;

    using Opeartor = cutlass::arch::OpMultiplyAddSaturate;//MixedInputUpcast;

    using LayoutA = cutlass::layout::RowMajor;
    using LayoutB = cutlass::layout::ColumnMajor;
    using LayoutC = cutlass::layout::RowMajor;

    constexpr int ElementsPerAccessA = 128 / cutlass::sizeof_bits<ElementA>::value;
    constexpr int ElementsPerAccessB = 128 / cutlass::sizeof_bits<ElementB>::value;

    // Define a grouped GEMM kernel with all template parameters set except
    // for scheduling mode. This will be used as the template for all scheduling
    // modes executed.
    using GemmKernel = typename cutlass::gemm::kernel::DefaultGemmGroupedW4A8PerGroupScale<
        ElementA,
        LayoutA,
        cutlass::ComplexTransform::kNone,
        ElementsPerAccessA,
        ElementB,
        LayoutB,
        cutlass::ComplexTransform::kNone,
        ElementsPerAccessB,
        ElementOutput, LayoutC,
        ElementAccumulator,
        cutlass::arch::OpClassTensorOp,
        cutlass::arch::Sm80,
        cutlass::gemm::GemmShape<32, 32, 128>,
        cutlass::gemm::GemmShape<32, 16, 64>,
        cutlass::gemm::GemmShape<16, 8, 32>,
        cutlass::epilogue::thread::LinearCombination<
            ElementOutput, 64 / cutlass::sizeof_bits<ElementOutput>::value,
            ElementAccumulator, ElementOutput>,
        // NOTE: Threadblock swizzling is currently not supported by CUTLASS's grouped kernels.
        // This parameter is passed in at present to match the APIs of other kernels. The parameter
        // is unused within the kernel.
        cutlass::gemm::threadblock::GemmBatchedIdentityThreadblockSwizzle,
        2,
        cutlass::gemm::kernel::GroupScheduleMode::kDeviceOnly,
        Opeartor>::GemmKernel;

    using Gemm = cutlass::gemm::device::GemmGrouped<GemmKernel>;

    std::vector<cutlass::gemm::GemmCoord> problem_sizes;
    int m = _in_feats.size(0);
    int n = _out_feats.size(1);
    int k = _in_feats.size(1);
    cutlass::gemm::GemmCoord problem(m, n, k);
    problem_sizes.push_back(problem);

    int threadblock_count = Gemm::sufficient(problem_sizes.data(), problem_count);

    // Early exit
    if (!threadblock_count) {
        std::cout << "Active CUDA device lacks hardware resources to run ATREK Grouped GEMM kernel." << std::endl;
        return ;
    }

    // auto alpha_ptr = _alpha_ptr_array.data_ptr<typename Gemm::EpilogueOutputOp::ElementCompute>();
    // typename Gemm::EpilogueOutputOp::ElementCompute** _alpha_ptr_array_device = &alpha_ptr;

    std::vector<float *> alpha_ptr_array_device;
    alpha_ptr_array_device.push_back(_alpha_ptr_array.data_ptr<float>());
    cutlass::DeviceAllocation<float *> alpha_ptr_array_device_alloc;
    alpha_ptr_array_device_alloc.reset(problem_count);
    alpha_ptr_array_device_alloc.copy_from_host(alpha_ptr_array_device.data());

    // Configure the GEMM arguments
    typename Gemm::EpilogueOutputOp::Params epilogue_op(alpha_ptr_array_device_alloc.get(), nullptr);

    cutlass::DeviceAllocation<cutlass::gemm::GemmCoord> problem_sizes_device;
    problem_sizes_device.reset(problem_count);
    problem_sizes_device.copy_from_host(problem_sizes.data());

    std::vector<ElementA *> _in_feat_ptr_array;
    _in_feat_ptr_array.push_back(_in_feats.data_ptr<ElementA>());
    cutlass::DeviceAllocation<ElementA *> _in_feat_ptr_array_alloc;
    _in_feat_ptr_array_alloc.reset(problem_count);
    _in_feat_ptr_array_alloc.copy_from_host(_in_feat_ptr_array.data());
    ElementA **in_feat_ptr_array = _in_feat_ptr_array_alloc.get();

    auto kernel_ptr = _kernel.data_ptr<ElementB>();
    std::vector<ElementB *> _kernel_ptr_array;
    _kernel_ptr_array.push_back(kernel_ptr);
    cutlass::DeviceAllocation<ElementB *> _kernel_ptr_array_alloc;
    _kernel_ptr_array_alloc.reset(problem_count);
    _kernel_ptr_array_alloc.copy_from_host(_kernel_ptr_array.data());
    ElementB **kernel_ptr_array = _kernel_ptr_array_alloc.get();
    
    auto out_feat_ptr = _out_feats.data_ptr<ElementOutput>();
    std::vector<ElementOutput *> _out_feat_ptr_array;
    _out_feat_ptr_array.push_back(out_feat_ptr);
    cutlass::DeviceAllocation<ElementOutput *> _out_feat_ptr_array_alloc;
    _out_feat_ptr_array_alloc.reset(problem_count);
    _out_feat_ptr_array_alloc.copy_from_host(_out_feat_ptr_array.data());
    ElementOutput **out_feat_ptr_array = _out_feat_ptr_array_alloc.get();
    
    auto zeros_ptr = _zeros.data_ptr<ElementA>();
    std::vector<ElementA *> _zeros_ptr_array;
    _zeros_ptr_array.push_back(zeros_ptr);
    cutlass::DeviceAllocation<ElementA *> _zeros_ptr_array_alloc;
    _zeros_ptr_array_alloc.reset(problem_count);
    _zeros_ptr_array_alloc.copy_from_host(_zeros_ptr_array.data());
    ElementA **zeros_ptr_array = _zeros_ptr_array_alloc.get();
    
    auto scales_i8_ptr = _scales_i8.data_ptr<ElementA>();
    std::vector<ElementA *> _scales_i8_ptr_array;
    _scales_i8_ptr_array.push_back(scales_i8_ptr);
    cutlass::DeviceAllocation<ElementA *> _scales_i8_ptr_array_alloc;
    _scales_i8_ptr_array_alloc.reset(problem_count);
    _scales_i8_ptr_array_alloc.copy_from_host(_scales_i8_ptr_array.data());
    ElementA **scales_i8_ptr_array = _scales_i8_ptr_array_alloc.get();
    
    auto wscales_ptr = _wscales.data_ptr<ElementA>();
    std::vector<ElementA *> _wscales_ptr_array;
    _wscales_ptr_array.push_back(wscales_ptr);
    cutlass::DeviceAllocation<ElementA *> _wscales_ptr_array_alloc;
    _wscales_ptr_array_alloc.reset(problem_count);
    _wscales_ptr_array_alloc.copy_from_host(_wscales_ptr_array.data());
    ElementA **wscales_ptr_array = _wscales_ptr_array_alloc.get();
    
    auto ascales_ptr = _ascales.data_ptr<ElementA>();
    std::vector<ElementA *> _ascales_ptr_array;
    _ascales_ptr_array.push_back(ascales_ptr);
    cutlass::DeviceAllocation<ElementA *> _ascales_ptr_array_alloc;
    _ascales_ptr_array_alloc.reset(problem_count);
    _ascales_ptr_array_alloc.copy_from_host(_ascales_ptr_array.data());
    ElementA **ascales_ptr_array = _ascales_ptr_array_alloc.get();
    auto lda_ptr = _lda.data_ptr<typename LayoutA::Stride::LongIndex>();
    // typename LayoutA::Stride::LongIndex **lda_ptr_array = &lda_ptr;
    auto ldb_ptr = _ldb.data_ptr<typename LayoutB::Stride::LongIndex>();
    // typename LayoutB::Stride::LongIndex **ldb_ptr_array = &ldb_ptr;
    auto ldo_ptr = _ldo.data_ptr<typename LayoutB::Stride::LongIndex>();
    // typename LayoutC::Stride::LongIndex **ldo_ptr_array = &ldo_ptr;
    // Configure GEMM arguments
    typename Gemm::Arguments args(
      problem_sizes_device.get(),
      problem_count,
      threadblock_count,
      epilogue_op,
      in_feat_ptr_array,
      kernel_ptr_array,
      out_feat_ptr_array,
      out_feat_ptr_array,
      lda_ptr,
      ldb_ptr,
      ldo_ptr,
      ldo_ptr,
      scales_i8_ptr_array,
      zeros_ptr_array,
      wscales_ptr_array,
      ascales_ptr_array,
      problem_sizes.data()
    );

    // Initialize the GEMM object
    Gemm gemm;

    cutlass::Status status;

    size_t workspace_size = gemm.get_workspace_size(args);
    cutlass::DeviceAllocation<uint8_t> workspace(workspace_size);

    status = gemm.initialize(args, workspace.get());

    if (status != cutlass::Status::kSuccess) {
      std::cerr << "Failed to initialize ATREK W4A8 Grouped GEMM kernel." << std::endl;
      return ;
    }

    // Run the grouped GEMM object
    status = gemm.run();

    if (status != cutlass::Status::kSuccess) {
      std::cerr << "Failed to run ATREK W4A8 Grouped GEMM kernel." << std::endl;
      return ;
    }

    cudaError_t error = cudaDeviceSynchronize();
    if (error != cudaSuccess) {
      std::cerr << "Failed to synchronize CUDA device." << cudaGetErrorString(error);
      return ;
    }

    alpha_ptr_array_device_alloc.release();
    problem_sizes_device.release();
    _in_feat_ptr_array_alloc.release();
    _kernel_ptr_array_alloc.release();
    _out_feat_ptr_array_alloc.release();
    _zeros_ptr_array_alloc.release();
    _scales_i8_ptr_array_alloc.release();
    _wscales_ptr_array_alloc.release();
    _ascales_ptr_array_alloc.release();
    workspace.release();
}