#include "qserve_w4a8_cutlass.h"

PYBIND11_MODULE(TORCH_EXTENSION_NAME, m) {
  m.def("qserve_cutlass_get_workspace_size", &qserve_cutlass_get_workspace_size,
        "qserve_cutlass_get_workspace_size", 
        py::arg("M"),
        py::arg("N"),
        py::arg("K"),
        py::arg("split_k_factor") = 1,
        py::arg("block_m") = 32, 
        py::arg("block_n") = 32, 
        py::arg("block_k") = 128,
        py::arg("warp_m") = 32, 
        py::arg("warp_n") = 16, 
        py::arg("warp_k") = 128, 
        py::arg("stages") = 2);

  m.def("qserve_w4a8_universal_gemm_cutlass", &qserve_w4a8_universal_gemm_cutlass,
        "qserve_w4a8_universal_gemm_cutlass", 
        py::arg("_in_feats"), 
        py::arg("_kernel"), 
        py::arg("_zeros"),
        py::arg("_scales_i8"), 
        py::arg("_wscales"), 
        py::arg("_ascales"),
        py::arg("_out_feats"),
        py::arg("workspace"),
        py::arg("M"),
        py::arg("N"),
        py::arg("K"),
        py::arg("split_k_factor") = 1,
        py::arg("block_m") = 32, 
        py::arg("block_n") = 32, 
        py::arg("block_k") = 128, 
        py::arg("warp_m") = 32, 
        py::arg("warp_n") = 16, 
        py::arg("warp_k") = 128, 
        py::arg("stages") = 2);
}