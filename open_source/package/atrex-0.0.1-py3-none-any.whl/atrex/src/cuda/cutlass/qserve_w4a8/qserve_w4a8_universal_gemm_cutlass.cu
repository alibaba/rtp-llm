#include <ATen/cuda/CUDAContext.h>
#include <cuda_fp16.h>
#include <cuda_pipeline_primitives.h>
#include <torch/all.h>

#include "qserve_w4a8_cutlass.h"

int64_t qserve_cutlass_get_workspace_size(
    int M,
    int N,
    int K,
    int split_k_factor,
    int block_m,
    int block_n,
    int block_k,
    int warp_m,
    int warp_n,
    int warp_k,
    int stages
) { 
    return qserve_w4a8_universal_get_workspace_size(
        M,
        N,
        K,
        split_k_factor,
        block_m,
        block_n,
        block_k
    );
}

float qserve_w4a8_universal_gemm_cutlass(
    const torch::Tensor& _in_feats,
    const torch::Tensor& _kernel,
    const torch::Tensor& _zeros,
    const torch::Tensor& _scales_i8,
    const torch::Tensor& _wscales,
    const torch::Tensor& _ascales,
    torch::Tensor& _out_feats,
    const torch::Tensor& _workspace,
    int M,
    int N,
    int K,
    int split_k_factor,
    int block_m,
    int block_n,
    int block_k,
    int warp_m,
    int warp_n,
    int warp_k,
    int stages
) {
    return qserve_w4a8_universal_body(
        _in_feats,
        _kernel,
        _zeros,
        _scales_i8,
        _wscales,
        _ascales,
        _out_feats,
        _workspace,
        split_k_factor,
        block_m,
        block_n,
        block_k,
        warp_m,
        warp_n,
        warp_k,
        stages
    );
}