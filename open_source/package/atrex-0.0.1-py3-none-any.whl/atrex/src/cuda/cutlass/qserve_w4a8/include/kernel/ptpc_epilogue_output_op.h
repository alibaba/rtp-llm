/***************************************************************************************************
 * Copyright (c) 2017 - 2025 NVIDIA CORPORATION & AFFILIATES. All rights reserved.
 * SPDX-License-Identifier: BSD-3-Clause
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 *
 * 1. Redistributions of source code must retain the above copyright notice, this
 * list of conditions and the following disclaimer.
 *
 * 2. Redistributions in binary form must reproduce the above copyright notice,
 * this list of conditions and the following disclaimer in the documentation
 * and/or other materials provided with the distribution.
 *
 * 3. Neither the name of the copyright holder nor the names of its
 * contributors may be used to endorse or promote products derived from
 * this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 * DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE
 * FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
 * DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
 * CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 * OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
 * OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 *
 **************************************************************************************************/
/*! \file
  \brief Functor performing linear combination operations used by epilogues.
*/

#pragma once

#include "cutlass/cutlass.h"
#include "cutlass/numeric_types.h"
#include "cutlass/array.h"
#include "cutlass/functional.h"
#include "cutlass/numeric_conversion.h"
#include "cutlass/epilogue/thread/scale_type.h"
#include "cutlass/epilogue/thread/linear_combination_params.h"

/////////////////////////////////////////////////////////////////////////////////////////////////

namespace cutlass {
enum class QuantType {
  PerToken,
  PerChannel,
  PTPC,
  NoQuant
};
namespace epilogue {
namespace thread {
template <
  typename ElementOutput_,          // fp16 or bf16
  int Count,                        // fragment size, e.g. 2
  typename ElementScale_,           // fp16
  typename ElementAccumulator_,     // int32
  typename ElementCompute_,         // fp32 (compute type)
  QuantType QuantType_ = QuantType::PTPC,
  FloatRoundStyle Round = FloatRoundStyle::round_to_nearest
>
class PTPCEpilogueOutputOp {
public:

  using ElementOutput = ElementOutput_;
  using ElementScale = ElementScale_;
  using ElementAccumulator = ElementAccumulator_;
  using ElementCompute = ElementCompute_;

  static int const kCount = Count;
  using FragmentOutput = Array<ElementOutput, kCount>;
  using FragmentAccumulator = Array<ElementAccumulator, kCount>;
  using FragmentCompute = Array<ElementCompute, kCount>;
  using FragmentPerTokenScales = Array<ElementScale, kCount>;
  using FragmentPerChannelScales = Array<ElementScale, kCount>;

  static FloatRoundStyle const kRound = Round;

  /// Host-constructable parameters structure
  struct Params {
    ElementCompute alpha;                         ///< scales accumulators
    ElementCompute beta;                          ///< scales source tensor
    CUTLASS_HOST_DEVICE Params(): alpha(1), beta(0) {}
    CUTLASS_HOST_DEVICE Params(ElementCompute alpha): alpha(alpha), beta(0) {}
    CUTLASS_HOST_DEVICE Params(ElementCompute alpha, ElementCompute beta): alpha(alpha), beta(beta) {}
  };

private:
  ElementCompute alpha_;
  ElementCompute beta_;


public:

  /// Constructs the function object, possibly loading from pointers in host memory
  CUTLASS_HOST_DEVICE
  explicit PTPCEpilogueOutputOp(const Params & params) {
    alpha_ = params.alpha;
    beta_ = params.beta;
  }

  /// Returns true if source is needed
  CUTLASS_HOST_DEVICE
  bool is_source_needed() const {
    return beta_ != ElementCompute(0);
  }

  /// Functionally required for serial reduction in the epilogue
  CUTLASS_HOST_DEVICE
  void set_k_partition(int k_partition, int k_partition_count) {
    if (k_partition) {
      beta_ = ElementCompute(1);
    }
  }

  /// Computes linear scaling with source: D = alpha * accumulator + beta * source
  CUTLASS_HOST_DEVICE
  FragmentOutput operator()(
      FragmentAccumulator const &accumulator,
      FragmentOutput const &source,
      FragmentPerChannelScales const &per_channel_scales_frag,
      FragmentPerTokenScales const &per_token_scales_frag
    ) const {
    // Convert source to internal compute numeric type
    NumericArrayConverter<ElementCompute, ElementOutput, kCount, Round> source_converter;
    NumericArrayConverter<ElementCompute, ElementAccumulator, kCount, Round> accumulator_converter;
    NumericArrayConverter<ElementCompute, ElementScale, kCount, Round> scale_converter;

    // Convert to destination numeric type
    NumericArrayConverter<ElementOutput, ElementCompute, kCount, Round> destination_converter;
  
    FragmentCompute converted_wscales = scale_converter(per_channel_scales_frag);  // fp16 -> fp32
    FragmentCompute converted_ascales = scale_converter(per_token_scales_frag);  // fp16 -> fp32
    FragmentCompute converted_source = source_converter(source);
    FragmentCompute converted_accumulator = accumulator_converter(accumulator);

    // Perform operations
    multiplies<FragmentCompute> mul_add_source;
    multiplies<FragmentCompute> mul_accumulator;
    multiply_add<FragmentCompute> mul_add_accumulator;
    
    FragmentCompute intermediate = mul_add_source(beta_, converted_source);
  
    FragmentCompute scaled_acc = mul_accumulator(converted_wscales, converted_accumulator);

    scaled_acc = mul_accumulator(converted_ascales, scaled_acc);

    intermediate = mul_add_accumulator(alpha_, scaled_acc, intermediate);    // D = alpha * Accum + X

    return destination_converter(intermediate);
  }

  CUTLASS_DEVICE
  FragmentOutput operator()(
    FragmentAccumulator const& accumulator_frag, 
    FragmentPerChannelScales const& per_channel_scales_frag,
    FragmentPerTokenScales const& per_token_scales_frag
  ) const {

    // Converters
    NumericArrayConverter<ElementCompute, ElementAccumulator, Count, Round> acc_converter;
    NumericArrayConverter<ElementCompute, ElementScale, Count, Round> scale_converter;
    NumericArrayConverter <ElementOutput, ElementCompute,     Count, Round> out_converter;
    
    multiplies<FragmentCompute> mul_accumulator;

    FragmentCompute converted_accumulator = acc_converter(accumulator_frag);  // int32 -> fp32
    FragmentCompute converted_wscales = scale_converter(per_channel_scales_frag);  // fp16 -> fp32
    FragmentCompute converted_ascales = scale_converter(per_token_scales_frag);  // fp16 -> fp32
    FragmentCompute intermediate = mul_accumulator(alpha_, converted_accumulator);
    intermediate = mul_accumulator(converted_wscales, intermediate);
    intermediate = mul_accumulator(converted_ascales, intermediate);
    FragmentOutput result = out_converter(intermediate);  // fp32 -> fp16

    return result;
  }

};

} // namespace thread
} // namespace epilogue
} // namespace cutlass

/////////////////////////////////////////////////////////////////////////////////////////////////
