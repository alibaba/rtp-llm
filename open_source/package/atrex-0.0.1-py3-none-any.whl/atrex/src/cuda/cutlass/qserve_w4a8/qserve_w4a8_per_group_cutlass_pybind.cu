#include "qserve_w4a8_cutlass.h"

PYBIND11_MODULE(TORCH_EXTENSION_NAME, m) {
  m.def("qserve_w4a8_per_group_gemm_cutlass", &qserve_w4a8_per_group_gemm_cutlass,
        "qserve_w4a8_per_group_gemm_cutlass", 
        py::arg("_in_feats"), 
        py::arg("_kernel"), 
        py::arg("_zeros"),
        py::arg("_scales_i8"), 
        py::arg("_wscales"), 
        py::arg("_ascales"),
        py::arg("_problem_sizes_device"),
        py::arg("_alpha_ptr_array"),
        py::arg("_lda"),
        py::arg("_ldb"),
        py::arg("_ldo"),
        py::arg("_out_feats"),
        py::arg("problem_count"));
}