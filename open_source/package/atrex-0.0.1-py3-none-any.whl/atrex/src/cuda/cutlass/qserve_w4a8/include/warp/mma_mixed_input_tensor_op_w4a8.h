/***************************************************************************************************
 * Copyright (c) 2023 - 2025 NVIDIA CORPORATION & AFFILIATES. All rights reserved.
 * SPDX-License-Identifier: BSD-3-Clause
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 *
 * 1. Redistributions of source code must retain the above copyright notice, this
 * list of conditions and the following disclaimer.
 *
 * 2. Redistributions in binary form must reproduce the above copyright notice,
 * this list of conditions and the following disclaimer in the documentation
 * and/or other materials provided with the distribution.
 *
 * 3. Neither the name of the copyright holder nor the names of its
 * contributors may be used to endorse or promote products derived from
 * this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 * DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE
 * FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
 * DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
 * CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 * OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
 * OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 *
 **************************************************************************************************/
/*! \file
    \brief Templates implementing warp-level matrix multiply-accumulate operations targeting
      Tensor Cores.
*/

#pragma once

#include "cutlass/cutlass.h"
#include "cutlass/array.h"
#include "cutlass/platform/platform.h"

#include "cutlass/numeric_conversion.h"
#include "cutlass/numeric_types.h"
#include "cutlass/matrix_shape.h"

#include "cutlass/arch/memory_sm75.h"
#include "cutlass/arch/mma_sm75.h" 
#include "cutlass/arch/mma_sm80.h"

#include "cutlass/gemm/gemm.h"
#include "cutlass/gemm/warp/mma.h"

#include "cutlass/gemm/warp/mma_tensor_op_policy.h"

#include "cutlass/gemm/warp/mma_tensor_op_tile_iterator.h"
#include "cutlass/gemm/warp/mma_tensor_op_tile_iterator_sm80.h"
#include "cutlass/gemm/warp/mma_mixed_input_tensor_op.h"

/////////////////////////////////////////////////////////////////////////////////////////////////

namespace cutlass {
namespace gemm {
namespace warp {

namespace detail {
template <
  /// Destination type
  typename Element_, 
  typename Element_scale_,
  /// Number of elements
  int N,
  int N_scale> 
struct FragmentUnpack {

  using Element = Element_;
  using ElementScale = Element_scale_;

  // Operand fragment registers in destination and source types
  using DestinationFragment = Array<Element, N*2>;
  using SourceFragment      = Array<Element, N>;
  using ScaleFragment       = Array<ElementScale, N_scale>;

  CUTLASS_DEVICE
  DestinationFragment operator()(SourceFragment const &src, ScaleFragment const &scale, ScaleFragment const &zeros) const {
    DestinationFragment dst;
    for (int i = 0; i < N; i++) {
      dst[i / 8 * 16 + i % 8] = static_cast<Element>(src[i] & 0xF);
      dst[i / 8 * 16 + i % 8 + 8] = static_cast<Element>((src[i] & 0xF0) >> 4);
    }
    // N is PACK_WARP_N, WARP_N = PACK_WARP_N * 2
    // THREAD_N = WARP_N / 8 = PACK_WARP_N / 4 = N / 4
    auto *dst_ptr = dst.raw_data();
    for (int i = 0; i < N / 4; i++) {
      uint32_t scale_i32 = uint8_t(scale[i]);
      uint32_t zero_i32 = uint8_t(zeros[i]) * 0x01010101;
      ((uint32_t *)dst_ptr)[i * 2] = ((uint32_t *)dst_ptr)[i * 2] * scale_i32;
      ((uint32_t *)dst_ptr)[i * 2] =
          __vadd4(((uint32_t *)dst_ptr)[i * 2], zero_i32);
      ((uint32_t *)dst_ptr)[i * 2 + 1] =
          ((uint32_t *)dst_ptr)[i * 2 + 1] * scale_i32;
      ((uint32_t *)dst_ptr)[i * 2 + 1] =
          __vadd4(((uint32_t *)dst_ptr)[i * 2 + 1], zero_i32);
    }
    return dst;
  }
};

}

/// Structure to compute the matrix product targeting CUDA cores and SIMT math instructions.
template <
  /// Size of the Gemm problem - concept: gemm::GemmShape<>
  typename Shape_,
  /// Data type of A elements
  typename ElementA_,
  /// Layout of A matrix (concept: MatrixLayout)
  typename LayoutA_,
  /// Data type of B elements
  typename ElementB_,
  /// Layout of B matrix (concept: MatrixLayout)
  typename LayoutB_,
  /// Element type of C matrix
  typename ElementC_,
  /// Layout of C matrix (concept: MatrixLayout)
  typename LayoutC_,
  /// Policy describing warp-level MmaTensorOp (concept: MmaTensorOp policy)
  typename Policy_,
  /// Number of partitions along K dimension
  int PartitionsK_ = 1,
  /// Store the accumulators in row major or column major.  Row major is used
  /// when output layout is interleaved.
  bool AccumulatorsInRowMajor = false,
  /// Used for partial specialization
  typename Enable = bool
>
class MmaMixedInputTensorOpW4A8 {
public:
  /// Shape of warp-level matrix operation (concept: GemmShape)
  using Shape = Shape_;

  /// Data type of multiplicand A
  using ElementA = ElementA_;

  /// Layout of multiplicand A
  using LayoutA = LayoutA_;

  /// Data type of multiplicand B
  using ElementB = ElementB_;

  /// Layout of multiplicand B
  using LayoutB = LayoutB_;

  /// Data type of accumulator matrix C
  using ElementC = ElementC_;

  /// Layout of accumulator matrix C
  using LayoutC = LayoutC_;

  /// Shape of the warp in units of thread (concept: MmaLanePolicySimt)
  using Policy = Policy_;

  /// Underlying matrix multiply operator (concept: arch::Mma)
  using ArchMmaOperator = typename Policy::Operator;

  /// Underlying arch::Mma instruction datatype for A operand
  using ElementAMma = typename ArchMmaOperator::ElementA;

  /// Underlying arch::Mma instruction datatype for B operand
  using ElementBMma = typename ArchMmaOperator::ElementB;

  /// Underlying arch::Mma instruction datatype for C operand
  using MmaElementC = typename ArchMmaOperator::ElementC;

  /// Indicates math operator 
  using MathOperator = typename ArchMmaOperator::Operator;

  /// Architecture tag from underlying instruction
  using ArchTag = typename ArchMmaOperator::ArchTag;

  /// Indicates class of matrix operator
  using OperatorClass = arch::OpClassTensorOp;

  /// Shape of underlying instruction
  using InstructionShape = typename ArchMmaOperator::Shape;

  /// Complex transform on A operand
  static ComplexTransform const kTransformA = ComplexTransform::kNone;

  /// Complex transform on B operand
  static ComplexTransform const kTransformB = ComplexTransform::kNone;

  /// Number of threads participating in warp-level matrix product
  static int const kThreadCount = 32;

  /// Number of partitions along K dimension
  static int const kPartitionsK = PartitionsK_;

  /// 
  // static int const kLoadShapeK = InstructionShape::kK * 
  //  (sizeof_bits<ElementAMma>::value / sizeof_bits<ElementB>::value);

public:

  /// Iterates over the A operand in Shared Memory
  using IteratorA = MmaTensorOpMultiplicandTileIterator<
     MatrixShape<Shape::kM, Shape::kK>, Operand::kA, ElementA, LayoutA,
     MatrixShape<ArchMmaOperator::Shape::kM, ArchMmaOperator::Shape::kK>,
     Policy::OpDelta::kRow, kThreadCount, kPartitionsK>;

  /// Storage for A tile in registers (loaded from Shared Memory)
  using FragmentA = typename IteratorA::Fragment;

  /// Storage for transformed A tile in registers (for use in Mma instruction)
  using TransformedFragmentA =
      Array<ElementAMma, FragmentA::kElements>;

  /// Underlying arch::Mma instruction operand fragment for matrix A
  using MmaOperandA = typename ArchMmaOperator::FragmentA;

  /// Iterates over the B operand in Shared Memory
  using IteratorB = MmaTensorOpMultiplicandTileIterator<
      MatrixShape<Shape::kK, Shape::kN/2>, Operand::kB, ElementB, LayoutB,
      MatrixShape<ArchMmaOperator::Shape::kK, ArchMmaOperator::Shape::kN>,
      Policy::OpDelta::kRow, kThreadCount, kPartitionsK>;

  /// Storage for B tile in registers (loaded from Shared Memory)
  using FragmentB = typename IteratorB::Fragment;

  static constexpr int ScaleElementsPerAccess = Shape::kN / ArchMmaOperator::Shape::kN;
  using FragmentScale = Array<ElementBMma, ScaleElementsPerAccess>;

  /// Storage for transformed B tile in registers (for use in Mma instruction)
  using TransformedFragmentB =
      Array<ElementBMma, FragmentB::kElements*2>;

  /// Underlying arch::Mma instruction operand fragment for matrix B
  using MmaOperandB = typename ArchMmaOperator::FragmentB;

  /// Iterates over the C operand in memory
  using IteratorC = MmaTensorOpAccumulatorTileIterator<
     MatrixShape<Shape::kM, Shape::kN>, ElementC, LayoutC,
     typename ArchMmaOperator::Shape, typename Policy::OpDelta>;

  /// Storage for C tile
  using FragmentC = typename IteratorC::Fragment;

  /// Underlying arch::Mma instruction operand fragment for matrix C
  using MmaOperandC = typename ArchMmaOperator::FragmentC;

  /// Number of mma operations performed
  using MmaIterations = MatrixShape<
    (Shape::kM + ArchMmaOperator::Shape::kM - 1) / ArchMmaOperator::Shape::kM,
    (Shape::kN + ArchMmaOperator::Shape::kN - 1) / ArchMmaOperator::Shape::kN
  >;


public:

  /// Underlying matrix multiply operator (concept: arch::Mma)
  ArchMmaOperator mma;

  mutable int count_f = 0;

public:

  //
  // Methods
  //

  /// Ctor
  CUTLASS_DEVICE
  MmaMixedInputTensorOpW4A8() {}

    /// Performs a warp-level matrix multiply-accumulate operation
  CUTLASS_DEVICE
  void operator()(
    FragmentC &D, 
    TransformedFragmentA const &A, 
    TransformedFragmentB const &B, 
    FragmentC const &C
  ) const {

    D = C;

    MmaOperandA const *ptr_A = reinterpret_cast<MmaOperandA const *>(&A);
    MmaOperandB const *ptr_B = reinterpret_cast<MmaOperandB const *>(&B);
    MmaOperandC *ptr_D = reinterpret_cast<MmaOperandC *>(&D);

    CUTLASS_PRAGMA_UNROLL
    for (int m = 0; m < MmaIterations::kRow; ++m) {

      CUTLASS_PRAGMA_UNROLL
      for (int n = 0; n < MmaIterations::kColumn; ++n) {

        int n_serpentine = ((m % 2) ? (MmaIterations::kColumn - 1 - n) : n);

        if (AccumulatorsInRowMajor) {  // matrix B is reordered
          mma(
            ptr_D[n_serpentine + m * MmaIterations::kColumn],
            ptr_A[m],
            ptr_B[n_serpentine],
            ptr_D[n_serpentine + m * MmaIterations::kColumn]);
        } else {
          mma(ptr_D[m + n_serpentine * MmaIterations::kRow],
              ptr_A[m],
              ptr_B[n_serpentine],
              ptr_D[m + n_serpentine * MmaIterations::kRow]);
        }
        // if (threadIdx.x<32 &&blockIdx.x==0) {
        //   printf("inA: %d: %d %d / %d %d / %d %d / %d %d / \n\
        //     inB:  %d %d / %d %d / %d %d / %d %d / \n\
        //     accum %d %d / %d %d / %d %d / %d %d / %d\n", int(threadIdx.x),
        //     int(A[0]), int(A[1]), int(A[2]), int(A[3]), int(A[4]), int(A[5]),
        //   int(A[6]), int(A[7]), 
        //   int(B[0]), int(B[1]), int(B[2]), int(B[3]), int(B[4]), int(B[5]),
        //   int(B[6]), int(B[7]), 
        //   int(D[0]), int(D[1]), int(D[2]), int(D[3]), int(D[4]), int(D[5]),
        //   int(D[6]), int(D[7]), int(D.size()));
        // }
      }
    }
    // if (threadIdx.x==0 && blockIdx.x==0) printf("in mma\n");
  }

  /// Transform the operand warp fragment register to the required data types and layout 
  /// for the `cultass::arch::Mma`
  CUTLASS_DEVICE
  void transform(TransformedFragmentA &dst_A, TransformedFragmentB &dst_B,
                 FragmentA const &A, FragmentB const &B, 
                 FragmentScale &scale, FragmentScale &zeros) const {
    // if (threadIdx.x==0 && blockIdx.x==0) printf("transform %d %d %d %d %d %d\n", 
    //   int(A[0]), int(A[1]), int(A[2]), int(A[3]), int(A[4]), int(A.size()));


    // Shuffle data within warp to obtain the mma.sync operand layout
    detail::FragmentShuffler<ElementBMma, ElementB, MmaIterations::kColumn, 
             FragmentB::kElements, MmaOperandB::kElements, Operand::kB> shuffler_B;
    FragmentB tmp_B; 
    tmp_B = shuffler_B(B);

    // Convert the B operand to the Mma Instruction operand type
    // detail::FragmentConverter<ElementBMma, ElementB, FragmentB::kElements> convert_B;
    // dst_B = convert_B(tmp_B);

    detail::FragmentUnpack<ElementBMma, ElementBMma, FragmentB::kElements, ScaleElementsPerAccess> transfor_B;
    dst_B = transfor_B(tmp_B, scale, zeros);

    // Array<ElementA, FragmentA::kElements / 2> *
    //     ptr_tmp_A = reinterpret_cast<Array<ElementA,
    //                                          FragmentA::kElements / 2> *>(&tmp_A);
    // Array<ElementAMma, FragmentA::kElements / 2> *
    //     ptr_dst_A = reinterpret_cast<Array<ElementAMma,
    //                                          FragmentA::kElements / 2> *>(&dst_A);

    // Shuffle data within warp to obtain the mma.sync operand layout
    detail::FragmentShuffler<ElementAMma, ElementA, MmaIterations::kRow,
             FragmentA::kElements, MmaOperandA::kElements, Operand::kA> shuffler_A;
    FragmentA tmp_A;

    // Convert the A operand to the Mma Instruction operand type
    detail::FragmentConverter<ElementAMma, ElementA, FragmentA::kElements> convert_A;

    tmp_A = shuffler_A(A);
    // ptr_dst_A[0] = convert_A(ptr_tmp_A[0]);

    // ptr_dst_A[1] = convert_A(ptr_tmp_A[1]);
    dst_A = convert_A(tmp_A);

    // if (threadIdx.x<32 &&blockIdx.x==0) {
    //   printf("transform %d: %d %d %d %d / %d %d %d %d / %d\n", int(threadIdx.x),
    //   int(dst_B[0]), int(dst_B[1]), int(dst_B[2]), int(dst_B[3]), int(dst_B[4]), int(dst_B[5]),
    //   int(dst_B[6]), int(dst_B[7]), int(dst_B.size()));
    //   // count_f +=1;
    // }
    // if (/*threadIdx.x==0 &&*/count_f == 0 && blockIdx.x==0) {
    //   printf("transform %d: %d %d %d\n", int(threadIdx.x),
    //   int(scale[0]), int(scale[1]), int(scale.size()));
    //   count_f +=1;
    // }
  }
};

/////////////////////////////////////////////////////////////////////////////////////////////////

} // namespace warp
} // namespace gemm
} // namespace cutlass

/////////////////////////////////////////////////////////////////////////////////////////////////
