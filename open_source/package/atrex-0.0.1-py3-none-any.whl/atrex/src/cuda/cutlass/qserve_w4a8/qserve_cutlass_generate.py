# SPDX-License-Identifier: MIT
# Copyright (c) 2018-2024, Advanced Micro Devices, Inc. All rights reserved.
# generate kernel instances to speed up compilation

import argparse
from enum import IntEnum
from pathlib import Path
import pkgutil
import sys
import os.path as path
from typing import List, Optional

QSERVER_W4A8_UNIVERSAL_FILENAME = "qserve_w4a8_universal_api.cu"

def update_file(file_path, content):
    """Update the file at file_path with the given content if it differs from the existing content.

    It avoids unnecessary touching of the file which triggers rebuilds
    """

    existing_content = ""
    if path.exists(file_path):
        with open(file_path, "r") as file:
            existing_content = file.read()
    if existing_content == content:
        return
    with open(file_path, "w") as file:
        file.write(content)


QSERVE_W4A8_CUTLASS_KERNEL = """
#include <ATen/cuda/CUDAContext.h>
#include <cuda_fp16.h>
#include <cuda_pipeline_primitives.h>
#include <torch/all.h>

#include "cutlass/cutlass.h"
#include "cutlass/util/device_memory.h"
#include "qserve_w4a8_cutlass.h"
#include "device/gemm_w4a8_universal.h"

__global__ void dummy_flush_kernel(void* ptr, size_t bytes) {{
    size_t tid = blockIdx.x * blockDim.x + threadIdx.x;
    size_t total_threads = gridDim.x * blockDim.x;
    char* data = static_cast<char*>(ptr);

    // 每个线程写入多个位置，确保覆盖足够大的内存
    for (size_t i = tid; i < bytes; i += total_threads) {{
        data[i] = 1;  // 写入任意值（如 1)
    }}
}}

using ElementA = int8_t;
using ElementB = int8_t;//cutlass::int4b_t;
using ElementOutput = cutlass::half_t;
using ElementAccumulator = int32_t;
using ElementScale = cutlass::half_t;
using ElementCompute = float;

using Opeartor = cutlass::arch::OpMultiplyAddSaturate;//MixedInputUpcast;

using LayoutA = cutlass::layout::RowMajor;
// TODO(sumu): support INTERLEAVED_K=64
using LayoutB = cutlass::layout::RowMajorInterleaved<128>;
using LayoutC = cutlass::layout::RowMajor;

static int const kAlignmentA = 16;
static int const kAlignmentB = 16;

template<int ThreadBlockM, int ThreadBlockN, int ThreadBlockK, int WarpM, int WarpN, int WarpK>
constexpr int ComputeElementsPerAccess() {{
    constexpr int kWarpSize = 32;
    constexpr int num_warps = (ThreadBlockM / WarpM) * (ThreadBlockN / WarpN) * (ThreadBlockK / WarpK);
    constexpr int thread_count = num_warps * kWarpSize;
    constexpr int elements_per_warp = WarpM * WarpN;
    constexpr int ratio = elements_per_warp / thread_count;
    constexpr int res = (ratio >= 4) ? 4 : (ratio >= 2) ? 2 : 1;
    return res;
}}

template<typename GemmUniversal>
float qserve_w4a8_universal_kernel(
    const torch::Tensor& _in_feats,
    const torch::Tensor& _kernel,
    const torch::Tensor& _zeros,
    const torch::Tensor& _scales_i8,
    const torch::Tensor& _wscales,
    const torch::Tensor& _ascales,
    torch::Tensor& _out_feats,
    const torch::Tensor& workspace,
    int split_k_factor
) {{
    int M = _in_feats.size(0);
    int N = _out_feats.size(1);
    int K = _in_feats.size(1);

    cutlass::gemm::GemmCoord problem_size(M,N,K);

    typename GemmUniversal::EpilogueOutputOp::Params epilogue_params(
        ElementOutput(1.0),
        ElementOutput(0.0));

    typename GemmUniversal::Arguments arguments{{
        cutlass::gemm::GemmUniversalMode::kGemm,
        problem_size,
        /* split_k_slices = */ split_k_factor,
        epilogue_params,
        _in_feats.data_ptr(),
        _kernel.data_ptr(),
        _out_feats.data_ptr(),
        _out_feats.data_ptr(),
        int64_t(M*K),
        int64_t(N/2*K),
        int64_t(M*N),
        int64_t(M*N),
        _in_feats.stride(0),
        _kernel.stride(0),
        _out_feats.stride(0),
        _out_feats.stride(0),
        _scales_i8.data_ptr<ElementA>(),
        _zeros.data_ptr<ElementA>(),
        static_cast<ElementScale *>(_wscales.data_ptr()),  // ptr_b_chn_scale_device
        static_cast<ElementScale *>(_ascales.data_ptr()),  // ptr_a_token_scale_device
    }};

    GemmUniversal gemm_op;

    cutlass::Status status;

    status = gemm_op.initialize(arguments, workspace.data_ptr());
    if (status != cutlass::Status::kSuccess) {{
        throw std::runtime_error("gemm initialization failed with error");
        return -1.0;
    }}

    //
    // Run the GEMM
    //

    status = gemm_op();

    if (status != cutlass::Status::kSuccess) {{
        throw std::runtime_error("gemm execution failed with error");
        return -1.0;
    }}

#ifdef AUTOTUNE_CPPEVENT
    if (std::getenv("AUTOTUNE_CPPEVENT")){{
        size_t flush_size = 128 * 1024 * 1024;  // 128 MB
        void* d_flush_buf;
        cudaMalloc(&d_flush_buf, flush_size);
        cudaEvent_t events[2];
        cudaError_t error;
        for (auto & event : events) {{
            error = cudaEventCreate(&event);
            if (error != cudaSuccess) {{
                throw std::runtime_error("cudaEventCreate failed with error");
                return -1.0;
            }}
        }}
        for (int i=0; i< 5; i++) {{
            // warm up
            gemm_op();
        }}
        float runtime_ms_all = 0;
        for (int i=0; i< 20; i++)
        {{
            dummy_flush_kernel<<<(flush_size + 255) / 256, 256>>>(d_flush_buf, flush_size);
            cudaDeviceSynchronize();
            error = cudaEventRecord(events[0]);
            gemm_op();
            error = cudaEventRecord(events[1]);
            error = cudaEventSynchronize(events[1]);
            float runtime_ms = 0;
            error = cudaEventElapsedTime(&runtime_ms, events[0], events[1]);
            runtime_ms_all += runtime_ms;
        }}

        cudaFree(d_flush_buf);

        return float(runtime_ms_all / 20);
    }}
#endif

    return 0.0;
}}

{Kernel_API_BODY}

template<typename ThreadblockShape>
int64_t qserve_w4a8_universal_utils(
    int M,
    int N,
    int K,
    int split_k_factor
) {{
    cutlass::gemm::GemmCoord problem_size(M,N,K);

    int64_t bytes = 0;

    // Determine grid shape
    using ThreadblockSwizzle = cutlass::gemm::threadblock::GemmIdentityThreadblockSwizzle<>;
    ThreadblockSwizzle threadblock_swizzle;

    cutlass::gemm::GemmCoord grid_tiled_shape = threadblock_swizzle.get_tiled_shape(
      problem_size, 
      {{ ThreadblockShape::kM, ThreadblockShape::kN, ThreadblockShape::kK }},
      split_k_factor);
    
    if (grid_tiled_shape.k() > 1) {{ // kGemm

      bytes += sizeof(int) * size_t(grid_tiled_shape.m()) * size_t(grid_tiled_shape.n());
    }}

    return bytes;

}}

int64_t qserve_w4a8_universal_get_workspace_size(
    int M,
    int N,
    int K,
    int split_k_factor,
    int thread_block_M,
    int thread_block_N,
    int thread_block_K
){{

    {GET_WORKSPACE_SIZE_BODY}

    throw std::invalid_argument("qserve_w4a8_universal_get_workspace_size not supported");

    return -1;
}}
"""

QSERVE_GET_WORKSPACE_SIZE_CORE = """
    if (thread_block_M == {ThreadBlockM} && thread_block_N == {ThreadBlockN} && thread_block_K == {ThreadBlockK}) {{
        using ThreadBlockShape = cutlass::gemm::GemmShape<{ThreadBlockM}, {ThreadBlockN}, {ThreadBlockK}>;
        return qserve_w4a8_universal_utils<ThreadBlockShape>(M, N, K, split_k_factor);
    }}
"""

QSERVE_API_CORE = """
    if (thread_block_M == {ThreadBlockM} && thread_block_N == {ThreadBlockN} && thread_block_K == {ThreadBlockK} && 
        warp_count_M == {WarpM} && warp_count_N == {WarpN} && warp_count_K == {WarpK} && kStages == {kStages}) {{

        using ThreadBlockShape = cutlass::gemm::GemmShape<{ThreadBlockM}, {ThreadBlockN}, {ThreadBlockK}>;
        using WarpShape = cutlass::gemm::GemmShape<{WarpM}, {WarpN}, {WarpK}>;

        // NOTE: CTA_K=64 has similar performance but shows correctness issues on small tiles
        static_assert(ThreadBlockShape::kK == 128, "CTA_K must be 128");

        using GemmUniversal = cutlass::gemm::device::GemmUniversalW4A8<
            ElementA, LayoutA, ElementB, LayoutB, ElementOutput, LayoutC,
            ElementAccumulator, cutlass::arch::OpClassTensorOp, cutlass::arch::Sm80,
            ThreadBlockShape,
            WarpShape,
            cutlass::gemm::GemmShape<16, 8, 32>,
            cutlass::epilogue::thread::PTPCEpilogueOutputOp<
                ElementOutput,
                ComputeElementsPerAccess<{ThreadBlockM}, {ThreadBlockN}, {ThreadBlockK}, {WarpM}, {WarpN}, {WarpK}>(),
                ElementScale, ElementAccumulator, ElementCompute>, 
            cutlass::gemm::threadblock::GemmIdentityThreadblockSwizzle<>, {kStages},
            kAlignmentA, kAlignmentB, Opeartor
        >;

        return qserve_w4a8_universal_kernel<GemmUniversal>(
            _in_feats, _kernel, _zeros, _scales_i8, _wscales, _ascales, _out_feats, workspace, split_k_factor
        );

    }}
"""

QSERVE_API_BODY = """
float qserve_w4a8_universal_body(
    const torch::Tensor& _in_feats,
    const torch::Tensor& _kernel,
    const torch::Tensor& _zeros,
    const torch::Tensor& _scales_i8,
    const torch::Tensor& _wscales,
    const torch::Tensor& _ascales,
    torch::Tensor& _out_feats,
    const torch::Tensor& workspace,
    int split_k_factor,
    int thread_block_M,
    int thread_block_N,
    int thread_block_K,
    int warp_count_M,
    int warp_count_N,
    int warp_count_K,
    int kStages
) {{
    {QSERVER_API_LOOP}

    throw std::invalid_argument("qserve_w4a8_universal not supported");
    
    return -1.0;
}}
"""

def write_blobs(
        output_dir,
        CTAM: list,
        CTAN: list,
        CTAK: list,
        WARPM: list,
        WARPN: list,
        WARPK: list,
        STAGES: list) -> None:
    api_core = """"""
    for CTAM_, CTAN_, CTAK_, WARPM_, WARPN_, WARPK_, STAGES_ in zip(CTAM, CTAN, CTAK, WARPM, WARPN, WARPK, STAGES):
        api_core += QSERVE_API_CORE.format(
            ThreadBlockM=CTAM_,
            ThreadBlockN=CTAN_,
            ThreadBlockK=CTAK_,
            WarpM=WARPM_,
            WarpN=WARPN_,
            WarpK=WARPK_,
            kStages=STAGES_
        )
    
    utils_core = """"""
    for CTAM_, CTAN_, CTAK_, WARPM_, WARPN_, WARPK_, STAGES_ in zip(CTAM, CTAN, CTAK, WARPM, WARPN, WARPK, STAGES):
        utils_core += QSERVE_GET_WORKSPACE_SIZE_CORE.format(
            ThreadBlockM=CTAM_,
            ThreadBlockN=CTAN_,
            ThreadBlockK=CTAK_,
        )

    api_body = QSERVE_API_BODY.format(
            QSERVER_API_LOOP=api_core,
        )
    
    content = QSERVE_W4A8_CUTLASS_KERNEL.format(
            Kernel_API_BODY=api_body,
            GET_WORKSPACE_SIZE_BODY=utils_core
        )

    if output_dir is None:
        output_dir = Path(__file__).parent
    else:
        output_dir = Path(output_dir)
    update_file(output_dir / QSERVER_W4A8_UNIVERSAL_FILENAME, content)

if __name__ == "__main__":
    parser = argparse.ArgumentParser(
        prog="generate",
        description="gen API for qserver w4a8 kernel",
    )
    parser.add_argument(
        "-o",
        "--output_dir",
        required=False,
        help="write all the blobs into a directory"
    )
    parser.add_argument(
        "-bm",
        "--block_m",
        nargs='+',
        type=int,
        default=[32],
        required=False,
        help="M block size"
    )
    parser.add_argument(
        "-bn",
        "--block_n",
        nargs='+',
        type=int,
        default=[32],
        required=False,
        help="N block size"
    )
    parser.add_argument(
        "-bk",
        "--block_k",
        nargs='+',
        type=int,
        default=[128],
        required=False,
        help="M block size"
    )
    parser.add_argument(
        "-wm",
        "--warp_m",
        nargs='+',
        type=int,
        default=[32],
        required=False,
        help="M warp size"
    )
    parser.add_argument(
        "-wn",
        "--warp_n",
        nargs='+',
        type=int,
        default=[32],
        required=False,
        help="N warp size"
    )
    parser.add_argument(
        "-wk",
        "--warp_k",
        nargs='+',
        type=int,
        default=[128],
        required=False,
        help="K warp size"
    )
    parser.add_argument(
        "-s",
        "--stages",
        nargs='+',
        type=int,
        default=[2],
        required=False,
        help="number of stages"
    )
    parser.add_argument(
        "-sk",
        "--split_k_factor",
        nargs='+',
        type=int,
        default=[2],
        required=False,
        help="number of split_k"
    )


    args = parser.parse_args()

    write_blobs(
            args.output_dir, args.block_m, args.block_n, args.block_k,
            args.warp_m, args.warp_n, args.warp_k, args.stages
        )