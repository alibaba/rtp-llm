#pragma once

#define ENABLE_ASYNC_COPY
