/***************************************************************************************************
 * Copyright (c) 2017 - 2025 NVIDIA CORPORATION & AFFILIATES. All rights reserved.
 * SPDX-License-Identifier: BSD-3-Clause
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 *
 * 1. Redistributions of source code must retain the above copyright notice, this
 * list of conditions and the following disclaimer.
 *
 * 2. Redistributions in binary form must reproduce the above copyright notice,
 * this list of conditions and the following disclaimer in the documentation
 * and/or other materials provided with the distribution.
 *
 * 3. Neither the name of the copyright holder nor the names of its
 * contributors may be used to endorse or promote products derived from
 * this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 * DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE
 * FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
 * DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
 * CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 * OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
 * OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 *
 **************************************************************************************************/
/*! \file
    \brief Template for a double-buffered threadblock-scoped GEMM kernel.
*/

#pragma once

#include "cutlass/tensor_ref.h"
#include "cutlass/aligned_buffer.h"
#include "cutlass/arch/memory.h"
#include "cutlass/array.h"
#include "cutlass/cutlass.h"
#include "cutlass/gemm/gemm.h"
#include "cutlass/matrix_shape.h"
#include "cutlass/numeric_types.h"

#include "config.h"

////////////////////////////////////////////////////////////////////////////////

namespace cutlass {
namespace gemm {
namespace threadblock {

////////////////////////////////////////////////////////////////////////////////

#if 0
/// Policy object describing MmaTensorOp
template <
    /// Warp-level GEMM operator (concept: gemm::warp::Mma)
    typename Operator_,
    /// Padding used for A operand in shared memory (concept: MatrixShape)
    typename SmemPaddingA_,
    /// Padding used for B operand in shared memory (concept: MatrixShape)
    typename SmemPaddingB_,
    /// Number of partitions of K dimension of GEMM
    int PartitionsK = 1>
struct MmaPolicy {
  /// Warp-level GEMM operator (concept: gemm::warp::MmaTensorOp or gemm::warp::MmaSimt)
  using Operator = Operator_;

  /// Padding used for A operand in shared memory
  using SmemPaddingA = SmemPaddingA_;

  /// Padding used for B operand in shared memory
  using SmemPaddingB = SmemPaddingB_;

  /// Number of partitions of K dimension
  static int const kPartitionsK = PartitionsK;
};
#endif

////////////////////////////////////////////////////////////////////////////////

/// Structure to compute the matrix product targeting CUDA cores and SIMT math
/// instructions.
template <
    /// Size of the Gemm problem - concept: gemm::GemmShape<>
    typename Shape_,
    /// Policy describing tuning details (concept: MmaPolicy)
    typename Policy_,
    /// Number of stages,
    int Stages,
#ifdef ENABLE_ASYNC_COPY
    typename SmemIteratorScale_, typename RegisterIteratorScale_,
#endif
    /// Used for partial specialization
    typename Enable = bool>
class MmaBaseW4A8 {
 public:
  ///< Size of the Gemm problem - concept: gemm::GemmShape<>
  using Shape = Shape_;

  ///< Policy describing tuning details
  using Policy = Policy_;

#ifdef ENABLE_ASYNC_COPY
  using SmemIteratorScale = SmemIteratorScale_;
  using RegisterIteratorScale = RegisterIteratorScale_;
#endif

  //
  // Dependent types
  //

  /// Warp-level Mma
  using Operator = typename Policy::Operator;

  /// Shape describing the overall GEMM computed from shared memory
  /// by each warp.
  using WarpGemm = typename Policy::Operator::Shape;

  /// Shape describing the number of warps filling the CTA
  using WarpCount = GemmShape<Shape::kM / WarpGemm::kM,
                              Shape::kN / WarpGemm::kN,
                              Shape::kK / WarpGemm::kK>;

  /// Number of warp-level GEMM oeprations
  static int const kWarpGemmIterations =
      (WarpGemm::kK / Operator::Policy::MmaShape::kK);

  /// Number of stages
  static int const kStages = Stages;

  static int const kWarpSize = 32;
  static constexpr int kMMAWarpThreadsN = 8; /* more precisely, INSTR_N */
  static constexpr int kMMAWarpThreadsK = 4; /* threads along the MMA reduction axis */

  /// Tensor reference to the A operand
  using TensorRefA = TensorRef<typename Operator::ElementA, typename Operator::LayoutA>;

  /// Tensor reference to the B operand
  using TensorRefB = TensorRef<typename Operator::ElementB, typename Operator::LayoutB>;

#ifdef ENABLE_ASYNC_COPY
  /// Tensor reference to the scale operand
  using TensorRefScaleG2S = TensorRef<typename SmemIteratorScale::Element,
                                      typename SmemIteratorScale::Layout>;

  /// Tensor reference to the scale operand
  using TensorRefScaleS2R = TensorRef<typename RegisterIteratorScale::Element,
                                      typename RegisterIteratorScale::Layout>;
#endif

  static_assert(kWarpGemmIterations > 1,
                "The pipelined structure requires at least two warp-level "
                "GEMM operations.");

  static_assert((kWarpGemmIterations % 2) == 0,
                "Inner loop iteration must be an even number.");

  //
  // Nested structs
  //

  /// Shared storage object needed by threadblock-scoped GEMM
  class SharedStorage {
   public:
    //
    // Type definitions
    //

    /// Shape of the A matrix operand in shared memory
    using ShapeA = MatrixShape<Shape::kM + Policy::SmemPaddingA::kRow,
                               Shape::kK * kStages +
                                   Policy::SmemPaddingA::kColumn>;

    /// Shape of the B matrix operand in shared memory
    using ShapeB =
        MatrixShape<Shape::kK * kStages + Policy::SmemPaddingB::kRow,
                    Shape::kN + Policy::SmemPaddingB::kColumn>;

#ifdef ENABLE_ASYNC_COPY
    /// Shape of the scale matrix operand in shared memory
    // TODO(sumu): check SharedStorage size via Shape/AlignedBuffer
    using ShapeScale =
        MatrixShape<(Shape::kK + 127) / 128 * kStages, Shape::kN>;
#endif

   public:
    //
    // Data members
    //

    /// Buffer for A operand
    AlignedBuffer<typename Operator::ElementA, ShapeA::kCount> operand_A;

    /// Buffer for B operand
    AlignedBuffer<typename Operator::ElementB, ShapeB::kCount> operand_B;

#ifdef ENABLE_ASYNC_COPY
    /// Buffer for scale operand
    AlignedBuffer<typename SmemIteratorScale::Element, ShapeScale::kCount>
        operand_scale;

    /// Buffer for zero operand
    AlignedBuffer<typename SmemIteratorScale::Element, ShapeScale::kCount>
        operand_zero;
#endif

   public:

    //
    // Methods
    //

    /// Returns a layout object for the A matrix
    CUTLASS_DEVICE
    static typename Operator::LayoutA LayoutA() {
      return Operator::LayoutA::packed({ShapeA::kRow, ShapeA::kColumn});
    }

    /// Returns a layout object for the B matrix
    CUTLASS_HOST_DEVICE
    static typename Operator::LayoutB LayoutB() {
      return Operator::LayoutB::packed({ShapeB::kRow, ShapeB::kColumn});
    }

#ifdef ENABLE_ASYNC_COPY
    /// Returns a layout object for the scale matrix
    CUTLASS_HOST_DEVICE
    static typename SmemIteratorScale::Layout LayoutScaleG2S() {
      return SmemIteratorScale::Layout::packed(
          {ShapeScale::kRow, ShapeScale::kColumn});
    }

    /// Returns a layout object for the scale matrix
    CUTLASS_HOST_DEVICE
    static typename RegisterIteratorScale::Layout LayoutScaleS2R() {
      return RegisterIteratorScale::Layout::packed(
          {(Shape::kK + 127) / 128, WarpGemm::kN});
    }
#endif

    /// Returns a TensorRef to the A operand
    CUTLASS_HOST_DEVICE
    TensorRefA operand_A_ref() {
      return TensorRefA{operand_A.data(), LayoutA()};
    }

    /// Returns a TensorRef to the B operand
    CUTLASS_HOST_DEVICE
    TensorRefB operand_B_ref() {
      return TensorRefB{operand_B.data(), LayoutB()};
    }

#ifdef ENABLE_ASYNC_COPY
    /// Returns a TensorRef to the scale operand
    CUTLASS_HOST_DEVICE
    TensorRefScaleG2S operand_scale_ref_g2s() {
      return TensorRefScaleG2S{operand_scale.data(), LayoutScaleG2S()};
    }

    /// Returns a TensorRef to the scale operand
    CUTLASS_HOST_DEVICE
    TensorRefScaleS2R operand_scale_ref_s2r() {
      return TensorRefScaleS2R{operand_scale.data(), LayoutScaleS2R()};
    }

    /// Returns a TensorRef to the zero operand
    CUTLASS_HOST_DEVICE
    TensorRefScaleG2S operand_zero_ref_g2s() {
      return TensorRefScaleG2S{operand_zero.data(), LayoutScaleG2S()};
    }

    /// Returns a TensorRef to the zero operand
    CUTLASS_HOST_DEVICE
    TensorRefScaleS2R operand_zero_ref_s2r() {
      return TensorRefScaleS2R{operand_zero.data(), LayoutScaleS2R()};
    }
#endif
  };

 protected:

  //
  // Data members
  //

  /// Iterator to load a warp-scoped tile of A operand from shared memory
  typename Operator::IteratorA warp_tile_iterator_A_;

  /// Iterator to load a warp-scoped tile of B operand from shared memory
  typename Operator::IteratorB warp_tile_iterator_B_;

#ifdef ENABLE_ASYNC_COPY
  /// Iterator to load a warp-scoped tile of scale operand from shared memory
  RegisterIteratorScale warp_tile_iterator_scale_;

  /// Iterator to load a warp-scoped tile of zero operand from shared memory
  RegisterIteratorScale warp_tile_iterator_zero_;
#endif
  
 public:
  /// Construct from tensor references
  CUTLASS_DEVICE
  MmaBaseW4A8(
      ///< Shared storage needed for internal use by threadblock-scoped GEMM
      SharedStorage &shared_storage,
      ///< ID within the threadblock
      int thread_idx,
      ///< ID of warp
      int warp_idx,
      ///< ID of each thread within a warp
      int lane_idx)
      : warp_tile_iterator_A_(shared_storage.operand_A_ref(), lane_idx),
        warp_tile_iterator_B_(shared_storage.operand_B_ref(), lane_idx)
#ifdef ENABLE_ASYNC_COPY
        // inter-warp layout follows column-major order
        // NOTE: hides the vectorized size = ElementsPerAccessS2R;
        // WARP_N = kMMAWarpThreadsN * ElementsPerAccessS2R
        ,
        warp_tile_iterator_scale_(
            shared_storage.operand_scale_ref_s2r(),
            thread_idx / kWarpSize /
            (Shape::kM / WarpGemm::kM) % (Shape::kN / WarpGemm::kN) *
            kMMAWarpThreadsN + thread_idx % kWarpSize / kMMAWarpThreadsK),
        warp_tile_iterator_zero_(
            shared_storage.operand_zero_ref_s2r(),
            thread_idx / kWarpSize /
            (Shape::kM / WarpGemm::kM) % (Shape::kN / WarpGemm::kN) *
            kMMAWarpThreadsN + thread_idx % kWarpSize / kMMAWarpThreadsK)
#endif
  {
  }
};

/////////////////////////////////////////////////////////////////////////////////////////////////

}  // namespace threadblock
}  // namespace gemm
}  // namespace cutlass

/////////////////////////////////////////////////////////////////////////////////////////////////
