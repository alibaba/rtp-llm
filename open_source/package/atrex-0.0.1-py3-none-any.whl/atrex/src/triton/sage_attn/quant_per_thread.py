"""
Copyright (c) 2024 by SageAttention team.

Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

    http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.
"""

import torch
import triton
import triton.language as tl

@triton.jit
def quant_key_per_thread_int8_kernel_v2_fused_km_swizzle(
    Input, Output, Scale, Km, L,
    stride_iz, stride_ih, stride_in,
    stride_oz, stride_oh, stride_on,
    stride_sz, stride_sh,
    stride_kmz, stride_kmh,
    C: tl.constexpr, BLK: tl.constexpr,
    NUM_WARP_BLKS: tl.constexpr,
):
    """
    Fused key quantization with km subtraction + head_dim swizzle on store.
    
    The swizzle remaps each element in the head_dim (C=128) dimension:
      Original index: d = a*8 + b*4 + c  (a in [0,16), b in [0,2), c in [0,4))
      Swizzled index: d' = b*64 + a*4 + c
    
    This is equivalent to:
      reshape(..., 16, 2, 4).permute(..., 1, 0, 2).reshape(..., 128)
    """
    off_prog = tl.program_id(0)
    off_h = tl.program_id(1)
    off_b = tl.program_id(2)

    base_in = Input + off_b * stride_iz + off_h * stride_ih
    base_out = Output + off_b * stride_oz + off_h * stride_oh
    scale_base = Scale + off_b * stride_sz + off_h * stride_sh

    offs_k = tl.arange(0, C)
    ROWS_PER_GROUP: tl.constexpr = BLK // 8

    # Precompute swizzled head_dim indices:
    # d = a*8 + b*4 + c => d' = b*64 + a*4 + c
    a = offs_k // 8        # [0, 16)
    b = (offs_k % 8) // 4  # [0, 2)
    c = offs_k % 4         # [0, 4)
    offs_k_swizzled = b * 64 + a * 4 + c

    # Load km vector once per (batch, head)
    km_ptr = Km + off_b * stride_kmz + off_h * stride_kmh + offs_k
    km_vec = tl.load(km_ptr).to(tl.float32)

    for wb in tl.static_range(0, NUM_WARP_BLKS):
        blk_idx = off_prog * NUM_WARP_BLKS + wb
        blk_start = blk_idx * BLK

        for tld in tl.static_range(0, 4):
            offs_n0 = blk_start + tl.arange(0, ROWS_PER_GROUP) * 8 + tld * 2
            offs_n1 = blk_start + tl.arange(0, ROWS_PER_GROUP) * 8 + tld * 2 + 1

            # Load from original layout
            input_ptrs0 = base_in + offs_n0[:, None] * stride_in + offs_k[None, :]
            input_ptrs1 = base_in + offs_n1[:, None] * stride_in + offs_k[None, :]
            # Store with swizzled head_dim indices
            output_ptrs0 = base_out + offs_n0[:, None] * stride_on + offs_k_swizzled[None, :]
            output_ptrs1 = base_out + offs_n1[:, None] * stride_on + offs_k_swizzled[None, :]

            x0 = tl.load(input_ptrs0, mask=offs_n0[:, None] < L)
            x1 = tl.load(input_ptrs1, mask=offs_n1[:, None] < L)
            x0 = x0.to(tl.float32) - km_vec[None, :]
            x1 = x1.to(tl.float32) - km_vec[None, :]

            scale = max(tl.max(tl.abs(x0)), tl.max(tl.abs(x1))) / 127. + 0.0000001
            x0_int8 = x0 / scale
            x1_int8 = x1 / scale
            x0_int8 += 0.5 * tl.where(x0_int8 >= 0, 1, -1)
            x1_int8 += 0.5 * tl.where(x1_int8 >= 0, 1, -1)
            x0_int8 = x0_int8.to(tl.int8)
            x1_int8 = x1_int8.to(tl.int8)
            tl.store(output_ptrs0, x0_int8, mask=offs_n0[:, None] < L)
            tl.store(output_ptrs1, x1_int8, mask=offs_n1[:, None] < L)
            tl.store(scale_base + blk_idx * 4 + tld, scale)


@triton.jit
def quant_key_per_thread_int8_kernel_v2_swizzle(
    Input, Output, Scale, L,
    stride_iz, stride_ih, stride_in,
    stride_oz, stride_oh, stride_on,
    stride_sz, stride_sh,
    C: tl.constexpr, BLK: tl.constexpr,
    NUM_WARP_BLKS: tl.constexpr,
):
    """
    Fused key quantization (no km) + head_dim swizzle on store.
    """
    off_prog = tl.program_id(0)
    off_h = tl.program_id(1)
    off_b = tl.program_id(2)

    base_in = Input + off_b * stride_iz + off_h * stride_ih
    base_out = Output + off_b * stride_oz + off_h * stride_oh
    scale_base = Scale + off_b * stride_sz + off_h * stride_sh

    offs_k = tl.arange(0, C)
    ROWS_PER_GROUP: tl.constexpr = BLK // 8

    # Precompute swizzled head_dim indices
    a = offs_k // 8
    b = (offs_k % 8) // 4
    c = offs_k % 4
    offs_k_swizzled = b * 64 + a * 4 + c

    for wb in tl.static_range(0, NUM_WARP_BLKS):
        blk_idx = off_prog * NUM_WARP_BLKS + wb
        blk_start = blk_idx * BLK

        for tld in tl.static_range(0, 4):
            offs_n0 = blk_start + tl.arange(0, ROWS_PER_GROUP) * 8 + tld * 2
            offs_n1 = blk_start + tl.arange(0, ROWS_PER_GROUP) * 8 + tld * 2 + 1

            input_ptrs0 = base_in + offs_n0[:, None] * stride_in + offs_k[None, :]
            input_ptrs1 = base_in + offs_n1[:, None] * stride_in + offs_k[None, :]
            output_ptrs0 = base_out + offs_n0[:, None] * stride_on + offs_k_swizzled[None, :]
            output_ptrs1 = base_out + offs_n1[:, None] * stride_on + offs_k_swizzled[None, :]

            x0 = tl.load(input_ptrs0, mask=offs_n0[:, None] < L)
            x1 = tl.load(input_ptrs1, mask=offs_n1[:, None] < L)
            x0 = x0.to(tl.float32)
            x1 = x1.to(tl.float32)

            scale = max(tl.max(tl.abs(x0)), tl.max(tl.abs(x1))) / 127. + 0.0000001
            x0_int8 = x0 / scale
            x1_int8 = x1 / scale
            x0_int8 += 0.5 * tl.where(x0_int8 >= 0, 1, -1)
            x1_int8 += 0.5 * tl.where(x1_int8 >= 0, 1, -1)
            x0_int8 = x0_int8.to(tl.int8)
            x1_int8 = x1_int8.to(tl.int8)
            tl.store(output_ptrs0, x0_int8, mask=offs_n0[:, None] < L)
            tl.store(output_ptrs1, x1_int8, mask=offs_n1[:, None] < L)
            tl.store(scale_base + blk_idx * 4 + tld, scale)


@triton.jit
def quant_query_per_thread_int8_kernel(Input, Output, Scale, L,
                                        stride_iz, stride_ih, stride_in,
                                        stride_oz, stride_oh, stride_on,
                                        stride_sz, stride_sh,
                                        C: tl.constexpr, BLK: tl.constexpr):
    off_blk = tl.program_id(0) // 8
    off_tld = tl.program_id(0) % 8
    off_h = tl.program_id(1)
    off_b = tl.program_id(2)

    offs_n = off_blk * BLK + tl.arange(0, BLK // 8) * 8 + off_tld
    offs_k = tl.arange(0, C)

    input_ptrs = Input + off_b * stride_iz + off_h * stride_ih + offs_n[:, None] * stride_in + offs_k[None, :]
    output_ptrs = Output + off_b * stride_oz + off_h * stride_oh + offs_n[:, None] * stride_on + offs_k[None, :]
    scale_ptrs = Scale + off_b * stride_sz + off_h * stride_sh + off_blk * 8 + off_tld

    x = tl.load(input_ptrs, mask=offs_n[:, None] < L)
    x = x.to(tl.float32)
    scale = tl.max(tl.abs(x)) / 127. + 0.0000001
    x_int8 = x / scale
    x_int8 += 0.5 * tl.where(x_int8 >= 0, 1, -1)
    x_int8 = x_int8.to(tl.int8)
    tl.store(output_ptrs, x_int8, mask=offs_n[:, None] < L)
    tl.store(scale_ptrs, scale)


@triton.jit
def quant_query_per_thread_int8_kernel_v2(Input, Output, Scale, L,
                                           stride_iz, stride_ih, stride_in,
                                           stride_oz, stride_oh, stride_on,
                                           stride_sz, stride_sh,
                                           C: tl.constexpr, BLK: tl.constexpr,
                                           NUM_WARP_BLKS: tl.constexpr):
    off_prog = tl.program_id(0)
    off_h = tl.program_id(1)
    off_b = tl.program_id(2)

    base_in = Input + off_b * stride_iz + off_h * stride_ih
    base_out = Output + off_b * stride_oz + off_h * stride_oh
    scale_base = Scale + off_b * stride_sz + off_h * stride_sh

    offs_k = tl.arange(0, C)
    ROWS_PER_GROUP: tl.constexpr = BLK // 8

    for wb in tl.static_range(0, NUM_WARP_BLKS):
        blk_idx = off_prog * NUM_WARP_BLKS + wb
        blk_start = blk_idx * BLK

        for tld in tl.static_range(0, 8):
            offs_n = blk_start + tl.arange(0, ROWS_PER_GROUP) * 8 + tld

            input_ptrs = base_in + offs_n[:, None] * stride_in + offs_k[None, :]
            output_ptrs = base_out + offs_n[:, None] * stride_on + offs_k[None, :]

            x = tl.load(input_ptrs, mask=offs_n[:, None] < L)
            x = x.to(tl.float32)
            scale = tl.max(tl.abs(x)) / 127. + 0.0000001
            x_int8 = x / scale
            x_int8 += 0.5 * tl.where(x_int8 >= 0, 1, -1)
            x_int8 = x_int8.to(tl.int8)
            tl.store(output_ptrs, x_int8, mask=offs_n[:, None] < L)
            tl.store(scale_base + blk_idx * 8 + tld, scale)


@triton.jit
def quant_key_per_thread_int8_kernel(Input, Output, Scale, L,
                                        stride_iz, stride_ih, stride_in,
                                        stride_oz, stride_oh, stride_on,
                                        stride_sz, stride_sh,
                                        C: tl.constexpr, BLK: tl.constexpr):
    off_blk = tl.program_id(0) // 4
    off_tld = tl.program_id(0) % 4
    off_h = tl.program_id(1)
    off_b = tl.program_id(2)

    offs_n0 = off_blk * BLK + tl.arange(0, BLK // 8) * 8 + off_tld * 2
    offs_n1 = off_blk * BLK + tl.arange(0, BLK // 8) * 8 + off_tld * 2 + 1
    offs_k = tl.arange(0, C)

    input_ptrs0 = Input + off_b * stride_iz + off_h * stride_ih + offs_n0[:, None] * stride_in + offs_k[None, :]
    input_ptrs1 = Input + off_b * stride_iz + off_h * stride_ih + offs_n1[:, None] * stride_in + offs_k[None, :]
    output_ptrs0 = Output + off_b * stride_oz + off_h * stride_oh + offs_n0[:, None] * stride_on + offs_k[None, :]
    output_ptrs1 = Output + off_b * stride_oz + off_h * stride_oh + offs_n1[:, None] * stride_on + offs_k[None, :]
    scale_ptrs = Scale + off_b * stride_sz + off_h * stride_sh + off_blk * 4 + off_tld

    x0 = tl.load(input_ptrs0, mask=offs_n0[:, None] < L)
    x1 = tl.load(input_ptrs1, mask=offs_n1[:, None] < L)
    x0 = x0.to(tl.float32)
    x1 = x1.to(tl.float32)
    scale = max(tl.max(tl.abs(x0)), tl.max(tl.abs(x1))) / 127. + 0.0000001
    x0_int8 = x0 / scale
    x1_int8 = x1 / scale
    x0_int8 += 0.5 * tl.where(x0_int8 >= 0, 1, -1)
    x1_int8 += 0.5 * tl.where(x1_int8 >= 0, 1, -1)
    x0_int8 = x0_int8.to(tl.int8)
    x1_int8 = x1_int8.to(tl.int8)
    tl.store(output_ptrs0, x0_int8, mask=offs_n0[:, None] < L)
    tl.store(output_ptrs1, x1_int8, mask=offs_n1[:, None] < L)
    tl.store(scale_ptrs, scale)


@triton.jit
def quant_key_per_thread_int8_kernel_v2(Input, Output, Scale, L,
                                         stride_iz, stride_ih, stride_in,
                                         stride_oz, stride_oh, stride_on,
                                         stride_sz, stride_sh,
                                         C: tl.constexpr, BLK: tl.constexpr,
                                         NUM_WARP_BLKS: tl.constexpr):
    """
    Fused key quantization: one program handles NUM_WARP_BLKS warp blocks,
    each with 4 thread groups. Same logic as original kernel, just serialized
    within one program to reduce grid size.
    """
    off_prog = tl.program_id(0)
    off_h = tl.program_id(1)
    off_b = tl.program_id(2)

    base_in = Input + off_b * stride_iz + off_h * stride_ih
    base_out = Output + off_b * stride_oz + off_h * stride_oh
    scale_base = Scale + off_b * stride_sz + off_h * stride_sh

    offs_k = tl.arange(0, C)
    ROWS_PER_GROUP: tl.constexpr = BLK // 8

    for wb in tl.static_range(0, NUM_WARP_BLKS):
        blk_idx = off_prog * NUM_WARP_BLKS + wb
        blk_start = blk_idx * BLK

        for tld in tl.static_range(0, 4):
            offs_n0 = blk_start + tl.arange(0, ROWS_PER_GROUP) * 8 + tld * 2
            offs_n1 = blk_start + tl.arange(0, ROWS_PER_GROUP) * 8 + tld * 2 + 1

            input_ptrs0 = base_in + offs_n0[:, None] * stride_in + offs_k[None, :]
            input_ptrs1 = base_in + offs_n1[:, None] * stride_in + offs_k[None, :]
            output_ptrs0 = base_out + offs_n0[:, None] * stride_on + offs_k[None, :]
            output_ptrs1 = base_out + offs_n1[:, None] * stride_on + offs_k[None, :]

            x0 = tl.load(input_ptrs0, mask=offs_n0[:, None] < L)
            x1 = tl.load(input_ptrs1, mask=offs_n1[:, None] < L)
            x0 = x0.to(tl.float32)
            x1 = x1.to(tl.float32)

            scale = max(tl.max(tl.abs(x0)), tl.max(tl.abs(x1))) / 127. + 0.0000001
            x0_int8 = x0 / scale
            x1_int8 = x1 / scale
            x0_int8 += 0.5 * tl.where(x0_int8 >= 0, 1, -1)
            x1_int8 += 0.5 * tl.where(x1_int8 >= 0, 1, -1)
            x0_int8 = x0_int8.to(tl.int8)
            x1_int8 = x1_int8.to(tl.int8)
            tl.store(output_ptrs0, x0_int8, mask=offs_n0[:, None] < L)
            tl.store(output_ptrs1, x1_int8, mask=offs_n1[:, None] < L)
            tl.store(scale_base + blk_idx * 4 + tld, scale)

@triton.jit
def quant_key_per_thread_int8_kernel_v2_fused_km(
    Input, Output, Scale, Km, L,
    stride_iz, stride_ih, stride_in,
    stride_oz, stride_oh, stride_on,
    stride_sz, stride_sh,
    stride_kmz, stride_kmh,
    C: tl.constexpr, BLK: tl.constexpr,
    NUM_WARP_BLKS: tl.constexpr,
):
    """
    Fused key quantization with km subtraction: loads k, subtracts km in-register,
    then quantizes to int8. Eliminates the separate k = k - km allocation.
    km has shape (B, 1, H, D) in NHD layout, broadcast along seq dim.
    """
    off_prog = tl.program_id(0)
    off_h = tl.program_id(1)
    off_b = tl.program_id(2)

    base_in = Input + off_b * stride_iz + off_h * stride_ih
    base_out = Output + off_b * stride_oz + off_h * stride_oh
    scale_base = Scale + off_b * stride_sz + off_h * stride_sh

    offs_k = tl.arange(0, C)
    ROWS_PER_GROUP: tl.constexpr = BLK // 8

    # Load km vector once per (batch, head) — shape (C,), broadcast across all tokens
    km_ptr = Km + off_b * stride_kmz + off_h * stride_kmh + offs_k
    km_vec = tl.load(km_ptr).to(tl.float32)

    for wb in tl.static_range(0, NUM_WARP_BLKS):
        blk_idx = off_prog * NUM_WARP_BLKS + wb
        blk_start = blk_idx * BLK

        for tld in tl.static_range(0, 4):
            offs_n0 = blk_start + tl.arange(0, ROWS_PER_GROUP) * 8 + tld * 2
            offs_n1 = blk_start + tl.arange(0, ROWS_PER_GROUP) * 8 + tld * 2 + 1

            input_ptrs0 = base_in + offs_n0[:, None] * stride_in + offs_k[None, :]
            input_ptrs1 = base_in + offs_n1[:, None] * stride_in + offs_k[None, :]
            output_ptrs0 = base_out + offs_n0[:, None] * stride_on + offs_k[None, :]
            output_ptrs1 = base_out + offs_n1[:, None] * stride_on + offs_k[None, :]

            x0 = tl.load(input_ptrs0, mask=offs_n0[:, None] < L)
            x1 = tl.load(input_ptrs1, mask=offs_n1[:, None] < L)
            x0 = x0.to(tl.float32) - km_vec[None, :]
            x1 = x1.to(tl.float32) - km_vec[None, :]

            scale = max(tl.max(tl.abs(x0)), tl.max(tl.abs(x1))) / 127. + 0.0000001
            x0_int8 = x0 / scale
            x1_int8 = x1 / scale
            x0_int8 += 0.5 * tl.where(x0_int8 >= 0, 1, -1)
            x1_int8 += 0.5 * tl.where(x1_int8 >= 0, 1, -1)
            x0_int8 = x0_int8.to(tl.int8)
            x1_int8 = x1_int8.to(tl.int8)
            tl.store(output_ptrs0, x0_int8, mask=offs_n0[:, None] < L)
            tl.store(output_ptrs1, x1_int8, mask=offs_n1[:, None] < L)
            tl.store(scale_base + blk_idx * 4 + tld, scale)

def per_thread_int8(q, k, km=None, BLKQ=128, WARPQ=32, BLKK=64, WARPK=64, sm_scale=None, tensor_layout="HND", swizzle_k=False):
    q_int8 = torch.empty(q.shape, dtype=torch.int8, device=q.device)
    k_int8 = torch.empty(k.shape, dtype=torch.int8, device=k.device)

    if tensor_layout == "HND":
        if km is not None:
            k = k - km

        b, h_qo, qo_len, head_dim = q.shape
        _, h_kv, kv_len, _ = k.shape

        stride_bz_q, stride_h_q, stride_seq_q = q.stride(0), q.stride(1), q.stride(2)
        stride_bz_k, stride_h_k, stride_seq_k = k.stride(0), k.stride(1), k.stride(2)
        stride_bz_qo, stride_h_qo, stride_seq_qo = q_int8.stride(0), q_int8.stride(1), q_int8.stride(2)
        stride_bz_ko, stride_h_ko, stride_seq_ko = k_int8.stride(0), k_int8.stride(1), k_int8.stride(2)

        q_scale = torch.empty((b, h_qo, (qo_len + BLKQ - 1) // BLKQ * (BLKQ // WARPQ) * 8), device=q.device, dtype=torch.float32)
        k_scale = torch.empty((b, h_kv, (kv_len + BLKK - 1) // BLKK * (BLKK // WARPK) * 4), device=q.device, dtype=torch.float32)

        if sm_scale is None:
            sm_scale = head_dim**-0.5

        grid = ((qo_len + BLKQ - 1) // BLKQ * (BLKQ // WARPQ) * 8, h_qo, b)
        quant_query_per_thread_int8_kernel[grid](
            q, q_int8, q_scale, qo_len,
            stride_bz_q, stride_h_q, stride_seq_q,
            stride_bz_qo, stride_h_qo, stride_seq_qo,
            q_scale.stride(0), q_scale.stride(1),
            C=head_dim, BLK=WARPQ
        )

        grid = ((kv_len + BLKK - 1) // BLKK * (BLKK // WARPK) * 4, h_kv, b)
        quant_key_per_thread_int8_kernel[grid](
            k, k_int8, k_scale, kv_len,
            stride_bz_k, stride_h_k, stride_seq_k,
            stride_bz_ko, stride_h_ko, stride_seq_ko,
            k_scale.stride(0), k_scale.stride(1),
            C=head_dim, BLK=WARPK
        )

        return q_int8, q_scale, k_int8, k_scale

    elif tensor_layout == "NHD":
        b, qo_len, h_qo, head_dim = q.shape
        _, kv_len, h_kv, _ = k.shape

        # --- 删除原来的 k = k - km ---
        # if km is not None:
        #     k = k - km

        stride_bz_q, stride_h_q, stride_seq_q = q.stride(0), q.stride(2), q.stride(1)
        stride_bz_qo, stride_h_qo, stride_seq_qo = q_int8.stride(0), q_int8.stride(2), q_int8.stride(1)
        stride_bz_k, stride_h_k, stride_seq_k = k.stride(0), k.stride(2), k.stride(1)
        stride_bz_ko, stride_h_ko, stride_seq_ko = k_int8.stride(0), k_int8.stride(2), k_int8.stride(1)

        q_scale = torch.empty((b, h_qo, (qo_len + BLKQ - 1) // BLKQ * (BLKQ // WARPQ) * 8), device=q.device, dtype=torch.float32)
        k_scale = torch.empty((b, h_kv, (kv_len + BLKK - 1) // BLKK * (BLKK // WARPK) * 4), device=q.device, dtype=torch.float32)

        if sm_scale is None:
            sm_scale = head_dim**-0.5

        # --- Query: v2 fused kernel ---
        NUM_Q_WARP_BLKS = BLKQ // WARPQ
        num_q_programs = (qo_len + BLKQ - 1) // BLKQ
        grid = (num_q_programs, h_qo, b)
        quant_query_per_thread_int8_kernel_v2[grid](
            q, q_int8, q_scale, qo_len,
            stride_bz_q, stride_h_q, stride_seq_q,
            stride_bz_qo, stride_h_qo, stride_seq_qo,
            q_scale.stride(0), q_scale.stride(1),
            C=head_dim, BLK=WARPQ, NUM_WARP_BLKS=NUM_Q_WARP_BLKS,
            num_warps=1, num_stages=1,
        )

        # --- Key: fused km subtraction + quantization ---
        NUM_K_WARP_BLKS = BLKK // WARPK
        num_k_programs = (kv_len + BLKK - 1) // BLKK
        grid = (num_k_programs, h_kv, b)

        if km is not None:
            # km shape: (B, 1, H, D) for NHD layout
            # stride_kmz = km.stride(0), stride_kmh = km.stride(2) (head dim in NHD)
            if swizzle_k:
                quant_key_per_thread_int8_kernel_v2_fused_km_swizzle[grid](
                    k, k_int8, k_scale, km, kv_len,
                    stride_bz_k, stride_h_k, stride_seq_k,
                    stride_bz_ko, stride_h_ko, stride_seq_ko,
                    k_scale.stride(0), k_scale.stride(1),
                    km.stride(0), km.stride(2),
                    C=head_dim, BLK=WARPK, NUM_WARP_BLKS=NUM_K_WARP_BLKS,
                    num_warps=1, num_stages=1,
                )
            else:
                quant_key_per_thread_int8_kernel_v2_fused_km[grid](
                    k, k_int8, k_scale, km, kv_len,
                    stride_bz_k, stride_h_k, stride_seq_k,
                    stride_bz_ko, stride_h_ko, stride_seq_ko,
                    k_scale.stride(0), k_scale.stride(1),
                    km.stride(0), km.stride(2),
                    C=head_dim, BLK=WARPK, NUM_WARP_BLKS=NUM_K_WARP_BLKS,
                    num_warps=1, num_stages=1,
                )
        else:
            if swizzle_k:
                quant_key_per_thread_int8_kernel_v2_swizzle[grid](
                    k, k_int8, k_scale, kv_len,
                    stride_bz_k, stride_h_k, stride_seq_k,
                    stride_bz_ko, stride_h_ko, stride_seq_ko,
                    k_scale.stride(0), k_scale.stride(1),
                    C=head_dim, BLK=WARPK, NUM_WARP_BLKS=NUM_K_WARP_BLKS,
                    num_warps=1, num_stages=1,
                )
            else:
                quant_key_per_thread_int8_kernel_v2[grid](
                    k, k_int8, k_scale, kv_len,
                    stride_bz_k, stride_h_k, stride_seq_k,
                    stride_bz_ko, stride_h_ko, stride_seq_ko,
                    k_scale.stride(0), k_scale.stride(1),
                    C=head_dim, BLK=WARPK, NUM_WARP_BLKS=NUM_K_WARP_BLKS,
                    num_warps=1, num_stages=1,
                )

        return q_int8, q_scale, k_int8, k_scale

    else:
        raise ValueError(f"Unknown tensor layout: {tensor_layout}")

if __name__ == "__main__":
    B,H,S,D = 1,12,32760,128
    WARPQ = 16
    WARPK = 128
    q = torch.rand(B,S,H,D,dtype=torch.float16, device="cuda")
    k = torch.rand(B,S,H,D,dtype=torch.float16, device="cuda")
    km = k.mean(dim=1, keepdim=True)
    q_int8, q_scale, k_int8, k_scale = per_thread_int8(q, k, km, tensor_layout="NHD", BLKQ=64, WARPQ=WARPQ, BLKK=128, WARPK=WARPK)

    # q_scale_t = q_scale.reshape(batch, num_q_heads, seqlen_q//2, 1).expand(batch, num_q_heads, seqlen_q//2, 2).reshape(batch, num_q_heads, seqlen_q, 1)
    # k_scale_t = k_scale.reshape(batch, num_k_heads, seqlen_k//32, 1).expand(batch, num_k_heads, seqlen_k//32, 32).reshape(batch, num_k_heads, seqlen_k, 1)
    token_indices_q = torch.arange(S, device=q_int8.device)
    blk_idx_q = token_indices_q // WARPQ
    tld_idx_q = token_indices_q % 8  # off_tld = n % WARPQ % 8, and WARPQ >= 8
    scale_idx_q = blk_idx_q * 8 + tld_idx_q  # (qo_len,)

    # Gather scales: q_scale is (b, h_qo, num_scale_groups)
    # We need to index the last dim with scale_idx_q
    scale_idx_q_expanded = scale_idx_q.unsqueeze(0).unsqueeze(0).expand(B, H, -1)  # (b, h_qo, qo_len)
    q_scale_t = torch.gather(q_scale, dim=2, index=scale_idx_q_expanded)
    query_layer = q_int8 * q_scale_t.permute(0,2,1).unsqueeze(-1)

    token_indices_k = torch.arange(S, device=k_int8.device)
    blk_idx_k = token_indices_k // WARPK
    tld_idx_k = (token_indices_k % 8) // 2  # off_tld = (n % WARPK % 8) // 2
    scale_idx_k = blk_idx_k * 4 + tld_idx_k  # (kv_len,)

    scale_idx_k_expanded = scale_idx_k.unsqueeze(0).unsqueeze(0).expand(B, H, -1)  # (b, h_kv, kv_len)
    k_scale_t = torch.gather(k_scale, dim=2, index=scale_idx_k_expanded)
    key_layer = k_int8 * k_scale_t.permute(0,2,1).unsqueeze(-1) + km

    print(f"q Max error: {(q - query_layer).abs().max().item():.6f}")
    print(f"k Max error: {(k - key_layer).abs().max().item():.6f}")
    

    q_trans = q.permute(0,2,1,3).contiguous()
    k_trans = k.permute(0,2,1,3).contiguous()
    km_t = k_trans.mean(dim=2, keepdim=True)
    q_int8_t, q_scale_t, k_int8_t, k_scale_t = per_thread_int8(q_trans, k_trans, km_t, tensor_layout="HND", BLKQ=64, WARPQ=WARPQ, BLKK=128, WARPK=WARPK)

    print(f"q Max error: {(q_int8 - q_int8_t.permute(0,2,1,3)).abs().max().item():.6f}")
    print(f"k Max error: {(k_int8 - k_int8_t.permute(0,2,1,3)).abs().max().item():.6f}")

    def fn():
        return per_thread_int8(q, k, km, tensor_layout="NHD", BLKQ=64, WARPQ=16, BLKK=128, WARPK=128)

    ms = triton.testing.do_bench(fn)
    print(f"ms: {ms}")