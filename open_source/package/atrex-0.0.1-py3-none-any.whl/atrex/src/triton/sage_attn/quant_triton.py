import torch
import triton
import triton.language as tl

@triton.jit
def _quant_fp8_per_channel_swizzle_kernel(
    input_ptr,       # [B, H, D, padded_S] — S dim contiguous
    output_ptr,      # [B, H, D, padded_S] fp8, with swizzle applied
    scale_ptr,       # [B, H, D]
    num_tokens: tl.constexpr,
    padded_num_tokens: tl.constexpr,
    scale_max: tl.constexpr,
    stride_ib: tl.constexpr,
    stride_ih: tl.constexpr,
    stride_id: tl.constexpr,
    stride_is: tl.constexpr,
    stride_ob: tl.constexpr,
    stride_oh: tl.constexpr,
    stride_od: tl.constexpr,
    stride_os: tl.constexpr,
    stride_sb: tl.constexpr,
    stride_sh: tl.constexpr,
    stride_sd: tl.constexpr,
    BLOCK_S: tl.constexpr,
    SWIZZLE_BLOCK: tl.constexpr,  # 新增：对应 BLOCK_N
):
    """
    Per-channel FP8 quantization with fused swizzle on store.
    
    The swizzle remaps each SWIZZLE_BLOCK-element block in the S dimension:
      G = SWIZZLE_BLOCK // 8
      Original index within block: i = a*8 + b*4 + c  (a in [0,G), b in [0,2), c in [0,4))
      Swizzled index within block: j = b*(G*4) + a*4 + c
    
    This is equivalent to:
      reshape(..., padded_S//SWIZZLE_BLOCK, SWIZZLE_BLOCK//8, 2, 4)
      .permute(..., 5, 4, 6)
      .reshape(..., padded_S)
    """
    d_id = tl.program_id(axis=0)
    head_id = tl.program_id(axis=1)
    batch_id = tl.program_id(axis=2)

    input_base = (
        input_ptr
        + batch_id * stride_ib
        + head_id * stride_ih
        + d_id * stride_id
    )
    output_base = (
        output_ptr
        + batch_id * stride_ob
        + head_id * stride_oh
        + d_id * stride_od
    )

    # ===== Phase 1: Find max absolute value (unchanged) =====
    max_abs_val = 0.0
    for block_start in tl.range(0, num_tokens, BLOCK_S, num_stages=3):
        offsets = block_start + tl.arange(0, BLOCK_S)
        mask = offsets < num_tokens
        vals = tl.load(input_base + offsets * stride_is, mask=mask, other=0.0)
        abs_vals = tl.abs(vals)
        block_max = tl.max(abs_vals, axis=0)
        max_abs_val = tl.maximum(max_abs_val, block_max)

    # Compute scale
    safe_max = tl.maximum(max_abs_val, 1e-12)
    scale_val = safe_max / scale_max
    recp_scale = scale_max / safe_max

    # Store scale
    scale_addr = (
        scale_ptr
        + batch_id * stride_sb
        + head_id * stride_sh
        + d_id * stride_sd
    )
    tl.store(scale_addr, scale_val)

    # Precompute swizzle constants
    HALF_SWIZZLE: tl.constexpr = SWIZZLE_BLOCK // 2  # G * 4 = (SWIZZLE_BLOCK // 8) * 4

    # ===== Phase 2: Quantize with fused swizzle on store =====
    for block_start in tl.range(0, padded_num_tokens, BLOCK_S, num_stages=3):
        offsets = block_start + tl.arange(0, BLOCK_S)
        in_mask = offsets < num_tokens
        out_mask = offsets < padded_num_tokens

        vals = tl.load(input_base + offsets * stride_is, mask=in_mask, other=0.0)
        scaled_vals = vals * recp_scale
        fp8_vals = scaled_vals.to(tl.float8e4b8)

        # Compute swizzled output indices within each SWIZZLE_BLOCK-element block
        # Original: offset = block_of_N * N + a * 8 + b * 4 + c
        #   where a in [0, N//8), b in [0, 2), c in [0, 4)
        # Swizzled: offset = block_of_N * N + b * (N//2) + a * 4 + c
        block_of_n = offsets // SWIZZLE_BLOCK
        idx_in_block = offsets % SWIZZLE_BLOCK
        a = idx_in_block // 8        # [0, SWIZZLE_BLOCK//8)
        b = (idx_in_block % 8) // 4  # [0, 2)
        c = idx_in_block % 4         # [0, 4)
        swizzled_offsets = block_of_n * SWIZZLE_BLOCK + b * HALF_SWIZZLE + a * 4 + c

        tl.store(output_base + swizzled_offsets * stride_os, fp8_vals, mask=out_mask)



def quant_fp8_2d_tiled_swizzle_triton(
    input_tensor: torch.Tensor,
    output_tensor: torch.Tensor,
    scale_tensor: torch.Tensor,
    num_tokens: int,
    scale_max: float = 448.0,
    swizzle_block: int = 64,  # 新增参数
):
    batch_size, num_heads, head_dim, padded_len = input_tensor.shape
    BLOCK_S = 2048

    grid = lambda meta: (head_dim, num_heads, batch_size)

    _quant_fp8_per_channel_swizzle_kernel[grid](
        input_tensor,
        output_tensor,
        scale_tensor,
        num_tokens=num_tokens,
        padded_num_tokens=padded_len,
        scale_max=scale_max,
        stride_ib=input_tensor.stride(0),
        stride_ih=input_tensor.stride(1),
        stride_id=input_tensor.stride(2),
        stride_is=input_tensor.stride(3),
        stride_ob=output_tensor.stride(0),
        stride_oh=output_tensor.stride(1),
        stride_od=output_tensor.stride(2),
        stride_os=output_tensor.stride(3),
        stride_sb=scale_tensor.stride(0),
        stride_sh=scale_tensor.stride(1),
        stride_sd=scale_tensor.stride(2),
        BLOCK_S=BLOCK_S,
        SWIZZLE_BLOCK=swizzle_block,  # 新增
        num_warps=1,
        num_stages=4,
    )


def per_channel_fp8_swizzle_triton(
    v: torch.Tensor,
    tensor_layout: str = "HND",
    scale_max: float = 448.0,
    smooth_v: bool = True,
    swizzle_block: int = 64,  # 新增参数
):
    """
    Fused per-channel FP8 quantization + swizzle.
    Replaces per_channel_fp8_triton() + the subsequent reshape/permute/contiguous.
    """
    assert smooth_v is False, "only support smooth_v == False."

    if tensor_layout == "HND":
        b, h_kv, kv_len, head_dim = v.shape
    elif tensor_layout == "NHD":
        b, kv_len, h_kv, head_dim = v.shape
    else:
        raise ValueError(f"Unknown tensor_layout: {tensor_layout}")

    padded_len = (kv_len + 63) // 64 * 64

    # Step 1: Transpose via Triton kernel (reuse existing)
    v_transposed = torch.empty(
        (b, h_kv, head_dim, padded_len),
        dtype=v.dtype,
        device=v.device,
    )
    transpose_pad_triton_optimized(v, v_transposed, tensor_layout)

    # Step 2: Quantize with fused swizzle via Triton kernel
    v_fp8 = torch.empty(
        (b, h_kv, head_dim, padded_len),
        dtype=torch.float8_e4m3fnuz,
        device=v.device,
    )
    v_scale = torch.empty((b, h_kv, head_dim), dtype=torch.float32, device=v.device)
    quant_fp8_2d_tiled_swizzle_triton(v_transposed, v_fp8, v_scale, kv_len, scale_max, swizzle_block)

    return v_fp8, v_scale, None

# ============================================================
# Kernel 2: 2D Tiled Per-Channel FP8 Quantize Kernel
# 输入: [B, H, D, padded_S] (已转置，最后一维连续)
# 输出: [B, H, D, padded_S] (fp8)
# scale: [B, H, D]
# Grid: (cdiv(D, BLOCK_D), H, B)
# ============================================================

@triton.jit
def _quant_fp8_per_channel_fast_kernel(
    input_ptr,       # [B, H, D, padded_S] — S dim contiguous
    output_ptr,      # [B, H, D, padded_S] fp8
    scale_ptr,       # [B, H, D]
    num_tokens: tl.constexpr,
    padded_num_tokens: tl.constexpr,
    scale_max: tl.constexpr,
    stride_ib: tl.constexpr,
    stride_ih: tl.constexpr,
    stride_id: tl.constexpr,
    # stride_is is always 1 (contiguous), but keep for generality
    stride_is: tl.constexpr,
    stride_ob: tl.constexpr,
    stride_oh: tl.constexpr,
    stride_od: tl.constexpr,
    stride_os: tl.constexpr,
    stride_sb: tl.constexpr,
    stride_sh: tl.constexpr,
    stride_sd: tl.constexpr,
    BLOCK_S: tl.constexpr,
):
    """
    Ultra-optimized per-channel FP8 quantization.

    Grid: (D, H, B) — one program per channel.
    Each program processes a contiguous 1D vector of `num_tokens` elements.

    Key optimizations for MI308:
    1. 1D access pattern along contiguous dim → perfect coalescing
    2. Large BLOCK_S (1024-4096) to maximize memory throughput per iteration
    3. Software pipelining via tl.range(num_stages=N) to overlap
       load of next block with compute of current block
    4. Single warp (num_warps=1) to minimize sync overhead for this
       simple element-wise + reduction workload
    5. Minimal register pressure: only 1 channel, accumulate scalar max
    """
    d_id = tl.program_id(axis=0)
    head_id = tl.program_id(axis=1)
    batch_id = tl.program_id(axis=2)

    input_base = (
        input_ptr
        + batch_id * stride_ib
        + head_id * stride_ih
        + d_id * stride_id
    )
    output_base = (
        output_ptr
        + batch_id * stride_ob
        + head_id * stride_oh
        + d_id * stride_od
    )

    # ===== Phase 1: Find max absolute value =====
    # Use tl.range with num_stages for software pipelining:
    # while computing abs/max of current block, prefetch next block
    max_abs_val = 0.0

    for block_start in tl.range(0, num_tokens, BLOCK_S, num_stages=3):
        offsets = block_start + tl.arange(0, BLOCK_S)
        mask = offsets < num_tokens
        vals = tl.load(input_base + offsets * stride_is, mask=mask, other=0.0)
        abs_vals = tl.abs(vals)
        block_max = tl.max(abs_vals, axis=0)
        max_abs_val = tl.maximum(max_abs_val, block_max)

    # Compute scale
    safe_max = tl.maximum(max_abs_val, 1e-12)
    scale_val = safe_max / scale_max
    recp_scale = scale_max / safe_max

    # Store scale
    scale_addr = (
        scale_ptr
        + batch_id * stride_sb
        + head_id * stride_sh
        + d_id * stride_sd
    )
    tl.store(scale_addr, scale_val)

    # ===== Phase 2: Quantize =====
    # Again use software pipelining for the write pass
    for block_start in tl.range(0, padded_num_tokens, BLOCK_S, num_stages=3):
        offsets = block_start + tl.arange(0, BLOCK_S)
        in_mask = offsets < num_tokens
        out_mask = offsets < padded_num_tokens

        vals = tl.load(input_base + offsets * stride_is, mask=in_mask, other=0.0)
        scaled_vals = vals * recp_scale
        fp8_vals = scaled_vals.to(tl.float8e4b8)
        tl.store(output_base + offsets * stride_os, fp8_vals, mask=out_mask)


def quant_fp8_2d_tiled_triton(
    input_tensor: torch.Tensor,
    output_tensor: torch.Tensor,
    scale_tensor: torch.Tensor,
    num_tokens: int,
    scale_max: float = 448.0,
):
    """
    Ultra-optimized per-channel FP8 quantization for MI308.

    Input: [B, H, D, padded_S] (already transposed, S dim contiguous)

    Performance characteristics:
    - Grid: B*H*D programs (e.g. 1*12*128 = 1536)
    - Each program: 1D streaming over contiguous tokens
    - Software pipelining (num_stages=3) hides memory latency
    - BLOCK_S=2048: each iteration processes 2048 contiguous fp16 = 4KB
      → 64 cache lines per iteration, saturates MI308 memory controller
    - num_warps=2: 2 wavefronts, enough for the simple compute
    - Total HBM traffic: 2× read + 1× write (fp8) = ~2.5× data size
      (theoretical minimum for two-pass algorithm)
    """
    batch_size, num_heads, head_dim, padded_len = input_tensor.shape

    # MI308 tuning:
    # - BLOCK_S=2048: sweet spot for 1D streaming on MI308
    #   2048 * 2B (fp16) = 4KB per load, good for HBM burst
    # - num_warps=2: minimal warps, each wavefront=64 threads
    #   handles 2048/64=32 elements per thread, low register pressure
    # - num_stages=3: triple-buffer for load/compute/store overlap
    BLOCK_S = 2048

    grid = lambda meta: (head_dim, num_heads, batch_size)

    _quant_fp8_per_channel_fast_kernel[grid](
        input_tensor,
        output_tensor,
        scale_tensor,
        num_tokens=num_tokens,
        padded_num_tokens=padded_len,
        scale_max=scale_max,
        stride_ib=input_tensor.stride(0),
        stride_ih=input_tensor.stride(1),
        stride_id=input_tensor.stride(2),
        stride_is=input_tensor.stride(3),
        stride_ob=output_tensor.stride(0),
        stride_oh=output_tensor.stride(1),
        stride_od=output_tensor.stride(2),
        stride_os=output_tensor.stride(3),
        stride_sb=scale_tensor.stride(0),
        stride_sh=scale_tensor.stride(1),
        stride_sd=scale_tensor.stride(2),
        BLOCK_S=BLOCK_S,
        num_warps=1,
        num_stages=4,
    )

@triton.jit
def _transpose_pad_optimized_kernel(
    input_ptr,       # [B, S, H, D] — D dim contiguous (stride=1)
    output_ptr,      # [B, H, D, padded_S] — S dim contiguous (stride=1)
    num_tokens: tl.constexpr,
    padded_num_tokens: tl.constexpr,
    head_dim: tl.constexpr,
    stride_ib: tl.constexpr,
    stride_is: tl.constexpr,
    stride_ih: tl.constexpr,
    stride_id: tl.constexpr,
    stride_ob: tl.constexpr,
    stride_oh: tl.constexpr,
    stride_od: tl.constexpr,
    stride_os: tl.constexpr,
    NUM_S_BLOCKS: tl.constexpr,
    BLOCK_S: tl.constexpr,
    BLOCK_D: tl.constexpr,
):
    """
    Optimized transpose: [B, S, H, D] → [B, H, D, padded_S]

    Grid: (cdiv(padded_S, BLOCK_S) * cdiv(D, BLOCK_D), H, B)
    axis=0 encodes both s_block and d_block (flattened).

    Each program loads a [BLOCK_S, BLOCK_D] tile from input and
    stores it transposed to output.

    Memory access pattern:
    - READ:  input[b, s_offsets, h, d_offsets]
             d_offsets is contiguous (stride_id=1)
             → each wavefront reads BLOCK_D consecutive fp16 per row → coalesced
    - WRITE: output[b, h, d_offsets, s_offsets]
             s_offsets is contiguous (stride_os=1)
             → each wavefront writes BLOCK_S consecutive fp16 per row → coalesced

    The tile is loaded as [BLOCK_S, BLOCK_D] and stored with swapped indices,
    achieving an in-register transpose. Triton compiler will use LDS for
    the transpose if needed.

    MI308 tuning:
    - BLOCK_S=32, BLOCK_D=32: small tile for low register pressure
      32*32*2B = 2KB per tile, fits easily in registers
    - num_warps=4: 256 threads, each handles a portion of the 32×32 tile
    - Grid is large enough (S/32 * D/32 * H * B) for good CU occupancy
    """
    sd_block_id = tl.program_id(axis=0)
    head_id = tl.program_id(axis=1)
    batch_id = tl.program_id(axis=2)

    # Decode s_block and d_block from flattened index
    s_block_id = sd_block_id % NUM_S_BLOCKS
    d_block_id = sd_block_id // NUM_S_BLOCKS

    s_start = s_block_id * BLOCK_S
    d_start = d_block_id * BLOCK_D

    s_offsets = s_start + tl.arange(0, BLOCK_S)
    d_offsets = d_start + tl.arange(0, BLOCK_D)

    s_in_mask = s_offsets < num_tokens
    s_out_mask = s_offsets < padded_num_tokens
    d_mask = d_offsets < head_dim

    # ===== Load [BLOCK_S, BLOCK_D] from input =====
    # input[batch, s, head, d]: d contiguous → coalesced read along d
    in_ptrs = (
        input_ptr
        + batch_id * stride_ib
        + head_id * stride_ih
        + s_offsets[:, None] * stride_is
        + d_offsets[None, :] * stride_id
    )
    tile = tl.load(
        in_ptrs,
        mask=s_in_mask[:, None] & d_mask[None, :],
        other=0.0,
    )

    # ===== Store transposed: write [BLOCK_S, BLOCK_D] with swapped output indices =====
    # output[batch, head, d, s]: s contiguous → coalesced write along s
    # We store tile[s, d] at output position [d, s]
    # Using the same tile shape [BLOCK_S, BLOCK_D] but mapping to output as:
    #   out_ptr[d_offsets[j], s_offsets[i]] = tile[i, j]
    # This is equivalent to:
    out_ptrs = (
        output_ptr
        + batch_id * stride_ob
        + head_id * stride_oh
        + d_offsets[None, :] * stride_od   # d selects row in output
        + s_offsets[:, None] * stride_os    # s selects col in output
    )
    tl.store(
        out_ptrs,
        tile,
        mask=s_out_mask[:, None] & d_mask[None, :],
    )


def transpose_pad_triton_optimized(
    input_tensor: torch.Tensor,
    output_tensor: torch.Tensor,
    tensor_layout: str = "NHD",
):
    """
    Optimized transpose: [B, S, H, D] → [B, H, D, padded_S]

    Uses tiled transpose with coalesced reads AND writes.
    """
    if tensor_layout == "NHD":
        b, kv_len, h_kv, head_dim = input_tensor.shape
        si_b, si_s, si_h, si_d = (
            input_tensor.stride(0), input_tensor.stride(1),
            input_tensor.stride(2), input_tensor.stride(3),
        )
    elif tensor_layout == "HND":
        b, h_kv, kv_len, head_dim = input_tensor.shape
        si_b, si_h, si_s, si_d = (
            input_tensor.stride(0), input_tensor.stride(1),
            input_tensor.stride(2), input_tensor.stride(3),
        )
    else:
        raise ValueError(f"Unknown tensor_layout: {tensor_layout}")

    padded_len = output_tensor.shape[-1]

    # ---- MI308 tile size tuning ----
    #
    # Classic transpose optimization: tile must be square-ish so that
    # both read (along D) and write (along S) are coalesced.
    #
    # H20 CUDA uses shared memory tiles (typically 32×32 or 32×64).
    # We match with BLOCK_S=32, BLOCK_D=32.
    #
    # For B=1, H=12, D=128, S=32768:
    #   Grid = (32768/32 * 128/32) * 12 * 1 = 1024 * 4 * 12 = 49152 programs
    #   MI308 has 304 CUs, each can run multiple programs → excellent occupancy
    #
    # Tile size 32×32 = 1024 elements × 2B = 2KB
    #   → very low register pressure, high occupancy
    BLOCK_S = 32
    BLOCK_D = 32

    num_s_blocks = triton.cdiv(padded_len, BLOCK_S)
    num_d_blocks = triton.cdiv(head_dim, BLOCK_D)

    grid = lambda meta: (num_s_blocks * num_d_blocks, h_kv, b)

    _transpose_pad_optimized_kernel[grid](
        input_tensor, output_tensor,
        num_tokens=kv_len,
        padded_num_tokens=padded_len,
        head_dim=head_dim,
        stride_ib=si_b, stride_is=si_s, stride_ih=si_h, stride_id=si_d,
        stride_ob=output_tensor.stride(0),
        stride_oh=output_tensor.stride(1),
        stride_od=output_tensor.stride(2),
        stride_os=output_tensor.stride(3),
        NUM_S_BLOCKS=num_s_blocks,
        BLOCK_S=BLOCK_S,
        BLOCK_D=BLOCK_D,
        num_warps=4,
        num_stages=1,
    )

# ============================================================
# 拆分版 per_channel_fp8: Transpose + Quantize 分开调用
# ============================================================

def per_channel_fp8_triton(
    v: torch.Tensor,
    tensor_layout: str = "HND",
    scale_max: float = 448.0,
    smooth_v: bool = True,
):
    """
    Split version: separate transpose kernel + quantize kernel.
    For benchmarking against the fused version.
    """
    assert smooth_v is False, "only support smooth_v == False."

    if tensor_layout == "HND":
        b, h_kv, kv_len, head_dim = v.shape
    elif tensor_layout == "NHD":
        b, kv_len, h_kv, head_dim = v.shape
    else:
        raise ValueError(f"Unknown tensor_layout: {tensor_layout}")

    padded_len = (kv_len + 63) // 64 * 64

    # Step 1: Transpose via Triton kernel
    v_transposed = torch.empty(
        (b, h_kv, head_dim, padded_len),
        dtype=v.dtype,
        device=v.device,
    )
    transpose_pad_triton_optimized(v, v_transposed, tensor_layout)

    # Step 2: Quantize via Triton kernel
    v_fp8 = torch.empty(
        (b, h_kv, head_dim, padded_len),
        dtype=torch.float8_e4m3fnuz,
        device=v.device,
    )
    v_scale = torch.empty((b, h_kv, head_dim), dtype=torch.float32, device=v.device)
    quant_fp8_2d_tiled_triton(v_transposed, v_fp8, v_scale, kv_len, scale_max)

    # v_dequant = v_fp8.to(torch.float16) * v_scale.unsqueeze(3)
    # print(f"Max error: {(v_transposed - v_dequant).abs().max().item():.6f}")

    # def fn():
    #     return quant_fp8_2d_tiled_triton(v_transposed, v_fp8, v_scale, kv_len, scale_max)

    # ms = triton.testing.do_bench(fn)
    # print(f"ms: {ms}")

    return v_fp8, v_scale, None

if __name__ == "__main__":
    B, H, S, D = 1, 12, 32760, 128
    y = torch.randn(B, S, H, D, dtype=torch.float16, device="cuda")

    def fn():
        return per_channel_fp8_triton(
            y,
            tensor_layout= "NHD",
            scale_max=240.0,
            smooth_v= False
        )

    ms = triton.testing.do_bench(fn)
    print(f"ms: {ms}")

    def fn():
        return per_channel_fp8_swizzle_triton(
            y,
            tensor_layout= "NHD",
            scale_max=240.0,
            smooth_v= False
        )
    
    ms = triton.testing.do_bench(fn)
    print(f"ms: {ms}")