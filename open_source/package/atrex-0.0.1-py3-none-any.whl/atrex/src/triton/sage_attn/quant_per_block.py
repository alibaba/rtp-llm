"""
Copyright (c) 2024 by SageAttention team.

Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

    http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.
"""

import torch
import triton
import triton.language as tl
from .quant_per_thread import quant_query_per_thread_int8_kernel_v2

@triton.jit
def quant_per_block_int8_kernel_fused_km(
    Input, Output, Scale, Km, L,
    stride_iz, stride_ih, stride_in,
    stride_oz, stride_oh, stride_on,
    stride_sz, stride_sh,
    stride_kmz, stride_kmh,
    sm_scale,
    C: tl.constexpr, BLK: tl.constexpr):
    """
    Fused: km subtraction + per-block int8 quantization.
    Same structure as quant_per_block_int8_kernel, with km subtraction fused in.
    No swizzle — output layout is identical to original kernel (contiguous stores).
    """
    off_blk = tl.program_id(0)
    off_h = tl.program_id(1)
    off_b = tl.program_id(2)

    offs_n = off_blk * BLK + tl.arange(0, BLK)
    offs_k = tl.arange(0, C)

    input_ptrs = Input + off_b * stride_iz + off_h * stride_ih + offs_n[:, None] * stride_in + offs_k[None, :]
    output_ptrs = Output + off_b * stride_oz + off_h * stride_oh + offs_n[:, None] * stride_on + offs_k[None, :]
    scale_ptrs = Scale + off_b * stride_sz + off_h * stride_sh + off_blk

    # Load km vector once
    km_ptr = Km + off_b * stride_kmz + off_h * stride_kmh + offs_k
    km_vec = tl.load(km_ptr).to(tl.float32)

    x = tl.load(input_ptrs, mask=offs_n[:, None] < L)
    x = x.to(tl.float32)
    x -= km_vec[None, :]
    x *= sm_scale
    scale = tl.max(tl.abs(x)) / 127.
    x_int8 = x / scale
    x_int8 += 0.5 * tl.where(x_int8 >= 0, 1, -1)
    x_int8 = x_int8.to(tl.int8)
    tl.store(output_ptrs, x_int8, mask=offs_n[:, None] < L)
    tl.store(scale_ptrs, scale)



@triton.jit
def quant_per_block_int8_kernel_swizzle(
    Input, Output, Scale, L,
    stride_iz, stride_ih, stride_in,
    stride_oz, stride_oh, stride_on,
    stride_sz, stride_sh,
    sm_scale,
    C: tl.constexpr, BLK: tl.constexpr,
    ROWS_PER_ITER: tl.constexpr,
):
    """
    Per-block int8 quantization + head_dim swizzle (no km subtraction).
    Same two-pass structure for consistency.
    """
    off_blk = tl.program_id(0)
    off_h = tl.program_id(1)
    off_b = tl.program_id(2)

    base_in = Input + off_b * stride_iz + off_h * stride_ih
    base_out = Output + off_b * stride_oz + off_h * stride_oh
    scale_ptr = Scale + off_b * stride_sz + off_h * stride_sh + off_blk

    offs_k = tl.arange(0, C)
    a = offs_k // 8
    b = (offs_k % 8) // 4
    c = offs_k % 4
    offs_k_swizzled = b * 64 + a * 4 + c

    blk_start = off_blk * BLK
    NUM_ITERS: tl.constexpr = BLK // ROWS_PER_ITER

    global_max = tl.full([1], 0.0, dtype=tl.float32)
    for i in tl.static_range(0, NUM_ITERS):
        offs_n = blk_start + i * ROWS_PER_ITER + tl.arange(0, ROWS_PER_ITER)
        input_ptrs = base_in + offs_n[:, None] * stride_in + offs_k[None, :]
        x = tl.load(input_ptrs, mask=offs_n[:, None] < L, other=0.0)
        x = x.to(tl.float32) * sm_scale
        global_max = tl.maximum(global_max, tl.max(tl.abs(x)))

    scale = global_max / 127.0 + 1e-7
    inv_scale = 1.0 / scale

    for i in tl.static_range(0, NUM_ITERS):
        offs_n = blk_start + i * ROWS_PER_ITER + tl.arange(0, ROWS_PER_ITER)
        input_ptrs = base_in + offs_n[:, None] * stride_in + offs_k[None, :]
        output_ptrs = base_out + offs_n[:, None] * stride_on + offs_k_swizzled[None, :]

        x = tl.load(input_ptrs, mask=offs_n[:, None] < L, other=0.0)
        x = x.to(tl.float32) * sm_scale
        x_int8 = x * inv_scale
        x_int8 += 0.5 * tl.where(x_int8 >= 0, 1, -1)
        x_int8 = x_int8.to(tl.int8)
        tl.store(output_ptrs, x_int8, mask=offs_n[:, None] < L)

    tl.store(scale_ptr, scale)

@triton.jit
def quant_per_block_int8_kernel(Input, Output, Scale, L,
                                stride_iz, stride_ih, stride_in,
                                stride_oz, stride_oh, stride_on,
                                stride_sz, stride_sh,
                                sm_scale,
                                C: tl.constexpr, BLK: tl.constexpr):
    off_blk = tl.program_id(0)
    off_h = tl.program_id(1)
    off_b = tl.program_id(2)

    offs_n = off_blk * BLK + tl.arange(0, BLK)
    offs_k = tl.arange(0, C)

    input_ptrs = Input + off_b * stride_iz + off_h * stride_ih + offs_n[:, None] * stride_in + offs_k[None, :]
    output_ptrs = Output + off_b * stride_oz + off_h * stride_oh + offs_n[:, None] * stride_on + offs_k[None, :]
    scale_ptrs = Scale + off_b * stride_sz + off_h * stride_sh + off_blk

    x = tl.load(input_ptrs, mask=offs_n[:, None] < L)
    x = x.to(tl.float32)
    x *= sm_scale
    scale = tl.max(tl.abs(x)) / 127.
    x_int8 = x / scale
    x_int8 += 0.5 * tl.where(x_int8 >= 0, 1, -1)
    x_int8 = x_int8.to(tl.int8)
    tl.store(output_ptrs, x_int8, mask=offs_n[:, None] < L)
    tl.store(scale_ptrs, scale)

def per_block_int8(q, k, km=None, BLKQ=128, BLKK=64, sm_scale=None, tensor_layout="HND"):
    q_int8 = torch.empty(q.shape, dtype=torch.int8, device=q.device)
    k_int8 = torch.empty(k.shape, dtype=torch.int8, device=k.device)

    if km is not None:
        k = k - km

    if tensor_layout == "HND":
        b, h_qo, qo_len, head_dim = q.shape
        _, h_kv, kv_len, _ = k.shape

        stride_bz_q, stride_h_q, stride_seq_q = q.stride(0), q.stride(1), q.stride(2)
        stride_bz_qo, stride_h_qo, stride_seq_qo = q_int8.stride(0), q_int8.stride(1), q_int8.stride(2)
        stride_bz_k, stride_h_k, stride_seq_k = k.stride(0), k.stride(1), k.stride(2)
        stride_bz_ko, stride_h_ko, stride_seq_ko = k_int8.stride(0), k_int8.stride(1), k_int8.stride(2)
    elif tensor_layout == "NHD":
        b, qo_len, h_qo, head_dim = q.shape
        _, kv_len, h_kv, _ = k.shape

        stride_bz_q, stride_h_q, stride_seq_q = q.stride(0), q.stride(2), q.stride(1)
        stride_bz_qo, stride_h_qo, stride_seq_qo = q_int8.stride(0), q_int8.stride(2), q_int8.stride(1)
        stride_bz_k, stride_h_k, stride_seq_k = k.stride(0), k.stride(2), k.stride(1)
        stride_bz_ko, stride_h_ko, stride_seq_ko = k_int8.stride(0), k_int8.stride(2), k_int8.stride(1)
    else:
        raise ValueError(f"Unknown tensor layout: {tensor_layout}")

    q_scale = torch.empty((b, h_qo, (qo_len + BLKQ - 1) // BLKQ), device=q.device, dtype=torch.float32)
    k_scale = torch.empty((b, h_kv, (kv_len + BLKK - 1) // BLKK), device=q.device, dtype=torch.float32)

    if sm_scale is None:
        sm_scale = head_dim**-0.5

    grid = ((qo_len + BLKQ - 1) // BLKQ, h_qo, b)
    quant_per_block_int8_kernel[grid](
        q, q_int8, q_scale, qo_len,
        stride_bz_q, stride_h_q, stride_seq_q,
        stride_bz_qo, stride_h_qo, stride_seq_qo,
        q_scale.stride(0), q_scale.stride(1),
        sm_scale=(sm_scale * 1.44269504),
        C=head_dim, BLK=BLKQ
    )

    grid = ((kv_len + BLKK - 1) // BLKK, h_kv, b)
    quant_per_block_int8_kernel[grid](
        k, k_int8, k_scale, kv_len,
        stride_bz_k, stride_h_k, stride_seq_k,
        stride_bz_ko, stride_h_ko, stride_seq_ko,
        k_scale.stride(0), k_scale.stride(1),
        sm_scale=1.0,
        C=head_dim, BLK=BLKK
    )

    return q_int8, q_scale, k_int8, k_scale

def per_thread_block_int8(q, k, km=None, BLKQ=128, BLKK=64, WARPQ=16, sm_scale=None, tensor_layout="HND"):
    q_int8 = torch.empty(q.shape, dtype=torch.int8, device=q.device)
    k_int8 = torch.empty(k.shape, dtype=torch.int8, device=k.device)
    assert tensor_layout == 'NHD', "per_thread_block_int8 only support NHD"

    # k-km is now fused into the kernel — do NOT subtract here

    if tensor_layout == "NHD":
        b, qo_len, h_qo, head_dim = q.shape
        _, kv_len, h_kv, _ = k.shape

        stride_bz_q, stride_h_q, stride_seq_q = q.stride(0), q.stride(2), q.stride(1)
        stride_bz_qo, stride_h_qo, stride_seq_qo = q_int8.stride(0), q_int8.stride(2), q_int8.stride(1)
        stride_bz_k, stride_h_k, stride_seq_k = k.stride(0), k.stride(2), k.stride(1)
        stride_bz_ko, stride_h_ko, stride_seq_ko = k_int8.stride(0), k_int8.stride(2), k_int8.stride(1)
    else:
        raise ValueError(f"per_thread_block_int8 only supports NHD, got {tensor_layout}")

    q_scale = torch.empty((b, h_qo, (qo_len + BLKQ - 1) // BLKQ * (BLKQ // WARPQ) * 8), device=q.device, dtype=torch.float32)
    k_scale = torch.empty((b, h_kv, (kv_len + BLKK - 1) // BLKK), device=q.device, dtype=torch.float32)

    if sm_scale is None:
        sm_scale = head_dim**-0.5

    # ---- Q quantization (unchanged) ----
    NUM_Q_WARP_BLKS = BLKQ // WARPQ
    num_q_programs = (qo_len + BLKQ - 1) // BLKQ
    grid = (num_q_programs, h_qo, b)
    quant_query_per_thread_int8_kernel_v2[grid](
        q, q_int8, q_scale, qo_len,
        stride_bz_q, stride_h_q, stride_seq_q,
        stride_bz_qo, stride_h_qo, stride_seq_qo,
        q_scale.stride(0), q_scale.stride(1),
        C=head_dim, BLK=WARPQ, NUM_WARP_BLKS=NUM_Q_WARP_BLKS,
        num_warps=1, num_stages=1,
    )

    # ---- K quantization: fused km + per-block quantize (no swizzle) ----
    grid = ((kv_len + BLKK - 1) // BLKK, h_kv, b)
    if km is not None:
        km_squeezed = km.squeeze(1)  # [b, 1, h_kv, D] -> [b, h_kv, D]
        quant_per_block_int8_kernel_fused_km[grid](
            k, k_int8, k_scale, km_squeezed, kv_len,
            stride_bz_k, stride_h_k, stride_seq_k,
            stride_bz_ko, stride_h_ko, stride_seq_ko,
            k_scale.stride(0), k_scale.stride(1),
            km_squeezed.stride(0), km_squeezed.stride(1),
            sm_scale=1.0,
            C=head_dim, BLK=BLKK
        )
    else:
        quant_per_block_int8_kernel[grid](
            k, k_int8, k_scale, kv_len,
            stride_bz_k, stride_h_k, stride_seq_k,
            stride_bz_ko, stride_h_ko, stride_seq_ko,
            k_scale.stride(0), k_scale.stride(1),
            sm_scale=1.0,
            C=head_dim, BLK=BLKK
        )

    return q_int8, q_scale, k_int8, k_scale

if __name__ == "__main__":
    B, H, S, D = 1, 12, 32760, 128
    q = torch.randn(B, S, H, D, dtype=torch.float16, device="cuda")
    k = torch.randn(B, S, H, D, dtype=torch.float16, device="cuda")

    km = k.mean(dim=1, keepdim=True)

    def fn():
        return per_thread_block_int8(q, k, km=km, BLKQ=128, BLKK=128, WARPQ=16, sm_scale=None, tensor_layout="NHD")
    
    ms = triton.testing.do_bench(fn)
    print(f"ms: {ms}")