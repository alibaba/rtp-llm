"""
Copyright (c) 2024 by SageAttention team.

Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

    http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.
"""

import torch, math
import triton
import triton.language as tl

@triton.jit
def _attn_fwd_inner(acc, l_i, m_i, q, q_scale, sm_scale_log2, qo_len, kv_len,
                    K_ptrs, K_scale_ptr, V_base, stride_vn, stride_vd, stride_kn,
                    start_m, mask_ptrs, stride_maskn,
                    k_scale_indices, v_perm_offsets,
                    BLOCK_M: tl.constexpr, HEAD_DIM: tl.constexpr, BLOCK_N: tl.constexpr,
                    STAGE: tl.constexpr, offs_m: tl.constexpr, offs_n: tl.constexpr,
                    NUM_K_SCALES_PER_BLK: tl.constexpr,
                    ):
    lo, hi = 0, kv_len
    offs_k = tl.arange(0, HEAD_DIM)
    for start_n in range(lo, hi, BLOCK_N):
        start_n = tl.multiple_of(start_n, BLOCK_N)

        mask_block = None
        skip = False
        if mask_ptrs is not None:
            if mask_ptrs.dtype.element_ty == tl.int1:
                mask_block = tl.load(mask_ptrs + start_n * stride_maskn, mask=(offs_m[:, None] < qo_len) & (offs_n[None, :] < kv_len - start_n), other=False)
                if tl.max(mask_block) == 0:
                    skip = True
            else:
                mask_block = tl.load(mask_ptrs + start_n * stride_maskn, mask=(offs_m[:, None] < qo_len) & (offs_n[None, :] < kv_len - start_n), other=-1.0e6)

        if not skip:
            k_mask = offs_n[None, :] < (kv_len - start_n)
            k = tl.load(K_ptrs, mask=k_mask)

            # Map each column in BLOCK_N to its k_scale via precomputed indices
            k_scale_per_col = tl.load(K_scale_ptr + k_scale_indices)

            qk = tl.dot(q, k).to(tl.float32)
            # Apply per-row q_scale, per-col k_scale, and sm_scale*log2(e) to convert to log2 space
            qk = qk * q_scale[:, None] * k_scale_per_col[None, :] * sm_scale_log2

            if mask_block is not None:
                if mask_block.dtype == tl.int1:
                    qk = qk + tl.where(mask_block, 0, -1.0e6)
                else:
                    qk = qk + mask_block
            else:
                qk += tl.where(k_mask, 0, -1.0e6)

            m_ij = tl.maximum(m_i, tl.max(qk, 1))
            qk = qk - m_ij[:, None]
            p = tl.math.exp2(qk)
            l_ij = tl.sum(p, 1)

            alpha = tl.math.exp2(m_i - m_ij)
            l_i = l_i * alpha + l_ij

            acc = acc * alpha[:, None]

            # Load V with permuted indices to undo transpose_pad_permute's permutation
            v_actual_offs = start_n + v_perm_offsets
            V_ptrs = V_base + v_actual_offs[:, None] * stride_vn + offs_k[None, :] * stride_vd
            v = tl.load(V_ptrs, mask=v_actual_offs[:, None] < kv_len)
            p = p.to(v.dtype)

            acc += tl.dot(p, v, out_dtype=tl.float32)
            m_i = m_ij

        K_ptrs += BLOCK_N * stride_kn
        K_scale_ptr += NUM_K_SCALES_PER_BLK
    return acc, l_i, m_i

@triton.jit
def _attn_fwd(Q, K, V, Q_scale, K_scale, V_scale, Out, mask, Lse,
              stride_qz, stride_qh, stride_qn,
              stride_kz, stride_kh, stride_kn,
              stride_vz, stride_vh, stride_vn, stride_vd,
              stride_oz, stride_oh, stride_on,
              stride_maskz, stride_maskh, stride_maskm, stride_maskn,
              stride_qs_z, stride_qs_h,
              stride_ks_z, stride_ks_h,
              sm_scale_log2,
              qo_len, kv_len, H: tl.constexpr, num_kv_groups: tl.constexpr,
              HEAD_DIM: tl.constexpr,
              BLOCK_M: tl.constexpr,
              BLOCK_N: tl.constexpr,
              STAGE: tl.constexpr,
              RETURN_LSE: tl.constexpr,
              WARPQ: tl.constexpr,
              WARPK: tl.constexpr,
              NUM_Q_SCALES_PER_BLK: tl.constexpr,
              NUM_K_SCALES_PER_BLK: tl.constexpr,
              ):
    start_m = tl.program_id(0)

    off_z = tl.program_id(2).to(tl.int64)
    off_h = tl.program_id(1).to(tl.int64)

    # Per-thread scale offsets using actual strides from the scale tensors
    q_scale_base = off_z * stride_qs_z + off_h * stride_qs_h
    k_scale_base = off_z * stride_ks_z + (off_h // num_kv_groups) * stride_ks_h

    v_scale_offset = (off_z * H + off_h) * HEAD_DIM + tl.arange(0, HEAD_DIM)

    offs_m = start_m * BLOCK_M + tl.arange(0, BLOCK_M)
    offs_n = tl.arange(0, BLOCK_N)
    offs_k = tl.arange(0, HEAD_DIM)
    Q_ptrs = Q + (off_z * stride_qz + off_h * stride_qh) + offs_m[:, None] * stride_qn + offs_k[None, :]
    K_ptrs = K + (off_z * stride_kz + (off_h // num_kv_groups) * stride_kh) + offs_n[None, :] * stride_kn + offs_k[:, None]
    O_block_ptr = Out + (off_z * stride_oz + off_h * stride_oh) + offs_m[:, None] * stride_on + offs_k[None, :]
    V_scale_ptr = V_scale + v_scale_offset

    # Build per-row q_scale indices within a BLOCK_M block
    # In quant_query_per_thread_int8_kernel (WARPQ=16, 8 threads per warp block):
    #   row r in warp block wb => scale index = wb * 8 + (r % 8)
    #   where wb = (r_in_block) // WARPQ, r_in_block % 8 = thread id
    local_m = tl.arange(0, BLOCK_M)
    q_warp_block = local_m // WARPQ
    q_thread_id = local_m % 8
    q_scale_local_indices = q_warp_block * 8 + q_thread_id

    # Build per-col k_scale indices within a BLOCK_N block
    # In quant_key_per_thread_int8_kernel (WARPK=128, 4 threads per warp block):
    #   col c in warp block wb => scale index = wb * 4 + (c % 8) // 2
    local_n = tl.arange(0, BLOCK_N)
    k_warp_block = local_n // WARPK
    k_thread_id = (local_n % 8) // 2
    k_scale_local_indices = k_warp_block * 4 + k_thread_id

    # Build V permutation offsets to undo transpose_pad_permute's permutation
    # The permutation is applied per CTA of 64 tokens, in groups of 16:
    #   forward_perm(idx) = (b3<<3)|(b0<<2)|(b2<<1)|b1
    # where b0..b3 are bits of (idx % 16).
    # V was stored at permuted positions, so to load original token j we need
    # to load from position forward_perm(j).
    v_cta_offset = local_n % 64
    v_block_16_id = v_cta_offset // 16
    v_in_block = v_cta_offset % 16
    v_b0 = v_in_block & 1
    v_b1 = (v_in_block >> 1) & 1
    v_b2 = (v_in_block >> 2) & 1
    v_b3 = (v_in_block >> 3) & 1
    v_permuted_in_block = (v_b3 << 3) | (v_b0 << 2) | (v_b2 << 1) | v_b1
    v_perm_offsets = (local_n // 64) * 64 + v_block_16_id * 16 + v_permuted_in_block

    # Load per-row q_scale for this Q block: [BLOCK_M]
    Q_scale_ptr = Q_scale + q_scale_base + start_m * NUM_Q_SCALES_PER_BLK
    q_scale_vec = tl.load(Q_scale_ptr + q_scale_local_indices)

    # K_scale pointer for the first KV block
    K_scale_ptr = K_scale + k_scale_base

    # V base pointer (without seq offset, will be computed per iteration with permuted indices)
    V_base = V + (off_z * stride_vz + (off_h // num_kv_groups) * stride_vh)

    if mask is None:
        mask_ptrs = None
    else:
        mask_ptrs = mask + (off_z * stride_maskz + off_h * stride_maskh) + offs_m[:, None] * stride_maskm + offs_n[None, :] * stride_maskn

    m_i = tl.zeros([BLOCK_M], dtype=tl.float32) - float("inf")
    l_i = tl.zeros([BLOCK_M], dtype=tl.float32) + 1.0
    acc = tl.zeros([BLOCK_M, HEAD_DIM], dtype=tl.float32)

    q = tl.load(Q_ptrs, mask=offs_m[:, None] < qo_len)
    acc, l_i, m_i = _attn_fwd_inner(acc, l_i, m_i, q, q_scale_vec, sm_scale_log2, qo_len, kv_len,
                                    K_ptrs, K_scale_ptr, V_base, stride_vn, stride_vd, stride_kn,
                                    start_m, mask_ptrs, stride_maskn,
                                    k_scale_local_indices, v_perm_offsets,
                                    BLOCK_M, HEAD_DIM, BLOCK_N,
                                    4 - STAGE, offs_m, offs_n,
                                    NUM_K_SCALES_PER_BLK,
                                    )
    v_scale_ = tl.load(V_scale_ptr)
    acc = acc / l_i[:, None]
    acc = acc * v_scale_[None, :]
    tl.store(O_block_ptr, acc.to(Out.type.element_ty), mask=(offs_m[:, None] < qo_len))

    if RETURN_LSE:
        lse_ptrs = Lse + (off_z * qo_len * H + off_h * qo_len) + offs_m
        l_i = tl.log2(l_i) + m_i
        tl.store(lse_ptrs, l_i, mask=(offs_m < qo_len))

def forward(q, k, v, q_scale, k_scale, v_scale, tensor_layout="HND", attn_mask=None, output_dtype=torch.float16, return_lse=False,
            BLOCK_M=64, BLOCK_N=128,
            WARPQ=16, WARPK=128):
    stage = 1

    o = torch.empty(q.shape, dtype=output_dtype, device=q.device)

    if tensor_layout == "HND":
        b, h_qo, qo_len, head_dim = q.shape
        _, h_kv, kv_len, _ = k.shape

        stride_bz_q, stride_h_q, stride_seq_q = q.stride(0), q.stride(1), q.stride(2)
        stride_bz_k, stride_h_k, stride_seq_k = k.stride(0), k.stride(1), k.stride(2)
        stride_bz_o, stride_h_o, stride_seq_o = o.stride(0), o.stride(1), o.stride(2)

        # V from per_channel_fp8_triton has shape [b, h_kv, head_dim, padded_len]
        # dims: batch=0, head=1, head_dim=2, seq=3
        stride_bz_v = v.stride(0)
        stride_h_v = v.stride(1)
        stride_d_v = v.stride(2)
        stride_seq_v = v.stride(3)
    elif tensor_layout == "NHD":
        b, qo_len, h_qo, head_dim = q.shape
        _, kv_len, h_kv, _ = k.shape

        stride_bz_q, stride_h_q, stride_seq_q = q.stride(0), q.stride(2), q.stride(1)
        stride_bz_k, stride_h_k, stride_seq_k = k.stride(0), k.stride(2), k.stride(1)
        stride_bz_o, stride_h_o, stride_seq_o = o.stride(0), o.stride(2), o.stride(1)

        # V from per_channel_fp8_triton has shape [b, head_dim, h_kv, padded_len]
        # dims: batch=0, head_dim=1, head=2, seq=3
        stride_bz_v = v.stride(0)
        stride_d_v = v.stride(1)
        stride_h_v = v.stride(2)
        stride_seq_v = v.stride(3)
    else:
        raise ValueError(f"tensor_layout {tensor_layout} not supported")

    if attn_mask is not None:
        stride_bz_mask, stride_h_mask, stride_m_mask, stride_n_mask = attn_mask.stride(0), attn_mask.stride(1), attn_mask.stride(2), attn_mask.stride(3)
    else:
        stride_bz_mask, stride_h_mask, stride_m_mask, stride_n_mask = 0, 0, 0, 0

    HEAD_DIM_K = head_dim
    num_kv_groups = h_qo // h_kv

    # sm_scale * log2(e): per-thread quant does not bake sm_scale into q_scale,
    # so the attention kernel must apply it. Multiply by log2(e) because we use exp2.
    sm_scale_log2 = (head_dim ** -0.5) * 1.44269504

    # Number of per-thread scales per Q/K block
    num_q_scales_per_blk = (BLOCK_M // WARPQ) * 8
    num_k_scales_per_blk = (BLOCK_N // WARPK) * 4

    if return_lse:
        lse = torch.empty([b, h_qo, qo_len], dtype=torch.float32, device=q.device)
    else:
        lse = torch.empty([0], dtype=torch.float32, device='cpu')

    grid = (triton.cdiv(qo_len, BLOCK_M), h_qo, b)
    _attn_fwd[grid](
        q, k, v, q_scale, k_scale, v_scale, o, attn_mask, lse,
        stride_bz_q, stride_h_q, stride_seq_q,
        stride_bz_k, stride_h_k, stride_seq_k,
        stride_bz_v, stride_h_v, stride_seq_v, stride_d_v,
        stride_bz_o, stride_h_o, stride_seq_o,
        stride_bz_mask, stride_h_mask, stride_m_mask, stride_n_mask,
        q_scale.stride(0), q_scale.stride(1),
        k_scale.stride(0), k_scale.stride(1),
        sm_scale_log2,
        qo_len, kv_len,
        h_qo, num_kv_groups,
        BLOCK_M=BLOCK_M, BLOCK_N=BLOCK_N, HEAD_DIM=HEAD_DIM_K,
        STAGE=stage, RETURN_LSE=return_lse,
        WARPQ=WARPQ, WARPK=WARPK,
        NUM_Q_SCALES_PER_BLK=num_q_scales_per_blk,
        NUM_K_SCALES_PER_BLK=num_k_scales_per_blk,
        num_warps=4,
        num_stages=2)

    return o, lse