"""
Per-token INT8 quantization kernel.
Input layout: [B, S, N, D] (BSND)
Output: quantized int8 tensor [B, S, N, D], scale tensor [B, N, S]
Each token (one row along D) gets its own scale factor.
"""

import torch
import triton
import triton.language as tl


@triton.jit
def quant_per_token_int8_kernel(
    Input, Output, Scale,
    seq_len,
    stride_ib, stride_is, stride_in, stride_id,
    stride_ob, stride_os, stride_on, stride_od,
    stride_sb, stride_sn, stride_ss,
    HEAD_DIM: tl.constexpr,
):
    """
    Grid: (S, N, B)
    Each program quantizes one token: Input[b, s, n, :] -> Output[b, s, n, :]
    and writes Scale[b, n, s].
    """
    off_s = tl.program_id(0)
    off_n = tl.program_id(1)
    off_b = tl.program_id(2)

    offs_d = tl.arange(0, HEAD_DIM)

    # Load one token vector along head_dim
    input_ptrs = (
        Input
        + off_b * stride_ib
        + off_s * stride_is
        + off_n * stride_in
        + offs_d * stride_id
    )
    output_ptrs = (
        Output
        + off_b * stride_ob
        + off_s * stride_os
        + off_n * stride_on
        + offs_d * stride_od
    )
    scale_ptr = (
        Scale
        + off_b * stride_sb
        + off_n * stride_sn
        + off_s * stride_ss
    )

    mask = offs_d < HEAD_DIM
    x = tl.load(input_ptrs, mask=mask, other=0.0)
    x = x.to(tl.float32)

    # Compute per-token scale: max(|x|) / 127 + eps
    abs_max = tl.max(tl.abs(x)) / 127.0 + 1e-7
    
    # Quantize with rounding
    x_scaled = x / abs_max
    x_scaled += 0.5 * tl.where(x_scaled >= 0, 1, -1)
    x_int8 = x_scaled.to(tl.int8)

    tl.store(output_ptrs, x_int8, mask=mask)
    tl.store(scale_ptr, abs_max)


def per_token_int8(
    tensor: torch.Tensor,
    km = None
) -> tuple:
    """
    Per-token INT8 quantization for BSND layout.

    Args:
        tensor: Input tensor of shape [B, S, N, D], dtype float16 or bfloat16.

    Returns:
        tensor_int8: Quantized tensor [B, S, N, D], dtype int8.
        scale: Per-token scale [B, N, S], dtype float32.
               Dequantize via: tensor_fp ≈ tensor_int8.float() * scale[:, :, :, None].permute(0, 2, 1).unsqueeze(-1)
    """
    assert tensor.ndim == 4, f"Expected 4D tensor [B,S,N,D], got {tensor.ndim}D"
    assert tensor.dtype in (torch.float16, torch.bfloat16), \
        f"Expected float16 or bfloat16, got {tensor.dtype}"
    if km is not None:
        tensor = tensor - km

    batch, seq_len, num_heads, head_dim = tensor.shape

    tensor_int8 = torch.empty_like(tensor, dtype=torch.int8)
    # Scale shape: [B, N, S]
    scale = torch.empty(
        (batch, num_heads, seq_len), device=tensor.device, dtype=torch.float32
    )

    # HEAD_DIM must be power of 2 for triton
    HEAD_DIM = triton.next_power_of_2(head_dim)

    grid = (seq_len, num_heads, batch)
    quant_per_token_int8_kernel[grid](
        tensor, tensor_int8, scale, seq_len,
        tensor.stride(0), tensor.stride(1), tensor.stride(2), tensor.stride(3),
        tensor_int8.stride(0), tensor_int8.stride(1), tensor_int8.stride(2), tensor_int8.stride(3),
        scale.stride(0), scale.stride(1), scale.stride(2),
        HEAD_DIM=HEAD_DIM,
    )

    return tensor_int8, scale