"""Fused MoE Stage2 (fused reduce) FP16 GEMM kernel using Triton Gluon.

Fuses stage2 GEMM with topk reduction via atomic add.
Outputs directly to [M, N] without a separate reduce kernel.
    output[token, :] += weight * (input[token, :] @ expert_weight[expert, :, :])
"""

import triton
import triton.language as tl
from triton.experimental import gluon
from triton.experimental.gluon import language as gl

from atrex.src.triton.fused_moe.fused_moe_common import (
    get_autotune_config,
    make_blocked_layout_a,
    make_blocked_layout_b,
    make_blocked_layout_c,
    make_mfma_layout,
    make_sorted_id_load_layout,
    get_output_tile_index,
    load_and_reshape_weight_tile,
    USE_GLOBAL_LS
)


@triton.autotune(
    configs=get_autotune_config(),
    key=["N", "K", "M_ALIGN", "BLOCK_SIZE_M"],
    reset_to_zero=["output_ptr"],
)
@gluon.jit
def fused_moe_stage2_fused_reduce_fp16_kernel(
    input_ptr,
    weight_ptr,      # [E, N, K] blocked layout
    output_ptr,      # [M, N] -- reduced output
    sorted_ids_ptr,
    sorted_weights_ptr,
    sorted_expert_ids_ptr,
    num_valid_ids_ptr,
    TOPK: gl.constexpr,
    M: gl.constexpr,
    M_ALIGN: gl.constexpr,
    N: gl.constexpr,
    K: gl.constexpr,
    BLOCK_SIZE_M: gl.constexpr,
    BLOCK_SIZE_N: gl.constexpr,
    BLOCK_SIZE_K: gl.constexpr,
    BN: gl.constexpr,
    BK: gl.constexpr,
    grid_size: gl.constexpr,
    NW: gl.constexpr,
    USE_GLOBAL_LS: gl.constexpr,
):
    # NOTE: require K % BLOCK_SIZE_K == 0; non-divisible K is not well supported
    tl.static_assert(K % BLOCK_SIZE_K == 0)

    nw: gl.constexpr = NW
    blocked_layout_a: gl.constexpr = make_blocked_layout_a(nw)
    blocked_layout_b: gl.constexpr = make_blocked_layout_b(nw)
    blocked_layout_c: gl.constexpr = make_blocked_layout_c(nw)
    mfma_layout: gl.constexpr = make_mfma_layout(nw)
    sorted_id_load_layout: gl.constexpr = make_sorted_id_load_layout(nw)

    tl.static_assert(BLOCK_SIZE_N % BN == 0)
    tl.static_assert(BLOCK_SIZE_K % BK == 0)
    tl.static_assert(N % BN == 0)

    NUM_N_MICRO: gl.constexpr = BLOCK_SIZE_N // BN
    NUM_K_MICRO: gl.constexpr = BLOCK_SIZE_K // BK
    # Handle non-divisible N (N % BLOCK_SIZE_N != 0) by using % N_DIV_BN to prevent N-dimension OOB.
    N_DIV_BN: gl.constexpr = N // BN
    NUM_TILES_N: gl.constexpr = gl.cdiv(N, BLOCK_SIZE_N)

    pid = tl.program_id(0)
    tile_idx = pid

    num_valid = tl.load(num_valid_ids_ptr)

    while tile_idx // NUM_TILES_N * BLOCK_SIZE_M < num_valid:

        (
            expert_id,
            topk_idx_for_a, token_tile_m_for_a,
            tile_idx_n,
            topk_idx_for_c, token_tile_m_for_c,
            sorted_weight_for_c,
        ) = get_output_tile_index(
            tile_idx,
            sorted_ids_ptr, sorted_weights_ptr,
            sorted_expert_ids_ptr, num_valid_ids_ptr,
            N, BLOCK_SIZE_M, BLOCK_SIZE_N,
            blocked_layout_a, blocked_layout_c, sorted_id_load_layout,
            LOAD_WEIGHTS=True,
        )

        m_offsets = token_tile_m_for_a * TOPK + topk_idx_for_a
        k_offsets = gl.arange(
            0, BLOCK_SIZE_K,
            layout=gl.SliceLayout(dim=0, parent=blocked_layout_a),
        )
        if USE_GLOBAL_LS:
            a_tile_offsets = m_offsets[:, None].to(tl.int64) * K + k_offsets[None, :].to(tl.int64)
        else:
            a_tile_offsets = m_offsets[:, None] * K + k_offsets[None, :]

        n_micro_offsets = (
            tile_idx_n * NUM_N_MICRO
            + gl.arange(0, NUM_N_MICRO, layout=gl.SliceLayout(1, blocked_layout_b))
        ) % N_DIV_BN
        k_block_offsets = gl.arange(
            0, BN * BK * NUM_K_MICRO,
            layout=gl.SliceLayout(0, blocked_layout_b),
        )

        dot_a_layout: gl.constexpr = gl.DotOperandLayout(
            operand_index=0, parent=mfma_layout, k_width=8,
        )
        dot_b_layout: gl.constexpr = gl.DotOperandLayout(
            operand_index=1, parent=mfma_layout, k_width=8,
        )
        smem_layout_a: gl.constexpr = gl.SwizzledSharedLayout(8, 1, 8, [1, 0])

        acc = gl.zeros([BLOCK_SIZE_M, BLOCK_SIZE_N], gl.float32, mfma_layout)

        expert_weight_base = weight_ptr + expert_id * N * K

        # === Prologue ===
        smem_a = gl.allocate_shared_memory(
            input_ptr.type.element_ty, [2, BLOCK_SIZE_M, BLOCK_SIZE_K],
            layout=smem_layout_a,
        )

        gmem_idx = 0
        cur_idx = 0
        a_mask = (
            (token_tile_m_for_a[:, None] < M)
            & (topk_idx_for_a[:, None] < TOPK)
            # & (k_offsets[None, :] + gmem_idx * BLOCK_SIZE_K < K)
        )
        if USE_GLOBAL_LS:
            a_tile = tl.load(input_ptr + gmem_idx * BLOCK_SIZE_K + a_tile_offsets,
                             mask=a_mask)
        else:
            a_tile = gl.amd.cdna3.buffer_load(
                ptr=input_ptr, offsets=gmem_idx * BLOCK_SIZE_K + a_tile_offsets,
                mask=a_mask
            )
        smem_a.index(cur_idx).store(a_tile)

        b_mfma = load_and_reshape_weight_tile(
            expert_weight_base, gmem_idx * BN * BK * NUM_K_MICRO,
            n_micro_offsets, k_block_offsets,
            K, BLOCK_SIZE_N, BLOCK_SIZE_K, BN, BK, dot_b_layout,
        )

        # === Main K-loop ===
        tl.static_assert(((K + BLOCK_SIZE_K - 1) // BLOCK_SIZE_K) > 1)
        num_k_iter = gl.cdiv(K, BLOCK_SIZE_K)

        buf_idx = 0
        for k_start in range(0, num_k_iter - 1):
            cur_idx = buf_idx
            next_idx = (buf_idx + 1) % 2
            gmem_idx = k_start + 1

            a_mfma = smem_a.index(cur_idx).load(dot_a_layout)
            acc = gl.amd.cdna3.mfma(a_mfma, b_mfma, acc)

            a_mask = (
                (token_tile_m_for_a[:, None] < M)
                & (topk_idx_for_a[:, None] < TOPK)
                # & (k_offsets[None, :] + gmem_idx * BLOCK_SIZE_K < K)
            )
            if USE_GLOBAL_LS:
                a_tile = tl.load(input_ptr + gmem_idx * BLOCK_SIZE_K + a_tile_offsets,
                                mask=a_mask)
            else:
                a_tile = gl.amd.cdna3.buffer_load(
                    ptr=input_ptr, offsets=gmem_idx * BLOCK_SIZE_K + a_tile_offsets,
                    mask=a_mask
                )        

            b_mfma = load_and_reshape_weight_tile(
                expert_weight_base, gmem_idx * BN * BK * NUM_K_MICRO,
                n_micro_offsets, k_block_offsets,
                K, BLOCK_SIZE_N, BLOCK_SIZE_K, BN, BK, dot_b_layout,
            )
            smem_a.index(next_idx).store(a_tile)

            buf_idx = (buf_idx + 1) % 2

        # === Epilogue ===
        smem_idx = buf_idx
        a_mfma = smem_a.index(smem_idx).load(dot_a_layout)
        acc = gl.amd.cdna3.mfma(a_mfma, b_mfma, acc)

        # Weighted result, atomic add to output[token, n] (fused reduce)
        result = gl.convert_layout(acc, layout=blocked_layout_c) * sorted_weight_for_c[:, None]
        result = result.to(input_ptr.dtype.element_ty)

        # Output addresses: output[token, n] -- no topk dimension
        out_m_offsets = token_tile_m_for_c
        out_n_offsets = tile_idx_n * BLOCK_SIZE_N + gl.arange(
            0, BLOCK_SIZE_N,
            layout=gl.SliceLayout(0, blocked_layout_c),
        )

        out_mask = (
            (out_m_offsets[:, None] < M)
            & (out_n_offsets[None, :] < N)
        )

        if USE_GLOBAL_LS:
            tl.atomic_add(output_ptr + out_m_offsets[:, None].to(tl.int64) * N + out_n_offsets[None, :].to(tl.int64),
                          result,
                          mask=out_mask,
                          sem="relaxed")
        else:
            gl.amd.cdna3.buffer_atomic_add(
                output_ptr,
                out_m_offsets[:, None] * N + out_n_offsets[None, :],
                result,
                mask=out_mask,
                sem="relaxed",
            )

        tile_idx += grid_size


def fused_moe_stage2_fused_reduce_fp16(
    x, y, out,
    sorted_ids, sorted_weights, sorted_expert_ids, num_valid_ids,
    M_ALIGN, BLOCK_SIZE_M,
):
    """Launch the fused MoE stage2 (fused reduce) FP16 kernel.

    Uses atomic add to reduce across topk slots directly into [M, N] output.

    Args:
        x:                  Input activations              [M, TOPK, K]
        y:                  Expert weights (blocked layout) [E, N, K]
        out:                Output buffer                   [M, N] (must be zeroed)
        sorted_ids:         Packed (token_index | topk_slot << 24) per routed slot
        sorted_weights:     Gating weights per routed slot
        sorted_expert_ids:  Expert id for each M-tile
        num_valid_ids:      Number of valid routed slots (scalar tensor)
        M_ALIGN:            Bucketed M value for autotune cache key
        BLOCK_SIZE_M:       Tile size for M dimension, must match moe_sorting block_size
    """
    M, TOPK, K = x.shape
    N = out.shape[1]

    def grid(META):
        return (META["grid_size"],)

    fused_moe_stage2_fused_reduce_fp16_kernel[grid](
        x, y, out,
        sorted_ids, sorted_weights, sorted_expert_ids, num_valid_ids,
        TOPK, M, M_ALIGN, N, K,
        BLOCK_SIZE_M=BLOCK_SIZE_M,
        BN=16,
        BK=32,
        USE_GLOBAL_LS=USE_GLOBAL_LS
    )
