"""Reduce FP16: sum along axis=1 for [B, TOPK, N] -> [B, N]."""

import torch
import triton
import triton.language as tl

DEVICE = triton.runtime.driver.active.get_active_torch_device()


@triton.jit
def reduce_fp16_kernel(
    input_ptr,      # [B, TOPK, N] input pointer
    output_ptr,     # [B, N] output pointer
    B,              # batch size
    TOPK,           # reduce dimension size
    N,              # last dimension size
    stride_b,       # input stride along B dim
    stride_topk,    # input stride along TOPK dim
    stride_n,       # input stride along N dim
    stride_ob,      # output stride along B dim
    stride_on,      # output stride along N dim
    BLOCK_SIZE_N: tl.constexpr,  # block size for N dim
):
    # 2D launch grid: (B, cdiv(N, BLOCK_SIZE_N))
    pid_b = tl.program_id(0)       # batch dim
    pid_n = tl.program_id(1)       # N dim block

    # offset of current block in N dim
    n_offset = pid_n * BLOCK_SIZE_N + tl.arange(0, BLOCK_SIZE_N)
    n_mask = n_offset < N

    # accumulator in float32 to avoid fp16 precision loss
    acc = tl.zeros([BLOCK_SIZE_N], dtype=tl.float32)

    # iterate over TOPK dim for reduction
    for k in range(TOPK):
        # compute input address: input[pid_b, k, n_offset]
        input_offsets = pid_b.to(tl.int64) * stride_b + k * stride_topk + n_offset * stride_n
        # load data
        x = tl.load(input_ptr + input_offsets, mask=n_mask, other=0.0)
        acc += x.to(tl.float32)

    # write back output[pid_b, n_offset], cast to fp16
    output_offsets = pid_b.to(tl.int64) * stride_ob + n_offset * stride_on
    tl.store(output_ptr + output_offsets, acc.to(input_ptr.dtype.element_ty), mask=n_mask)


def reduce_fp16(x: torch.Tensor) -> torch.Tensor:
    """
    Reduce-sum a [B, TOPK, N] fp16 tensor along axis=1.
    Returns a [B, N] fp16 tensor.
    """
    assert x.ndim == 3, f"Input must be 3-dim, got {x.ndim}-dim"

    B, TOPK, N = x.shape
    output = torch.empty((B, N), dtype=x.dtype, device=x.device)

    BLOCK_SIZE_N = min(triton.next_power_of_2(N), 2048)

    grid = (B, triton.cdiv(N, BLOCK_SIZE_N))

    reduce_fp16_kernel[grid](
        x, output,
        B, TOPK, N,
        x.stride(0), x.stride(1), x.stride(2),
        output.stride(0), output.stride(1),
        BLOCK_SIZE_N=BLOCK_SIZE_N,
    )

    return output


# =====================
# Correctness test + benchmark
# =====================

def test_correctness():
    """Correctness verification"""
    print("=" * 60)
    print("Correctness Test")
    print("=" * 60)

    # Test scenario: B=4000, TOPK=6, N=2048
    B, TOPK, N = 4000, 6, 2048
    x = torch.randn(B, TOPK, N, dtype=torch.float16, device=DEVICE)

    # Triton result
    y_triton = reduce_fp16(x)

    # PyTorch reference result
    y_torch = x.sum(dim=1)

    # Compare
    max_diff = torch.max(torch.abs(y_triton.float() - y_torch.float())).item()
    print(f"Input shape: [{B}, {TOPK}, {N}]")
    print(f"Output shape: {list(y_triton.shape)}")
    print(f"Max absolute error: {max_diff:.6e}")
    assert torch.allclose(y_triton, y_torch, atol=1e-2, rtol=1e-2), \
        f"Results mismatch! Max diff: {max_diff}"
    print("PASS: Correctness test passed!\n")

    # Additional tests: various sizes
    test_cases = [
        (1, 6, 128),
        (16, 6, 512),
        (100, 6, 1024),
        (4000, 6, 2048),
        (1, 1, 1),
        (32, 6, 3),      # N is not power of 2
        (64, 6, 1000),   # N is not power of 2
    ]
    for b, topk, n in test_cases:
        x = torch.randn(b, topk, n, dtype=torch.float16, device=DEVICE)
        y_triton = reduce_fp16(x)
        y_torch = x.sum(dim=1)
        max_diff = torch.max(torch.abs(y_triton.float() - y_torch.float())).item()
        status = "PASS" if torch.allclose(y_triton, y_torch, atol=1e-2, rtol=1e-2) else "FAIL"
        print(f"  {status} [{b}, {topk}, {n}] -> [{b}, {n}]  max error: {max_diff:.6e}")


def benchmark():
    """Performance benchmark"""
    print("\n" + "=" * 60)
    print("Performance Benchmark (B=4000, TOPK=6, N=2048)")
    print("=" * 60)

    B, TOPK, N = 400000, 6, 2048
    x = torch.randn(B, TOPK, N, dtype=torch.float16, device=DEVICE)

    # Triton
    ms_triton = triton.testing.do_bench(lambda: reduce_fp16(x))

    # PyTorch
    ms_torch = triton.testing.do_bench(lambda: x.sum(dim=1))

    # Compute bandwidth utilization
    # Read: B * TOPK * N * 2 bytes, Write: B * N * 2 bytes
    total_bytes = (B * TOPK * N * 2 + B * N * 2)
    gbps_triton = total_bytes * 1e-9 / (ms_triton * 1e-3)
    gbps_torch = total_bytes * 1e-9 / (ms_torch * 1e-3)

    print(f"  Triton:  {ms_triton:.4f} ms  ({gbps_triton:.1f} GB/s)")
    print(f"  PyTorch: {ms_torch:.4f} ms  ({gbps_torch:.1f} GB/s)")
    print(f"  Speedup: {ms_torch / ms_triton:.2f}x")


if __name__ == "__main__":
    test_correctness()
    benchmark()
