"""Shared helpers for fused MoE stage1/stage2 FP16 gluon kernels."""

import triton
import triton.language as tl
from triton.experimental import gluon
from triton.experimental.gluon import language as gl

# NOTE: Fix incorrect memory access due to int32 index overflow, no performance regression observed in regression tests
USE_GLOBAL_LS = True


def get_autotune_config():
    configs = []
    for nw in [4, 8]:
        for tile_n in [64, 128, 256]:
            for tile_k in [64, 128, 256]:
                # for sm_multiplier in range(1, 8):
                # NOTE: reduce the parameter search space, no performance regression observed in regression tests
                sm_multiplier = 8
                configs.append(
                    triton.Config(
                        {
                            "BLOCK_SIZE_N": tile_n,
                            "BLOCK_SIZE_K": tile_k,
                            "grid_size": sm_multiplier * 80,
                            "NW": nw,
                        },
                        num_warps=nw,
                    )
                )
    return configs


@gluon.constexpr_function
def make_blocked_layout_a(nw):
    return gl.BlockedLayout(
        size_per_thread=[1, 8], threads_per_warp=[8, 8],
        warps_per_cta=[nw, 1], order=[1, 0],
    )

@gluon.constexpr_function
def make_blocked_layout_b(nw):
    return gl.BlockedLayout(
        size_per_thread=[1, 8], threads_per_warp=[1, 64],
        warps_per_cta=[nw, 1], order=[1, 0],
    )

@gluon.constexpr_function
def make_blocked_layout_c(nw):
    return gl.BlockedLayout(
        size_per_thread=[1, 4], threads_per_warp=[16, 4],
        warps_per_cta=[1, nw], order=[1, 0],
    )

@gluon.constexpr_function
def make_mfma_layout(nw):
    return gl.amd.AMDMFMALayout(
        version=3, instr_shape=[16, 16],
        transposed=True, warps_per_cta=[1, nw],
    )

@gluon.constexpr_function
def make_sorted_id_load_layout(nw):
    return gl.BlockedLayout(
        size_per_thread=[1, 1], threads_per_warp=[8, 8],
        warps_per_cta=[1, nw], order=[0, 1],
    )


@gluon.jit
def silu(x):
    return x * tl.sigmoid(x)


@gluon.jit
def get_output_tile_index(
    block_idx_1d,
    sorted_ids_ptr,
    sorted_weights_ptr,
    sorted_expert_ids_ptr,
    num_valid_ids_ptr,
    N: gl.constexpr,
    BLOCK_SIZE_M: gl.constexpr,
    BLOCK_SIZE_N: gl.constexpr,
    blocked_layout_a: gl.constexpr,
    blocked_layout_c: gl.constexpr,
    sorted_id_load_layout: gl.constexpr,
    LOAD_WEIGHTS: gl.constexpr,
):
    """Map a 1-D persistent-kernel block index to an (expert, M-tile, N-tile).

    sorted_ids encoding:
        token_index = sorted_id & 0xFFFFFF   (lower 24 bits)
        topk_slot   = sorted_id >> 24        (upper 8 bits)

    When LOAD_WEIGHTS=True, also loads and returns sorted_weight_for_c
    (used by stage2 for weighted accumulation).
    """
    num_tiles_n: gl.constexpr = gl.cdiv(N, BLOCK_SIZE_N)

    tile_idx_m = block_idx_1d // num_tiles_n
    tile_idx_n = block_idx_1d % num_tiles_n

    expert_id = tl.load(sorted_expert_ids_ptr + tile_idx_m)

    m_base = tile_idx_m * BLOCK_SIZE_M
    m_offsets = gl.arange(
        0, BLOCK_SIZE_M,
        layout=gl.SliceLayout(dim=0, parent=sorted_id_load_layout),
    )
    sorted_id = gl.amd.cdna3.buffer_load(
        ptr=sorted_ids_ptr, offsets=m_base + m_offsets,
    )

    # Decode for A-matrix tile
    sorted_id_a = gl.convert_layout(
        sorted_id,
        layout=gl.SliceLayout(dim=1, parent=blocked_layout_a),
    )
    token_tile_m_for_a = sorted_id_a & 0xFFFFFF
    topk_idx_for_a = sorted_id_a >> 24

    # Decode for C-matrix tile
    sorted_id_c = gl.convert_layout(
        sorted_id,
        layout=gl.SliceLayout(dim=1, parent=blocked_layout_c),
    )
    token_tile_m_for_c = sorted_id_c & 0xFFFFFF
    topk_idx_for_c = sorted_id_c >> 24

    if LOAD_WEIGHTS:
        sorted_weight = gl.amd.cdna3.buffer_load(
            ptr=sorted_weights_ptr, offsets=m_base + m_offsets,
        )
        sorted_weight_for_c = gl.convert_layout(
            sorted_weight,
            layout=gl.SliceLayout(dim=1, parent=blocked_layout_c),
        )
        return (
            expert_id,
            topk_idx_for_a, token_tile_m_for_a,
            tile_idx_n,
            topk_idx_for_c, token_tile_m_for_c,
            sorted_weight_for_c,
        )
    else:
        return (
            expert_id,
            topk_idx_for_a, token_tile_m_for_a,
            tile_idx_n,
            topk_idx_for_c, token_tile_m_for_c,
        )


@gluon.jit
def load_and_reshape_weight_tile(
    weight_base_ptr,
    k_tile_byte_offset,
    n_micro_offsets,
    k_block_offsets,
    K: gl.constexpr,
    BLOCK_SIZE_N: gl.constexpr,
    BLOCK_SIZE_K: gl.constexpr,
    BN: gl.constexpr,
    BK: gl.constexpr,
    dot_b_layout: gl.constexpr,
):
    """Load a weight tile from global memory and reshape for MFMA.

    Weights are in blocked micro-tile layout [E, N//BN, K//BK, BK, BN].
    Loads [BLOCK_SIZE_N//BN, BN*BK*(BLOCK_SIZE_K//BK)], reshapes and permutes
    into [BLOCK_SIZE_K, BLOCK_SIZE_N] in dot_b_layout.
    """
    tl.static_assert(BLOCK_SIZE_N % BN == 0)
    tl.static_assert(BLOCK_SIZE_K % BK == 0)

    num_k_micro: gl.constexpr = BLOCK_SIZE_K // BK

    weight_tile = gl.amd.cdna3.buffer_load(
        ptr=weight_base_ptr + k_tile_byte_offset,
        offsets=n_micro_offsets[:, None] * BN * K + k_block_offsets[None, :],
    )

    weight_tile = weight_tile.reshape(
        (BLOCK_SIZE_N // BN, num_k_micro, BK // 8, BN, 8)
    )
    weight_tile = weight_tile.permute((1, 2, 4, 0, 3))
    weight_tile = weight_tile.reshape((BLOCK_SIZE_K, BLOCK_SIZE_N))

    return gl.convert_layout(weight_tile, layout=dot_b_layout)
