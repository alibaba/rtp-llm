import triton.language as tl
from atrex.utils.compat_gluon import gluon, gl
from atrex.core.compile_triton import triton_kernel


@gluon.jit
def _matmul_split(a_ptr, b_ptr,
                  M, N, K,
                  stride_am, stride_ak,
                  stride_bn, stride_bk,
                  blocked_a: gl.constexpr,
                  blocked_b: gl.constexpr,
                  blocked_c: gl.constexpr,
                  mfma_layout: gl.constexpr,
                  BLOCK_SIZE_M: gl.constexpr,
                  BLOCK_SIZE_N: gl.constexpr,
                  BLOCK_SIZE_K: gl.constexpr,
                  pidr: gl.constexpr,
                  smem_a: gl.shared_memory_descriptor,
                  smem_b: gl.shared_memory_descriptor,
                  acc: gl.tensor):
    num_pid_n = gl.cdiv(N, BLOCK_SIZE_N)

    pid_m = pidr // num_pid_n
    pid_n = pidr % num_pid_n

    start_m = pid_m * BLOCK_SIZE_M
    start_n = pid_n * BLOCK_SIZE_N

    dot_a_layout: gl.constexpr = gl.DotOperandLayout(operand_index=0, parent=mfma_layout, k_width=8)
    dot_b_layout: gl.constexpr = gl.DotOperandLayout(operand_index=1, parent=mfma_layout, k_width=8)

    offs_am = gl.arange(0, BLOCK_SIZE_M, layout=gl.SliceLayout(1, blocked_a)) + start_m
    offs_bn = gl.arange(0, BLOCK_SIZE_N, layout=gl.SliceLayout(1, blocked_b)) + start_n

    offs_ak = gl.arange(0, BLOCK_SIZE_K, layout=gl.SliceLayout(0, blocked_a))
    offs_bk = gl.arange(0, BLOCK_SIZE_K, layout=gl.SliceLayout(0, blocked_b))
    offs_a = offs_am[:, None] * stride_am + offs_ak[None, :] * stride_ak
    offs_b = offs_bn[:, None] * stride_bn + offs_bk[None, :] * stride_bk

    valid_am = offs_am < M
    valid_bn = offs_bn < N
    valid_ak = offs_ak < K
    valid_bk = offs_bk < K

    a = gl.amd.cdna3.buffer_load(ptr=a_ptr, offsets=offs_a, mask=valid_am[:, None] & valid_ak[None, :])
    b = gl.amd.cdna3.buffer_load(ptr=b_ptr, offsets=offs_b, mask=valid_bn[:, None] & valid_bk[None, :])
    smem_a.index(0).store(a)
    smem_b.index(0).store(tl.trans(b))

    loop_n = gl.cdiv(K, BLOCK_SIZE_K)
    for i in range(1, loop_n):

        offs_a += BLOCK_SIZE_K * stride_ak
        offs_b += BLOCK_SIZE_K * stride_bk
        valid_ak = (offs_ak + i * BLOCK_SIZE_K) < K
        valid_bk = (offs_bk + i * BLOCK_SIZE_K) < K
        a = gl.amd.cdna3.buffer_load(ptr=a_ptr, offsets=offs_a, mask=valid_am[:, None] & valid_ak[None, :])
        a1 = smem_a.index((i - 1) % 2).load(layout=dot_a_layout)
        b1 = smem_b.index((i - 1) % 2).load(layout=dot_b_layout)

        b = gl.amd.cdna3.buffer_load(ptr=b_ptr, offsets=offs_b, mask=valid_bn[:, None] & valid_bk[None, :])

        smem_a.index(i % 2).store(a)
        smem_b.index(i % 2).store(tl.trans(b))
        acc = gl.amd.cdna3.mfma(a1, b1, acc)

    offs_a += BLOCK_SIZE_K * stride_ak
    offs_b += BLOCK_SIZE_K * stride_bk
    # tail
    a1 = smem_a.index((loop_n - 1) % 2).load(layout=dot_a_layout)
    b1 = smem_b.index((loop_n - 1) % 2).load(layout=dot_b_layout)
    acc = gl.amd.cdna3.mfma(a1, b1, acc)

    c = gl.convert_layout(acc, layout=blocked_c)
    return c, start_m, start_n


@gluon.jit
def qkvz_kernel(a_ptr, b_ptr, c0_ptr, c1_ptr,
                M: int, N0: int, N: int, K: int,
                stride_am, stride_ak: gl.constexpr,
                stride_bn, stride_bk: gl.constexpr,
                stride_cm0, stride_cn0: gl.constexpr,
                stride_cm1, stride_cn1: gl.constexpr,
                blocked_a: gl.constexpr,
                blocked_b: gl.constexpr,
                blocked_c: gl.constexpr,
                mfma_layout: gl.constexpr,
                num_heads: gl.constexpr,
                BLOCK_SIZE_M: gl.constexpr,
                BLOCK_SIZE_N: gl.constexpr,
                BLOCK_SIZE_K: gl.constexpr,
                pidr: gl.constexpr,
                smem_a: gl.shared_memory_descriptor,
                smem_b: gl.shared_memory_descriptor,
                acc: gl.tensor
                ):

    c_f32, start_m, start_n = _matmul_split(a_ptr, b_ptr, M, N, K, stride_am, stride_ak, stride_bn, stride_bk,
                                            blocked_a, blocked_b, blocked_c, mfma_layout, BLOCK_SIZE_M, BLOCK_SIZE_N,
                                            BLOCK_SIZE_K, pidr, smem_a, smem_b, acc)
    c = c_f32.to(a_ptr.dtype.element_ty)

    offs_cm = gl.arange(0, BLOCK_SIZE_M, layout=gl.SliceLayout(1, blocked_c)) + start_m
    offs_cn = gl.arange(0, BLOCK_SIZE_N, layout=gl.SliceLayout(0, blocked_c)) + start_n

    head_dim_total = 768
    head_dim_q = 128
    head_dim_k = 128
    head_dim_v = 256
    head_dim_z = 256

    valid_input = offs_cn < N
    valid_output_m = offs_cm < M

    head_idx = offs_cn // head_dim_total  # 第几个head
    within_head_idx = offs_cn % head_dim_total  # 在该head内的位置

    valid_head = head_idx < num_heads

    # 定义范围
    q_range = (within_head_idx >= 0) & (within_head_idx < head_dim_q)
    k_range = (within_head_idx >= head_dim_q) & (within_head_idx < head_dim_q + head_dim_k)
    v_range = (within_head_idx >= head_dim_q + head_dim_k) & (within_head_idx < head_dim_q + head_dim_k + head_dim_v)
    z_range = (within_head_idx >= head_dim_q + head_dim_k + head_dim_v) & (within_head_idx < head_dim_total)

    # 计算每个部分内的相对索引
    q_within_idx = within_head_idx  # 0-127
    k_within_idx = within_head_idx - head_dim_q  # 0-127
    v_within_idx = within_head_idx - (head_dim_q + head_dim_k)  # 0-255
    z_within_idx = within_head_idx - (head_dim_q + head_dim_k + head_dim_v)

    # 计算输出索引（只在对应范围内有效）
    q_output_idx = head_idx * head_dim_q + q_within_idx
    k_output_idx = num_heads * head_dim_q + head_idx * head_dim_k + k_within_idx
    v_output_idx = num_heads * (head_dim_q + head_dim_k) + head_idx * head_dim_v + v_within_idx
    z_output_idx = head_idx * head_dim_z + z_within_idx

    q_output_valid = q_output_idx < (num_heads * head_dim_q)
    k_output_valid = (k_output_idx >= num_heads * head_dim_q) & (k_output_idx < num_heads * (head_dim_q + head_dim_k))
    v_output_valid = (v_output_idx >= num_heads * (head_dim_q + head_dim_k)) & (v_output_idx < num_heads * (head_dim_q + head_dim_k + head_dim_v))
    z_output_valid = z_output_idx < (num_heads * head_dim_z)

    # 组合掩码
    q_mask = q_range[None, :] & valid_input[None, :] & valid_output_m[:, None] & valid_head[None, :] & q_output_valid[None, :]
    k_mask = k_range[None, :] & valid_input[None, :] & valid_output_m[:, None] & valid_head[None, :] & k_output_valid[None, :]
    v_mask = v_range[None, :] & valid_input[None, :] & valid_output_m[:, None] & valid_head[None, :] & v_output_valid[None, :]
    z_mask = z_range[None, :] & valid_input[None, :] & valid_output_m[:, None] & valid_head[None, :] & z_output_valid[None, :]

    offs_q = offs_cm[:, None] * stride_cm0 + q_output_idx[None, :] * stride_cn0
    gl.amd.cdna3.buffer_store(stored_value=c, ptr=c0_ptr, offsets=offs_q, mask=q_mask)

    offs_k = offs_cm[:, None] * stride_cm0 + k_output_idx[None, :] * stride_cn0
    gl.amd.cdna3.buffer_store(stored_value=c, ptr=c0_ptr, offsets=offs_k, mask=k_mask)

    offs_v = offs_cm[:, None] * stride_cm0 + v_output_idx[None, :] * stride_cn0
    gl.amd.cdna3.buffer_store(stored_value=c, ptr=c0_ptr, offsets=offs_v, mask=v_mask)

    offs_z = offs_cm[:, None] * stride_cm1 + z_output_idx[None, :] * stride_cn1
    gl.amd.cdna3.buffer_store(stored_value=c, ptr=c1_ptr, offsets=offs_z, mask=z_mask)


@gluon.jit
def beta_alpha_kernel(a_ptr, b_ptr, A_log, dt_bias,
                      c0_ptr, c1_ptr, M: int, N0: int, N: int, K: int,
                      stride_am, stride_ak: gl.constexpr,
                      stride_bn, stride_bk: gl.constexpr,
                      stride_cm0, stride_cn0: gl.constexpr,
                      stride_cm1, stride_cn1: gl.constexpr,
                      blocked_a: gl.constexpr,
                      blocked_b: gl.constexpr,
                      blocked_c: gl.constexpr,
                      mfma_layout: gl.constexpr,
                      num_heads: gl.constexpr,
                      beta : gl.constexpr,
                      threshold: gl.constexpr,
                      BLOCK_SIZE_M: gl.constexpr,
                      BLOCK_SIZE_N: gl.constexpr,
                      BLOCK_SIZE_K: gl.constexpr,
                      pidr: gl.constexpr,
                      smem_a: gl.shared_memory_descriptor,
                      smem_b: gl.shared_memory_descriptor,
                      acc: gl.tensor
                      ):

    c_f32, start_m, start_n = _matmul_split(a_ptr, b_ptr, M, N, K, stride_am, stride_ak, stride_bn, stride_bk,
                                            blocked_a, blocked_b, blocked_c, mfma_layout, BLOCK_SIZE_M, BLOCK_SIZE_N,
                                            BLOCK_SIZE_K, pidr, smem_a, smem_b, acc)
    c = c_f32.to(a_ptr.dtype.element_ty)
    offs_cm = gl.arange(0, BLOCK_SIZE_M, layout=gl.SliceLayout(1, blocked_c)) + start_m
    offs_cn = gl.arange(0, BLOCK_SIZE_N, layout=gl.SliceLayout(0, blocked_c)) + start_n

    head_dim_total = 4  # 每个head的总维度：b(2) + a(2)
    head_dim_b = 2
    head_dim_a = 2

    # 添加全局边界检查
    valid_input = offs_cn < N
    valid_output_m = offs_cm < M

    # 从原始交错数据 [b1,a1, b2,a2, ...] 中提取
    head_idx = offs_cn // head_dim_total
    within_head_idx = offs_cn % head_dim_total

    # 添加head边界检查
    valid_head = head_idx < num_heads

    # 处理b部分: 原始[0,2) -> 输出b的[head_idx*2:(head_idx+1)*2] (with sigmoid)
    b_mask = (within_head_idx[None, :] < head_dim_b) & valid_input[None, :] & valid_output_m[:, None] & valid_head[None, :]
    b_output_idx = head_idx * head_dim_b + within_head_idx
    # 添加输出边界检查
    b_output_valid = b_output_idx < (num_heads * head_dim_b)
    b_mask = b_mask & b_output_valid[None, :]
    offs_b = offs_cm[:, None] * stride_cm0 + b_output_idx[None, :] * stride_cn0

    c_sigmoid = tl.sigmoid(c.to(tl.float32))
    gl.amd.cdna3.buffer_store(stored_value=c_sigmoid.to(c0_ptr.dtype.element_ty), ptr=c0_ptr, offsets=offs_b, mask=b_mask)

    # 处理a部分: 原始[2,4) -> 输出a的[head_idx*2:(head_idx+1)*2] (with post-processing)
    a_start = head_dim_b
    a_range = (within_head_idx >= a_start) & (within_head_idx < head_dim_total)
    a_within_idx = within_head_idx - a_start
    a_output_idx = head_idx * head_dim_a + a_within_idx
    a_output_valid = a_output_idx < num_heads * head_dim_a
    a_mask = a_range[None, :] & valid_input[None, :] & valid_output_m[:, None] & valid_head[None, :] & a_output_valid[None, :]

    # A_log和dt_bias的索引 - 添加边界检查
    a_global_idx = head_idx * head_dim_a + a_within_idx
    a_load_valid = (within_head_idx >= a_start) & valid_head & (a_global_idx < (num_heads * head_dim_a)) & (a_global_idx >= 0)

    blk_A_log = gl.load(A_log + a_global_idx, mask=a_load_valid).expand_dims(0)
    blk_bias = gl.load(dt_bias + a_global_idx, mask=a_load_valid).expand_dims(0)
    x = c.to(tl.float32) + blk_bias.to(tl.float32)
    softplus_x = tl.where(x <= 20, tl.log(1 + tl.exp(x)), x)
    blk_g = -tl.exp(blk_A_log.to(tl.float32)) * softplus_x

    offs_a = offs_cm[:, None] * stride_cm1 + a_output_idx[None, :] * stride_cn1
    gl.amd.cdna3.buffer_store(stored_value=blk_g, ptr=c1_ptr, offsets=offs_a, mask=a_mask)


@triton_kernel()
@gluon.jit
def gated_delta_net_pre_kernel(
        hidden_states, in_proj_qkvz, in_proj_ba, A_log, dt_bias,
        mixed_qkv, z, b, a,
        T: int, Nqkv: int, Nz: int, Nb: int, Na: int, K: int,
        num_heads: gl.constexpr,
        stride_inm, stride_ink : gl.constexpr,
        stride_w0k, stride_w0n : gl.constexpr,
        stride_w1k, stride_w1n : gl.constexpr,
        stride_qkvm, stride_qkvn : gl.constexpr,
        stride_zm, stride_zn : gl.constexpr,
        stride_bm, stride_bn : gl.constexpr,
        stride_am, stride_an : gl.constexpr,
        beta : gl.constexpr, threshold: gl.constexpr,
        BLOCK_SIZE_M: gl.constexpr, BLOCK_SIZE_N: gl.constexpr, BLOCK_SIZE_K: gl.constexpr,
) -> None:
    pid = gl.program_id(axis=0)
    num_pid_m = gl.cdiv(T, BLOCK_SIZE_M)
    num_pid_n = gl.cdiv(Nqkv + Nz, BLOCK_SIZE_N)
    pid_offset = num_pid_m * num_pid_n
    blocked_a: gl.constexpr = gl.BlockedLayout(size_per_thread=[1, 2], threads_per_warp=[8, 8],
                                               warps_per_cta=[2, 2], order=[1, 0])
    blocked_b: gl.constexpr = gl.BlockedLayout(size_per_thread=[8, 1], threads_per_warp=[4, 16],
                                               warps_per_cta=[1, 4], order=[1, 0])
    blocked_c: gl.constexpr = gl.BlockedLayout(size_per_thread=[1, 2], threads_per_warp=[8, 8],
                                               warps_per_cta=[2, 2], order=[1, 0])
    mfma_layout: gl.constexpr = gl.amd.AMDMFMALayout(version=3, instr_shape=[16, 16, 16],
                                                     transposed=True, warps_per_cta=[2, 2])
    shared_a: gl.constexpr = gl.SwizzledSharedLayout(
        vec=4, per_phase=1, max_phase=32, order=[1, 0]
    )

    shared_b: gl.constexpr = gl.SwizzledSharedLayout(
        vec=4, per_phase=1, max_phase=32, order=[0, 1]
    )

    smem_a = gl.allocate_shared_memory(
        hidden_states.type.element_ty, [2, BLOCK_SIZE_M, BLOCK_SIZE_K], layout=shared_a
    )

    smem_b = gl.allocate_shared_memory(
        in_proj_qkvz.type.element_ty, [2, BLOCK_SIZE_K, BLOCK_SIZE_N], layout=shared_b
    )

    acc = gl.zeros([BLOCK_SIZE_M, BLOCK_SIZE_N], gl.float32, mfma_layout)
    if (pid < pid_offset):
        qkvz_kernel(hidden_states, in_proj_qkvz, mixed_qkv, z, T, Nqkv, Nqkv + Nz, K,
                    stride_inm, stride_ink, stride_w0k, stride_w0n, stride_qkvm, stride_qkvn,
                    stride_zm, stride_zn, blocked_a, blocked_b, blocked_c, mfma_layout, num_heads,
                    BLOCK_SIZE_M=BLOCK_SIZE_M, BLOCK_SIZE_N=BLOCK_SIZE_N, BLOCK_SIZE_K=BLOCK_SIZE_K, pidr=pid,
                    smem_a=smem_a, smem_b=smem_b, acc=acc)
    else:
        beta_alpha_kernel(hidden_states, in_proj_ba, A_log, dt_bias, b, a, T, Nb, Nb + Na, K,
                          stride_inm, stride_ink, stride_w1k, stride_w1n, stride_bm, stride_bn,
                          stride_am, stride_an, blocked_a, blocked_b, blocked_c, mfma_layout, num_heads, beta, threshold,
                          BLOCK_SIZE_M=BLOCK_SIZE_M, BLOCK_SIZE_N=BLOCK_SIZE_N, BLOCK_SIZE_K=BLOCK_SIZE_K, pidr=pid - pid_offset,
                          smem_a=smem_a, smem_b=smem_b, acc=acc)


if __name__ == '__main__':
    import os
    # below will only be called in aot mode
    build_dir = os.path.dirname(os.path.abspath(__file__)) + "/../../build/triton/"
    os.makedirs(build_dir, exist_ok=True)
    os.environ["TRITON_PREBUILD"] = build_dir
    gated_delta_net_pre_kernel
