#include "fused_mrope_rms.h"

PYBIND11_MODULE(TORCH_EXTENSION_NAME, m) {
  m.def("fused_rope_rms_set_kv", &fused_rope_rms_set_kv);
}
