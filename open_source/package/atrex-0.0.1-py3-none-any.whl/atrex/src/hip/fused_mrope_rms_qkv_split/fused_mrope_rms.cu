#include "../include/hip_float8.h"
#include "rope_common.h"

using namespace at;

constexpr int BLOCK_SIZE = 256;

namespace rope_rms {

static constexpr int kBytesPerAccess = 16;

namespace block_utils {

template <typename T>
__inline__ __device__ T warp_shfl_xor_sync(T val, int offset) {
  return __shfl_xor(val, offset, 32);
}

template <typename T> __inline__ __device__ T warp_reduce_sum(T val) {
#pragma unroll
  for (int offset = 16; offset > 0; offset >>= 1)
    val += warp_shfl_xor_sync(val, offset);
  return val;
}

template <typename T>
__inline__ __device__ T warp_shfl_sync(T val, int src_id) {
  return __shfl(val, src_id, 32);
}

} // namespace block_utils

template <typename T, int vec_size> struct alignas(sizeof(T) * vec_size) vec_t {
  T data[vec_size];
  __device__ __forceinline__ T &operator[](int i) { return data[i]; }
  __device__ __forceinline__ T const &operator[](int i) const {
    return data[i];
  }
  __device__ __forceinline__ void load(const T *ptr) {
    *this = *reinterpret_cast<vec_t<T, vec_size> *>(const_cast<T *>(ptr));
  }
  __device__ __forceinline__ void loop_load(const T *ptr) {
#pragma unroll
    for (int i = 0; i < vec_size; ++i) {
      data[i] = ptr[i];
    }
  }
  __device__ __forceinline__ void store(T *ptr) {
    *reinterpret_cast<vec_t<T, vec_size> *>(ptr) = *this;
  }
  __device__ __forceinline__ void loop_store(T *ptr) {
#pragma unroll
    for (int i = 0; i < vec_size; ++i) {
      ptr[i] = data[i];
    }
  }
  __device__ __forceinline__ void nontemporal_load(const T *ptr) {
    constexpr int ITERS = vec_size * sizeof(T) / sizeof(uint32_t);
#pragma unroll
    for (int i = 0; i < ITERS; ++i) {
      reinterpret_cast<uint32_t *>(&data)[i] =
          __builtin_nontemporal_load((uint32_t *)ptr + i);
    }
  }
  __device__ __forceinline__ void nontemporal_store(T *ptr) {
    constexpr int ITERS = vec_size * sizeof(T) / sizeof(uint32_t);
#pragma unroll
    for (int i = 0; i < ITERS; ++i) {
      __builtin_nontemporal_store(reinterpret_cast<uint32_t *>(&data)[i],
                                  (uint32_t *)ptr + i);
    }
  }
  __device__ __forceinline__ void fill(T val) {
#pragma unroll
    for (int i = 0; i < vec_size; ++i) {
      data[i] = val;
    }
  }
};

template <typename T, int vec_size>
__inline__ __device__ vec_t<T, vec_size>
warp_shfl_sync_vec(vec_t<T, vec_size> &val, int offset) {
  constexpr int ITERS = vec_size * sizeof(T) / sizeof(uint32_t);
  vec_t<T, vec_size> out;
#pragma unroll
  for (int i = 0; i < ITERS; ++i) {
    uint32_t val_ = reinterpret_cast<uint32_t *>(&val)[i];
    reinterpret_cast<uint32_t *>(&out)[i] =
        block_utils::warp_shfl_sync<uint32_t>(val_, offset);
  }
  return out;
}

template <typename T, int VEC_SIZE>
__device__ __forceinline__ void warp_rms_norm_(vec_t<T, VEC_SIZE> &input,
                                               vec_t<T, VEC_SIZE> &gamma,
                                               float rms_dim, float rms_eps) {
  vec_t<T, VEC_SIZE> norm_out;
  float acc = 0.f;
#pragma unroll
  for (int i = 0; i < VEC_SIZE; ++i) {
    float v = (float)input[i];
    acc += v * v;
  }
  int warp_id = threadIdx.x / 32;
  int warp_t_id = threadIdx.x % 32;
  acc = block_utils::warp_reduce_sum<float>(acc);
  acc = block_utils::warp_shfl_sync<float>(acc, 0);
  auto s_val = rsqrtf(acc / rms_dim + rms_eps);
#pragma unroll
  for (int i = 0; i < VEC_SIZE; ++i) {
    input[i] = static_cast<T>((float)input[i] * s_val * (float)gamma[i]);
  }
}

template <typename T, int VEC_SIZE, int HEAD_SIZE, bool IS_INTERLEAVED, int M>
__device__ __forceinline__ void mrope_load_cos_sin_vec(
    vec_t<T, VEC_SIZE> &out, const T *cos_sin, const int64_t *positions,
    int64_t ps0, int64_t ps1, int64_t token_id, int64_t num_tokens,
    int access_id_in_head, std::array<int64_t, M> &mrope_section) {
  constexpr int HALF_HEAD_SIZE = HEAD_SIZE / 2;
  if constexpr (IS_INTERLEAVED) {
    for (int i = 0; i < VEC_SIZE; ++i) {
      auto id = access_id_in_head + i;
      auto id_ =
          (access_id_in_head < HALF_HEAD_SIZE) ? id : id - HALF_HEAD_SIZE;
      auto mid_ = id_ % M;
      if (mid_ >= 1 && id_ < mrope_section[mid_] * M) {
        auto p = positions[mid_ * ps0 + token_id * ps1];
        out[i] = cos_sin[p * HEAD_SIZE + id];
      } else {
        out[i] = cos_sin[positions[token_id * ps1] * HEAD_SIZE + id];
      }
    }
  } else {
    for (int i = 0; i < VEC_SIZE; ++i) {
      auto id = access_id_in_head + i;
      auto id_ =
          (access_id_in_head < HALF_HEAD_SIZE) ? id : id - HALF_HEAD_SIZE;
      int mid;
      int end = 0;
      for (mid = 0; mid < M; ++mid) {
        end += mrope_section[mid];
        if (id_ < end)
          break;
      }
      auto p = positions[mid * ps0 + token_id * ps1];
      out[i] = cos_sin[p * HEAD_SIZE + id];
    }
  }
}

template <typename T, int HEAD_SIZE, bool IS_MROPE, bool IS_INTERLEAVED, int M>
__global__ void fused_mrope_rms_neox_kernel(
    const T *qkv, const T *q_w, const T *k_w, const T *cos_sin,
    const int64_t *positions, int64_t ps0, int64_t ps1, int64_t num_heads_q,
    int64_t num_heads_k, int64_t num_heads_v, double eps,
    std::array<int64_t, M> mrope_section, int64_t num_tokens,
    int64_t total_warps, T *q, T *k_cache, T *v_cache, int64_t *kv_loc) {
  constexpr int VEC_SIZE = HEAD_SIZE / 32;
  constexpr int HALF_HEAD_SIZE = HEAD_SIZE / 2;
  constexpr int NUM_WARPS_PER_BLOCK = BLOCK_SIZE / 32;

  const auto warp_id = threadIdx.x / 32;
  const auto global_warp_id = blockIdx.x * NUM_WARPS_PER_BLOCK + warp_id;
  if (global_warp_id >= total_warps) {
    return;
  }
  const auto num_heads_total = num_heads_q + num_heads_k + num_heads_v;
  const auto num_heads_qk = num_heads_q + num_heads_k;
  auto token_id = global_warp_id / num_heads_total;
  auto head_id_in_token = global_warp_id % num_heads_total;

  bool is_q = head_id_in_token < num_heads_q;
  bool is_k = !is_q && (head_id_in_token < num_heads_qk);
  bool is_v = !is_q && !is_k;

  auto access_id_in_head = (threadIdx.x % 32) * VEC_SIZE;
  auto qkv_offset =
      token_id * num_heads_total * HEAD_SIZE + head_id_in_token * HEAD_SIZE;
  const T *qkv_ptr = qkv + qkv_offset;
  vec_t<T, VEC_SIZE> x_vec;
  x_vec.load(qkv_ptr + access_id_in_head);

  if (is_v) {
    auto v_head_id = head_id_in_token - num_heads_qk;
    auto v_offset =
        kv_loc[token_id] * num_heads_v * HEAD_SIZE + v_head_id * HEAD_SIZE;
    x_vec.store(v_cache + v_offset + access_id_in_head);
    return;
  }

  auto neighbor_offset = access_id_in_head < HALF_HEAD_SIZE
                             ? HALF_HEAD_SIZE / VEC_SIZE
                             : -HALF_HEAD_SIZE / VEC_SIZE;
  vec_t<T, VEC_SIZE> w_vec, cos_sin_vec;
  if (is_q) {
    w_vec.load(q_w + access_id_in_head);
  } else {
    w_vec.load(k_w + access_id_in_head);
  }

  if constexpr (IS_MROPE) {
    mrope_load_cos_sin_vec<T, VEC_SIZE, HEAD_SIZE, IS_INTERLEAVED, M>(
        cos_sin_vec, cos_sin, positions, ps0, ps1, token_id, num_tokens,
        access_id_in_head, mrope_section);
  } else {
    auto position_ = positions[token_id * ps1];
    cos_sin_vec.load(&cos_sin[position_ * HEAD_SIZE + access_id_in_head]);
  }

  warp_rms_norm_<T, VEC_SIZE>(x_vec, w_vec, HEAD_SIZE, eps);
  auto nb_cos_sin_vec = warp_shfl_sync_vec<T, VEC_SIZE>(
      cos_sin_vec, threadIdx.x + neighbor_offset);
  auto nb_x_vec =
      warp_shfl_sync_vec<T, VEC_SIZE>(x_vec, threadIdx.x + neighbor_offset);
  vec_t<T, VEC_SIZE> out_vec;
  if (neighbor_offset > 0) {
#pragma unroll
    for (int i = 0; i < VEC_SIZE; ++i) {
      out_vec[i] =
          (float)x_vec[i] * (float)cos_sin_vec[i] -
          (float)nb_x_vec[i] * (float)nb_cos_sin_vec[i]; // x0 * cos - x1 * sin
    }
  } else {
#pragma unroll
    for (int i = 0; i < VEC_SIZE; ++i) {
      out_vec[i] =
          (float)x_vec[i] * (float)nb_cos_sin_vec[i] +
          (float)nb_x_vec[i] * (float)cos_sin_vec[i]; // x1 * cos + x0 * sin
    }
  }
  if (is_q) {
    auto q_offset =
        token_id * num_heads_q * HEAD_SIZE + head_id_in_token * HEAD_SIZE;
    out_vec.store(q + q_offset + access_id_in_head);
  } else { // is_k
    auto k_head_id = head_id_in_token - num_heads_q;
    auto k_offset =
        kv_loc[token_id] * num_heads_k * HEAD_SIZE + k_head_id * HEAD_SIZE;
    out_vec.store(k_cache + k_offset + access_id_in_head);
  }
}

template <typename T, int HEAD_SIZE, bool IS_MROPE, bool IS_INTERLEAVED, int M>
__global__ void fused_mrope_rms_noneox_kernel(
    const T *qkv, const T *q_w, const T *k_w, const T *cos_sin,
    const int64_t *positions, int64_t ps0, int64_t ps1, int64_t num_heads_q,
    int64_t num_heads_k, int64_t num_heads_v, double eps,
    std::array<int64_t, M> mrope_section, int64_t num_tokens,
    int64_t total_warps, T *q, T *k_cache, T *v_cache, int64_t *kv_loc) {
  constexpr int VEC_SIZE = HEAD_SIZE / 32;
  constexpr int HALF_HEAD_SIZE = HEAD_SIZE / 2;
  const auto warp_id = threadIdx.x / 32;
  constexpr int NUM_WARPS_PER_BLOCK = BLOCK_SIZE / 32;
  const auto global_warp_id = blockIdx.x * NUM_WARPS_PER_BLOCK + warp_id;
  if (global_warp_id >= total_warps) {
    return;
  }
  const auto num_heads_total = num_heads_q + num_heads_k + num_heads_v;
  const auto num_heads_qk = num_heads_q + num_heads_k;
  auto token_id = global_warp_id / num_heads_total;
  auto head_id_in_token = global_warp_id % num_heads_total;

  bool is_q = head_id_in_token < num_heads_q;
  bool is_k = !is_q && (head_id_in_token < num_heads_qk);
  bool is_v = !is_q && !is_k;

  auto access_id_in_head = (threadIdx.x % 32) * VEC_SIZE;
  auto qkv_offset =
      token_id * num_heads_total * HEAD_SIZE + head_id_in_token * HEAD_SIZE;
  const T *qkv_ptr = qkv + qkv_offset;
  vec_t<T, VEC_SIZE> x_vec;
  x_vec.load(qkv_ptr + access_id_in_head);

  if (is_v) {
    auto v_head_id = head_id_in_token - num_heads_qk;
    auto v_offset =
        kv_loc[token_id] * num_heads_v * HEAD_SIZE + v_head_id * HEAD_SIZE;
    x_vec.store(v_cache + v_offset + access_id_in_head);
    return;
  }

  vec_t<T, VEC_SIZE> w_vec, cos_vec, sin_vec;

  if (is_q) {
    w_vec.load(q_w + access_id_in_head);
  } else {
    w_vec.load(k_w + access_id_in_head);
  }

  if constexpr (IS_MROPE) {
    mrope_load_cos_sin_vec<T, VEC_SIZE, HEAD_SIZE, IS_INTERLEAVED, M>(
        cos_vec, cos_sin, positions, ps0, ps1, token_id, num_tokens,
        access_id_in_head / 2, mrope_section);
    mrope_load_cos_sin_vec<T, VEC_SIZE, HEAD_SIZE, IS_INTERLEAVED, M>(
        sin_vec, cos_sin, positions, ps0, ps1, token_id, num_tokens,
        access_id_in_head / 2 + HALF_HEAD_SIZE, mrope_section);
  } else {
    auto position_ = positions[token_id * ps1];
    cos_vec.load(&cos_sin[position_ * HEAD_SIZE + access_id_in_head / 2]);
    sin_vec.load(&cos_sin[position_ * HEAD_SIZE + access_id_in_head / 2 +
                          HALF_HEAD_SIZE]);
  }

  warp_rms_norm_<T, VEC_SIZE>(x_vec, w_vec, HEAD_SIZE, eps);

  vec_t<T, VEC_SIZE> out_vec;
#pragma unroll
  for (int i = 0; i < VEC_SIZE / 2; ++i) {
    out_vec[2 * i + 0] = (float)x_vec[2 * i + 0] * (float)cos_vec[i] -
                         (float)x_vec[2 * i + 1] * (float)sin_vec[i];
    out_vec[2 * i + 1] = (float)x_vec[2 * i + 1] * (float)cos_vec[i] +
                         (float)x_vec[2 * i + 0] * (float)sin_vec[i];
  }

  if (is_q) {
    auto q_offset =
        token_id * num_heads_q * HEAD_SIZE + head_id_in_token * HEAD_SIZE;
    out_vec.store(q + q_offset + access_id_in_head);
  } else { // is_k
    auto k_head_id = head_id_in_token - num_heads_q;
    auto k_offset =
        kv_loc[token_id] * num_heads_k * HEAD_SIZE + k_head_id * HEAD_SIZE;
    out_vec.store(k_cache + k_offset + access_id_in_head);
  }
}

template <typename T>
void fused_rope_rms_set_kv(const T *qkv, const T *q_w, const T *k_w,
                           const T *cos_sin, const int64_t *positions,
                           int64_t ps0, int64_t ps1, int64_t num_tokens,
                           int64_t num_heads_q, int64_t num_heads_k,
                           int64_t num_heads_v, int64_t head_size,
                           bool is_neox_style, double eps, T *q, T *k_cache,
                           T *v_cache, int64_t *kv_loc, hipStream_t stream) {
  TORCH_CHECK(head_size == 64 || head_size == 128 || head_size == 256);
  constexpr int NUM_WARPS_PER_BLOCK = BLOCK_SIZE / 32;
  auto total_warps = num_tokens * (num_heads_q + num_heads_k + num_heads_v);
  dim3 threadsPerBlock(BLOCK_SIZE);
  dim3 numBlocks((total_warps + NUM_WARPS_PER_BLOCK - 1) / NUM_WARPS_PER_BLOCK);
  std::array<int64_t, 1> mrope_section = {0};

#define DISPATCH_NEOX(HEAD_SIZE)                                               \
  if (is_neox_style) {                                                         \
    fused_mrope_rms_neox_kernel<T, HEAD_SIZE, false, false, 1>                 \
        <<<numBlocks, threadsPerBlock, 0, stream>>>(                           \
            qkv, q_w, k_w, cos_sin, positions, ps0, ps1, num_heads_q,          \
            num_heads_k, num_heads_v, eps, mrope_section, num_tokens,          \
            total_warps, q, k_cache, v_cache, kv_loc);                         \
  } else {                                                                     \
    fused_mrope_rms_noneox_kernel<T, HEAD_SIZE, false, false, 1>               \
        <<<numBlocks, threadsPerBlock, 0, stream>>>(                           \
            qkv, q_w, k_w, cos_sin, positions, ps0, ps1, num_heads_q,          \
            num_heads_k, num_heads_v, eps, mrope_section, num_tokens,          \
            total_warps, q, k_cache, v_cache, kv_loc);                         \
  }

  switch (head_size) {
  case 64:
    DISPATCH_NEOX(64)
    break;
  case 128:
    DISPATCH_NEOX(128)
    break;
  case 256:
    DISPATCH_NEOX(256)
    break;
  }

#undef DISPATCH_NEOX
}

static constexpr int WARP_SIZE = 32;

struct alignas(1) fp8e4m3fn {
  enum {
    max_value = 240,
  };
  struct from_bits_t {};
  __host__ __device__ static constexpr from_bits_t from_bits() {
    return from_bits_t();
  }
  uint8_t data;

  fp8e4m3fn() = default;
  __host__ __device__ constexpr fp8e4m3fn(const fp8e4m3fn &) = default;
  __host__ __device__ constexpr fp8e4m3fn(uint8_t v) = delete;
  explicit __host__ __device__ constexpr fp8e4m3fn(uint8_t v, from_bits_t)
      : data(v) {}

  explicit __host__ __device__ fp8e4m3fn(float v) {
    data = hip_fp8_impl::to_float8<4, 3, float, false /*negative_zero_nan*/,
                                   true /*clip*/>(v);
  }

  explicit __host__ __device__ fp8e4m3fn(double v)
      : fp8e4m3fn(static_cast<float>(v)) {}

  explicit inline __host__ __device__ operator float() const {
    return hip_fp8_impl::from_float8<4, 3, float, false /*negative_zero_nan*/>(
        data);
  }
};

template <typename T, int VEC_SIZE, typename OutT>
__device__ __forceinline__ vec_t<OutT, VEC_SIZE>
convert_to(vec_t<T, VEC_SIZE> &in_vec, float scale) {
  vec_t<OutT, VEC_SIZE> out_vec;
#pragma unroll
  for (int i = 0; i < VEC_SIZE; ++i) {
    volatile float out = static_cast<float>(in_vec[i]) / scale;
    out_vec[i] = static_cast<OutT>(out);
  }
  return out_vec;
}

} // namespace rope_rms

template <typename T> struct KernelElementType {
  using type = T;
};

template <> struct KernelElementType<c10::Half> {
  using type = __half;
};

template <> struct KernelElementType<c10::BFloat16> {
  using type = hip_bfloat16;
};

void fused_rope_rms_set_kv(Tensor &qkv, Tensor &qw, Tensor &kw, Tensor &cos_sin,
                           Tensor &positions, int64_t num_tokens,
                           int64_t num_heads_q, int64_t num_heads_k,
                           int64_t num_heads_v, int64_t head_size,
                           bool is_neox_style, double eps, Tensor &q,
                           Tensor &k_cache, Tensor &v_cache, Tensor &kv_loc) {
  const at::hip::OptionalHIPGuardMasqueradingAsCUDA device_guard(
      device_of(qkv));
  auto stream = c10::hip::getCurrentHIPStreamMasqueradingAsCUDA().stream();
  auto pos_strides = positions.strides();
  TORCH_CHECK(pos_strides.size() == 1);
  AT_DISPATCH_FLOATING_TYPES_AND2(
      kBFloat16, kHalf, qkv.scalar_type(), "fused_rope_rms_set_kv", [&] {
        using T = KernelElementType<scalar_t>::type;
        rope_rms::fused_rope_rms_set_kv<T>(
            (T *)qkv.data_ptr<scalar_t>(), (T *)qw.data_ptr<scalar_t>(),
            (T *)kw.data_ptr<scalar_t>(), (T *)cos_sin.data_ptr<scalar_t>(),
            positions.data_ptr<int64_t>(), 0, pos_strides[0], num_tokens,
            num_heads_q, num_heads_k, num_heads_v, head_size, is_neox_style,
            eps, (T *)q.data_ptr<scalar_t>(), (T *)k_cache.data_ptr<scalar_t>(),
            (T *)v_cache.data_ptr<scalar_t>(), kv_loc.data_ptr<int64_t>(),
            stream);
      });
}
