// SPDX-License-Identifier: MIT
// Copyright (c) 2024, Advanced Micro Devices, Inc. All rights reserved.
#include "trtllm_all_reduce_fusion.h"

PYBIND11_MODULE(TORCH_EXTENSION_NAME, m)
{
    m.def("trtllm_init_ar_fusion", &trtllm::init_ar_fusion);                                   \
    m.def("trtllm_destroy_ar_fusion", &trtllm::destroy_ar_fusion);                             \
    m.def("trtllm_get_ar_fusion_barrier_handle", &trtllm::get_ar_fusion_barrier_handle);       \
    m.def("trtllm_get_ar_fusion_data_handle", &trtllm::get_ar_fusion_data_handle);             \
    m.def("trtllm_open_ar_fusion_barrier_handles", &trtllm::open_ar_fusion_barrier_handles);   \
    m.def("trtllm_open_ar_fusion_data_handles", &trtllm::open_ar_fusion_data_handles);         \
    m.def("trtllm_ar_fusion_capture_clear", &trtllm::ar_fusion_capture_clear);                 \
    m.def("trtllm_get_ar_fusion_captured_handles", &trtllm::get_ar_fusion_captured_handles);   \
    m.def("trtllm_get_ar_fusion_captured_offsets", &trtllm::get_ar_fusion_captured_offsets);   \
    m.def("trtllm_open_ar_fusion_captured_handles", &trtllm::open_ar_fusion_captured_handles); \
    m.def("trtllm_allreduce_rms", &trtllm::allreduce_rms);
}
