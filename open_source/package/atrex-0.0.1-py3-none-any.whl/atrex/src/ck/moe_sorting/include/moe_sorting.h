// SPDX-License-Identifier: MIT
// Copyright (C) 2024-2025, Advanced Micro Devices, Inc. All rights reserved.
#pragma once
#include <torch/extension.h>

void moe_sorting_fwd(torch::Tensor &topk_ids,
                     torch::Tensor &topk_weights,
                     torch::Tensor &sorted_token_ids,
                     torch::Tensor &sorted_weights,
                     torch::Tensor &sorted_expert_ids,
                     torch::Tensor &num_valid_ids,
                     torch::Tensor &moe_buf,
                     int num_experts,
                     int unit_size,
                     std::optional<torch::Tensor> local_expert_mask = std::nullopt,
                     std::optional<torch::Tensor> num_local_tokens = std::nullopt,
                     int dispatch_policy = 0);
