#include "jenga_sparse_attention.hpp"

PYBIND11_MODULE(TORCH_EXTENSION_NAME, m) {
  m.def("jenga_sparse_attention", &jenga_sparse_attention,
        "jenga_sparse_attention", py::arg("TQ"), py::arg("TK"), py::arg("TV"),
        py::arg("Tkv_block_idx"), py::arg("Tkv_blocks"), py::arg("out"),
        py::arg("bias") = std::nullopt, py::arg("lse") = std::nullopt,
        py::arg("seqstart_q") = std::nullopt,
        py::arg("seqstart_k") = std::nullopt, py::arg("bias_type") = 0,
        py::arg("batch") = 0, py::arg("nhead") = 0, py::arg("nhead_k") = 0,
        py::arg("seqlen_q") = 0, py::arg("seqlen_k") = 0, py::arg("hdim_q") = 0,
        py::arg("hdim_v") = 0, py::arg("mode") = 0, py::arg("i_perm") = true,
        py::arg("o_perm") = true, py::arg("max_seqlen_q") = 0,
        py::arg("max_seqlen_k") = 0, py::arg("data_type") = "fp16");
}