def _lazy_import_and_call(func_name, module_name):
    def wrapper(*args, **kwargs):
        module = __import__(module_name, fromlist=[func_name])
        func = getattr(module, func_name)

        globals()[wrapper.__name__] = func
        return func(*args, **kwargs)
    return wrapper

# lazy import
qserve_w4a8_per_group_gemm = _lazy_import_and_call("qserve_w4a8_per_group_gemm", "atrex.api.qserver_w4a8_per_group_gemm")
qserve_w4a8_wrapper = _lazy_import_and_call("qserve_w4a8_wrapper", "atrex.api.qserver_w4a8_per_group_gemm")
qserve_cutlass_get_workspace_size = _lazy_import_and_call("qserve_cutlass_get_workspace_size", "atrex.api.qserver_w4a8_per_group_gemm")
qserve_get_workspace_size = _lazy_import_and_call("qserve_get_workspace_size", "atrex.api.qserver_w4a8_per_group_gemm")
sparse_attention_ck = _lazy_import_and_call("sparse_attention_ck", "atrex.api.jenga_sparse_attention")
gated_delta_net_pre = _lazy_import_and_call("gated_delta_net_pre", "atrex.api.gated_delta_net_pre")
paged_attention_decode = _lazy_import_and_call("paged_attention_decode", "atrex.api.paged_attention_decode")
fused_rope_rms_set_kv = _lazy_import_and_call("fused_rope_rms_set_kv", "atrex.api.fused_mrope_rms_split")
gemm_csv_parse = _lazy_import_and_call("gemm_csv_parse", "atrex.api.utils.gemm_utils")
convert_to_qserve_format_cutlass = _lazy_import_and_call("convert_to_qserve_format_cutlass", "atrex.api.utils.gemm_utils")
allreduce_residual_rmsnorm = _lazy_import_and_call("allreduce_residual_rmsnorm", "atrex.api.trt_allreduce")
fused_moe = _lazy_import_and_call("fused_moe", "atrex.api.fused_moe")