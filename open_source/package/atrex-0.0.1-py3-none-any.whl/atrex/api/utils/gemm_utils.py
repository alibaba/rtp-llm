import pandas as pd
import torch
import os
from ..qserver_w4a8_per_group_gemm import qserve_w4a8_universal_gemm_cutlass
from ...core.compile_cu import config_dir
import logging
import bisect

GEMM_TUNE_KEYS = ["block_m", "block_n", "block_k", "warp_m", "warp_n", "warp_k", "stages", "split_k_factor"]

def ceil_in_list(lst, value):
    idx = bisect.bisect_left(lst, value)
    if idx < len(lst):
        return lst[idx]
    
    return lst[-1]

def gemm_csv_parse(kernel_name, M, N, K):
    os_config_path = os.getenv("AUTOTUNE_CONFIG_PATH")
    csv_file = f"{config_dir}/{kernel_name}.csv" if not os_config_path else f"{os_config_path}/{kernel_name}.csv"
    if not os.path.exists(csv_file):
        logging.warning(f"{csv_file} not exists!")
        return None
    df = pd.read_csv(csv_file, encoding='utf-8')
    mini_df = df[(df['N'] == N) & (df['K'] == K) & (df['kernel_name'] == kernel_name) & (df['platform'] == torch.cuda.get_device_name(0))]
    df_m = mini_df["M"].tolist()
    if len(df_m) == 0:
        return None
    
    if M in df_m:
        row_ = mini_df.loc[mini_df['M'] == M].index
    else:
        df_m.sort()
        M_up = ceil_in_list(df_m, M)
        row_ = mini_df.loc[mini_df['M'] == M_up].index
    
    config = {k: df[k][row_].tolist() for k in GEMM_TUNE_KEYS}

    return config

def convert_to_qserve_format_cutlass(qweight, chn_scale, scale_i8, zero_i8, group_size, config=None):
    try:
        WARP_N = config["warp_n"][0]
    except:
        config = qserve_w4a8_universal_gemm_cutlass.default_config
        WARP_N = config["warp_n"][0]
    
    assert qweight.min() >= 0 and qweight.max() <= 15, "Quantized weight out of range"
    in_features = qweight.shape[1]
    out_features = qweight.shape[0]
    assert in_features % 32 == 0, "Input features must be divisible by 32"
    assert out_features % 32 == 0, "Output features must be divisible by 32"
    assert group_size == 128, "Group size must be 128"
    assert (
        in_features % group_size == 0
    ), "Input features must be divisible by group_size"

    # ---- Repack the weight ---- #
    # pack to M // 32, K // 32, (8, 4), ([2], 2, 2, 4)
    qweight_unpack_reorder = (
        qweight.permute(1,0).reshape(in_features, out_features//16, 2, 8).permute(0,1,3,2)
        .contiguous().to(torch.int8)
    )

    # B_fp16_reorder = B_fp16_reorder[:, :, :, :, :, :, [3, 2, 1, 0]].contiguous()
    # [16, 0, 17, 1, ...]
    qweight_unpack_repacked = (
        qweight_unpack_reorder[..., 1] << 4
    ) + qweight_unpack_reorder[..., 0]

    qweight_unpack_repacked = qweight_unpack_repacked.reshape(
        in_features, out_features // 2
    )

    qweight_unpack_repacked = qweight_unpack_repacked.permute(1,0).contiguous()
    
    # TODO(sumu): support INTERLEAVED_K=64
    INTERLEAVED_K = 128
    qweight_unpack_repacked = qweight_unpack_repacked.reshape(
        out_features // 2, in_features // INTERLEAVED_K, INTERLEAVED_K).permute(1, 0, 2).contiguous()

    # ---- Pack the scales ---- #
    chn_scale = chn_scale.reshape(out_features)

    scale_i8 = (
        scale_i8.reshape(out_features, in_features // group_size)
        .transpose(0, 1)
        .contiguous()
    )

    scale_i8 = (
        scale_i8.reshape(in_features // group_size, out_features // WARP_N, WARP_N // 8, 8)
        .permute(0, 1, 3, 2)
        .contiguous()
    )
    scale_i8 = scale_i8.reshape(in_features // group_size, out_features).contiguous()

    # ---- Pack the zeros ---- #
    zero_i8 = -zero_i8
    # zero_i8 = zero_i8.int()  # convert to 2-complement

    zero_i8 = (
        zero_i8.reshape(out_features, in_features // group_size)
        .transpose(0, 1)
        .contiguous()
    )
    # for the last dimension, organize as 0, 8, 16, 24, 1, 9, 17, 25, ... following the requirement of tensor core gemm
    zero_i8 = (
        zero_i8.reshape(in_features // group_size, out_features // WARP_N, WARP_N // 8, 8)
        .permute(0, 1, 3, 2)
        .contiguous()
    )
    zero_i8 = (
        zero_i8.reshape(in_features // group_size, out_features).contiguous() * scale_i8
    )

    return qweight_unpack_repacked, chn_scale, scale_i8, zero_i8