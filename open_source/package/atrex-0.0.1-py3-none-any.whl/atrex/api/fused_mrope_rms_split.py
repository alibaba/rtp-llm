# SPDX-License-Identifier: MIT
# Copyright (C) 2024-2025, Advanced Micro Devices, Inc. All rights reserved.

from torch import Tensor
from ..core.compile_hip import hip_kernel
from typing import List

@hip_kernel(md_name="module_fused_mrope_rms")
def fused_rope_rms_set_kv(
    qkv: Tensor,
    qw: Tensor,
    kw: Tensor,
    cos_sin: Tensor,
    positions: Tensor,
    num_tokens: int,
    num_heads_q: int,
    num_heads_k: int,
    num_heads_v: int,
    head_size: int,
    is_neox_style: bool,
    eps: float,
    q: Tensor,
    k_cache: Tensor,
    v_cache: Tensor,
    kv_loc: Tensor,
) -> None: ...
