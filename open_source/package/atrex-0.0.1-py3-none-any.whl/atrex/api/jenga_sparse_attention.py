import torch
from torch import Tensor
from typing import Optional
from ..core.compile_ck import ck_kernel


@ck_kernel(
    params=[["mod", "hdim_q", "bias_type", "dtype"]]
)
def jenga_sparse_attention(
    TQ: Tensor,
    TK: Tensor,
    TV: Tensor,
    Tkv_block_idx: Tensor,
    Tkv_blocks: Tensor,
    out: Tensor,
    bias: Optional[Tensor] = None,
    lse: Optional[Tensor] = None,
    seqstart_q: Optional[Tensor] = None,
    seqstart_k: Optional[Tensor] = None,
    bias_type: int = 0,
    batch: int = 0,
    nhead: int = 0,
    nhead_k: int = 0,
    seqlen_q: int = 0,
    seqlen_k: int = 0,
    hdim_q: int = 0,
    hdim_v: int = 0,
    mod: int = 0,
    i_perm: bool = True,
    o_perm: bool = True,
    max_seq_len_q: int = 0,
    max_seq_len_k: int = 0,
    dtype: str = "fp16"
) -> Tensor: ...


def sparse_attention_ck(
        TQ,
        TK,
        TV,
        Tkv_block_idx,
        Tkv_blocks,
        out,
        bias=None,
        lse=None,
        seqstart_q=None,
        seqstart_k=None,
        bias_type=0,
        batch=0,
        nhead=0,
        nhead_k=0,
        seqlen_q=0,
        seqlen_k=0,
        hdim_q=0,
        hdim_v=0,
        mod=0,
        i_perm=True,
        o_perm=True,
        max_seq_len_q=0,
        max_seq_len_k=0):
    dtype = "fp16"
    if TQ.dtype == torch.bfloat16:
        dtype = "bf16"
    elif TQ.dtype == torch.float32:
        dtype = "fp32"
    assert (
        seqlen_q + 127) // 128 == Tkv_block_idx.size(2), "tile_size only support (128,128)"
    return jenga_sparse_attention(
        TQ,
        TK,
        TV,
        Tkv_block_idx,
        Tkv_blocks,
        out,
        bias,
        lse,
        seqstart_q,
        seqstart_k,
        bias_type,
        batch,
        nhead,
        nhead_k,
        seqlen_q,
        seqlen_k,
        hdim_q,
        hdim_v,
        mod,
        i_perm,
        o_perm,
        max_seq_len_q,
        max_seq_len_k,
        dtype)
