import torch
from torch import Tensor
from typing import Optional
from ..core.compile_cu import cuda_kernel
import logging

@cuda_kernel(
    default_config={
    "block_m": [32, 64],
    "block_n": [64, 64],
    "block_k": [128, 128],
    "warp_m": [32, 64],
    "warp_n": [32, 32],
    "warp_k": [64, 64],
    "stages": [2, 2]
    }
)
def qserve_w4a8_per_group_gemm(
    _in_feats: Tensor,
    _kernel: Tensor,
    _zeros: Tensor,
    _scales_i8: Tensor,
    _wscales: Tensor,
    _ascales: Tensor,
    _out_feats: Tensor,
    config: dict = None
) -> None: ...

@cuda_kernel()
def qserve_w4a8_per_group_gemm_cutlass(
    _in_feats: Tensor,
    _kernel: Tensor,
    _zeros: Tensor,
    _scales_i8: Tensor,
    _wscales: Tensor,
    _ascales: Tensor,
    _problem_sizes_device: Tensor,
    _alpha_ptr_array: Tensor,
    _lda: Tensor,
    _ldb: Tensor,
    _ldo: Tensor,
    _out_feats: Tensor,
    problem_count: int
) -> None: ...

@cuda_kernel(
    default_config={
        "block_m": [32, 64],
        "block_n": [64, 64],
        "block_k": [128, 128],
        "warp_m": [32, 64],
        "warp_n": [16, 16],
        "warp_k": [128, 128],
        "stages": [2, 2],
        "split_k_factor": [1, 2]
    },
    kernel_type="gemm",
    explore_keys=["block_m", "block_n", "block_k", "warp_m", "warp_n", "warp_k"],
    key_name="GemmUniversalW4A8"
)
def qserve_w4a8_universal_gemm_cutlass(
    _in_feats: Tensor,
    _kernel: Tensor,
    _zeros: Tensor,
    _scales_i8: Tensor,
    _wscales: Tensor,
    _ascales: Tensor,
    _out_feats: Tensor,
    workspace: Tensor,
    M: int, N: int, K: int,
    config: dict = None
) -> float: ...

@cuda_kernel(
    default_config={
        "block_m": [32, 64],
        "block_n": [64, 64],
        "block_k": [128, 128],
        "warp_m": [32, 64],
        "warp_n": [16, 16],
        "warp_k": [128, 128],
        "stages": [2, 2],
        "split_k_factor": [1, 2]
    },
    kernel_type="gemm",
    link_kernel="qserve_w4a8_universal_gemm_cutlass"
)
def qserve_cutlass_get_workspace_size(
    M: int, N: int, K: int,
    config: dict = None
) -> int: ...

def qserve_get_workspace_size(
    M: int, N: int, K: int,
    config: dict = None
) -> int:
    
    workspace_size = qserve_cutlass_get_workspace_size(
        M, N, K,
        config
    )

    logging.info(f"{M}, {N}, {K}, {config} get workspace_size: {workspace_size}")

    return workspace_size
    

def qserve_w4a8_wrapper(
    _in_feats: Tensor,
    _kernel: Tensor,
    _zeros: Tensor,
    _scales_i8: Tensor,
    _wscales: Tensor,
    _ascales: Tensor,
    _out_feats: Tensor,
    workspace: Tensor,
    M: int, N: int, K: int,
    config: dict = None
):
    assert M == _in_feats.size(0) and K == _in_feats.size(1), "_in_feats shape mismatch, _in_feats only support RowMajor"
    assert N == _out_feats.size(1), "_out_feats shape mismatch, _out_feats only support RowMajor"
    return qserve_w4a8_universal_gemm_cutlass(
        _in_feats,
        _kernel,
        _zeros,
        _scales_i8,
        _wscales,
        _ascales,
        _out_feats,
        workspace,
        M, N, K,
        config
    )