import torch
import triton
import triton.language as tl
from atrex.src.triton.gated_delta_net_pre import gated_delta_net_pre_kernel


def gated_delta_net_pre(hidden_states: torch.Tensor, in_proj_qkvz: torch.Tensor, in_proj_ba: torch.Tensor, A_log: torch.Tensor,
                        dt_bias: torch.Tensor, beta: float = 1.0, threshold: float = 20.0):
    T, K = hidden_states.shape
    Nqkvz, _ = in_proj_qkvz.shape
    Nba, _ = in_proj_ba.shape
    num_heads = Nqkvz // 768
    num_vz_heads = num_heads * 2
    qkv_dim: tl.constexpr = 512  # q(128) + k(128) + v(128 * 2)
    vz_dim: tl.constexpr = 128
    b_dim: tl.constexpr = 2
    a_dim: tl.constexpr = 2

    Nqkv = num_heads * qkv_dim
    Nz = num_vz_heads * vz_dim
    Nb = num_heads * b_dim
    Na = num_heads * a_dim

    qkv = torch.empty((T, Nqkv), device=hidden_states.device, dtype=torch.bfloat16)
    z = torch.empty((T, Nz), device=hidden_states.device, dtype=torch.bfloat16)
    b = torch.empty((T, Nb), device=hidden_states.device, dtype=torch.bfloat16)
    g = torch.empty((T, Na), device=hidden_states.device, dtype=torch.float32)

    BLOCK_SIZE_M: tl.constexpr = 16
    BLOCK_SIZE_N: tl.constexpr = 32
    BLOCK_SIZE_K: tl.constexpr = 64
    grid = (triton.cdiv(T, BLOCK_SIZE_M) *
            (triton.cdiv(Nqkvz, BLOCK_SIZE_N) + triton.cdiv(Nba, BLOCK_SIZE_N)), )

    gated_delta_net_pre_kernel[grid](
        hidden_states, in_proj_qkvz, in_proj_ba, A_log, dt_bias,
        qkv, z, b, g,
        T, Nqkv, Nz, Nb, Na, K, num_heads,
        hidden_states.stride(0), hidden_states.stride(1),
        in_proj_qkvz.stride(0), in_proj_qkvz.stride(1),
        in_proj_ba.stride(0), in_proj_ba.stride(1),
        qkv.stride(0), qkv.stride(1),
        z.stride(0), z.stride(1),
        b.stride(0), b.stride(1),
        g.stride(0), g.stride(1),
        beta, threshold,
        BLOCK_SIZE_M, BLOCK_SIZE_N, BLOCK_SIZE_K,
        num_warps=4
    )
    z = z.reshape(z.size(0), num_vz_heads, vz_dim)
    return qkv, z, b, g
