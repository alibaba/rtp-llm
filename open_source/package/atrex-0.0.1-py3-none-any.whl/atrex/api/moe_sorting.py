# SPDX-License-Identifier: MIT
# Copyright (C) 2024-2025, Advanced Micro Devices, Inc. All rights reserved.

import torch
from torch import Tensor
from typing import Optional
from ..core.compile_ck import ck_kernel


@ck_kernel(params=[[]])
def moe_sorting_fwd(
    topk_ids: Tensor,
    topk_weights: Tensor,
    sorted_token_ids: Tensor,
    sorted_weights: Tensor,
    sorted_expert_ids: Tensor,
    num_valid_ids: Tensor,
    moe_buf: Tensor,
    num_experts: int,
    unit_size: int,
    local_expert_mask: Optional[Tensor] = None,
    num_local_tokens: Optional[Tensor] = None,
    dispatch_policy: int = 0,
) -> None: ...
