# SPDX-License-Identifier: MIT
# Copyright (C) 2024-2026, Advanced Micro Devices, Inc. All rights reserved.

import functools
import logging
from typing import Optional

import torch

log = logging.getLogger(__name__)

from atrex.src.triton.fused_moe.fused_moe_helper import (
    ActivationType,
    QuantType,
    flush_cache,
    i32,
    fp32,
    moe_sorting,
    get_m_align,
    get_block_size_m,
    get_m_per_expert_avg
)

from atrex.src.triton.fused_moe.fused_moe_stage1_fp16 import fused_moe_stage1_fp16
from atrex.src.triton.fused_moe.fused_moe_stage2_split_reduce_fp16 import fused_moe_stage2_split_reduce_fp16
from atrex.src.triton.fused_moe.fused_moe_stage2_fused_reduce_fp16 import fused_moe_stage2_fused_reduce_fp16
from atrex.src.triton.fused_moe.reduce_fp16 import reduce_fp16


@functools.lru_cache(maxsize=2048)
def get_inter_dim(w1_shape, w2_shape):
    E, _, model_dim = w1_shape
    E, model_dim, inter_dim = w2_shape
    int4_war = model_dim // w1_shape[-1]
    inter_dim *= int4_war
    return E, model_dim, inter_dim


def fused_moe(
    hidden_states,
    w1,  # [expert(local_expert:EP), inter_dim*2, dim] N,K
    w2,  # [expert(local_expert:EP), dim, inter_dim]
    topk_weight,
    topk_ids,
    expert_mask: Optional[torch.tensor] = None,  # EP
    activation=ActivationType.Silu,
    quant_type=QuantType.No,
    doweight_stage1=False,
    # following for quant
    w1_scale: Optional[torch.tensor] = None,
    w2_scale: Optional[torch.tensor] = None,
    a1_scale: Optional[torch.tensor] = None,
    a2_scale: Optional[torch.tensor] = None,
    # following for tuning
    block_size_M=None,
    num_local_tokens: Optional[torch.tensor] = None,
    moe_sorting_dispatch_policy=0,
    dtype=None,
    # following for cktile support
    hidden_pad=0,
    intermediate_pad=0,
    bias1=None,
    bias2=None,
    out1_ref=None,
):
    B = hidden_states.shape[0]
    E, N1, K1 = w1.shape
    N2, K2 = w2.shape[1], w2.shape[2]
    TOPK = topk_ids.shape[1]
    assert N1 == 2 * K2
    log.debug("fused_moe enter: B=%d, E=%d, TOPK=%d, N=%d, K=%d, dtype=%s", B, E, TOPK, N1, K1, hidden_states.dtype)

    gemm1_out = torch.empty(
        [B, TOPK, N1 // 2],
        dtype=hidden_states.dtype,
        device=hidden_states.device,
    )

    M_ALIGN = get_m_align(B, TOPK, E)
    BLOCK_SIZE_M = get_block_size_m(B, TOPK, E)
    log.debug("fused_moe bucket: M=%d, M_ALIGN=%d, BLOCK_SIZE_M=%d", B, M_ALIGN, BLOCK_SIZE_M)

    sorted_ids, sorted_weights, sorted_expert_ids, num_valid_ids, moe_buf = moe_sorting(
        topk_ids,
        topk_weight,
        E,
        K1,
        hidden_states.dtype,
        BLOCK_SIZE_M,
        expert_mask,
        num_local_tokens,
        moe_sorting_dispatch_policy,
    )

    flush_cache(512)
    fused_moe_stage1_fp16(
        hidden_states, w1, gemm1_out,
        sorted_ids, sorted_weights, sorted_expert_ids, num_valid_ids,
        M_ALIGN, BLOCK_SIZE_M,
    )

    # NOTE: this is an experimental value and may be adjusted later
    if get_m_per_expert_avg(B, TOPK, E) <= 32:
        log.debug("fused_moe stage2: using fused_reduce (m_per_expert_avg=%d <= 32)", get_m_per_expert_avg(B, TOPK, E))
        flush_cache(512)
        fused_moe_stage2_fused_reduce_fp16(
            gemm1_out, w2, moe_buf,
            sorted_ids, sorted_weights, sorted_expert_ids, num_valid_ids,
            M_ALIGN, BLOCK_SIZE_M,
        )
    else:
        log.debug("fused_moe stage2: using split_reduce + reduce (m_per_expert_avg=%d > 32)", get_m_per_expert_avg(B, TOPK, E))
        moe_buf = torch.empty(
            [B, TOPK, N2],
            dtype=hidden_states.dtype,
            device=hidden_states.device,
        )

        flush_cache(512)
        fused_moe_stage2_split_reduce_fp16(
            gemm1_out, w2, moe_buf,
            sorted_ids, sorted_weights, sorted_expert_ids, num_valid_ids,
            M_ALIGN, BLOCK_SIZE_M,
        )

        flush_cache(512)
        moe_buf = reduce_fp16(moe_buf)

    return moe_buf
