# SPDX-License-Identifier: MIT
# Copyright (C) 2024-2025, Advanced Micro Devices, Inc. All rights reserved.

from typing import Optional, Tuple
import torch
import triton
import triton.experimental.gluon.language as gl

import atrex.api.utils.types as types
from atrex.api.utils.device_info import get_num_xcds

from atrex.src.triton.sage_attn.sageAttn_gluon import _attn_fwd
from atrex.src.triton.sage_attn.quant_triton import per_channel_fp8_triton, per_channel_fp8_swizzle_triton
from atrex.src.triton.sage_attn.quant_per_block import per_block_int8, per_thread_block_int8
from atrex.src.triton.sage_attn.quant_per_thread import per_thread_int8 as per_thread_int8_triton
from atrex.src.triton.sage_attn.quant_per_token import per_token_int8 as per_token_int8_triton
from atrex.src.triton.sage_attn.attn_qk_int8_per_block import forward as attn_false
from atrex.src.triton.sage_attn.attn_qk_int8_per_thread import forward as attn_false_thread

def _get_mfma_instr_shape(dtype: torch.dtype) -> Tuple[int, int, int]:
    # V_MFMA_F32_32x32x16_F16
    if dtype == torch.float16:
        return (32, 32, 8)
    # V_MFMA_F32_16x16x32_BF16
    elif dtype == torch.bfloat16:
        return (32, 32, 8)
    # V_MFMA_F32_16x16x4_F32
    elif dtype == torch.float32:
        return (16, 16, 4)
    # V_MFMA_F32_32x32x16_F8
    elif dtype == torch.float8_e4m3fnuz or dtype == torch.int8:
        return (32, 32, 16)
    else:
        raise ValueError(f"Unsupported data type for MFMA: {dtype}")

def sageattn_qk_int8_pv_fp8(
    q: torch.Tensor, 
    k: torch.Tensor, 
    v: torch.Tensor, 
    tensor_layout: str = "NHD",
    is_causal: bool =False, 
    qk_quant_gran: str = "per_thread-block",
    attn_mask: Optional[torch.Tensor] = None,
    sm_scale: Optional[float] = None, 
    smooth_k: bool = True,
    return_lse: bool = False,
    use_triton: bool = False,
    dropout_p: float = 0.0
) -> torch.Tensor:
    dtype = q.dtype
    assert q.is_cuda, "Input tensors must be on cuda."
    assert dtype in [torch.float16, torch.bfloat16], "Input tensors must be in dtype of torch.float16 or torch.bfloat16"
    assert q.device == k.device == v.device, "All tensors must be on the same device."
    assert q.dtype == k.dtype == v.dtype, "All tensors must have the same dtype."
    assert is_causal is False, "causal only support False now."
    assert tensor_layout is "NHD", "tensor_layout only support NHD now."

    if attn_mask is not None:
        assert attn_mask.dtype == torch.bool or attn_mask.dtype == q.dtype, "attn_mask must be of dtype bool or the same dtype as q."
        assert attn_mask.device == q.device, "All tensors must be on the same device."

    # FIXME(DefTruth): make sage attention work compatible with distributed 
    # env, for example, xDiT which launch by torchrun. Without this workaround, 
    # sage attention will run into illegal memory access error after first 
    # inference step in distributed env for multi gpus inference. This small
    # workaround also make sage attention work compatible with torch.compile
    # through non-fullgraph compile mode.
    torch.cuda.set_device(v.device)

    head_dim_og = q.size(-1)

    if head_dim_og < 64:
        q = torch.nn.functional.pad(q, (0, 64 - head_dim_og))
        k = torch.nn.functional.pad(k, (0, 64 - head_dim_og))
        v = torch.nn.functional.pad(v, (0, 64 - head_dim_og))
    elif head_dim_og > 64 and head_dim_og < 128:
        q = torch.nn.functional.pad(q, (0, 128 - head_dim_og))
        k = torch.nn.functional.pad(k, (0, 128 - head_dim_og))
        v = torch.nn.functional.pad(v, (0, 128 - head_dim_og))
    elif head_dim_og > 128:
        raise ValueError(f"Unsupported head_dim: {head_dim_og}")

    # assert last dim is contiguous
    assert q.stride(-1) == 1 and k.stride(-1) == 1 and v.stride(-1) == 1, "Last dim of qkv must be contiguous."

    seq_dim = 1 if tensor_layout == "NHD" else 2
    nh_dim = 2 if tensor_layout == "NHD" else 1

    if smooth_k:
        km = k.mean(dim=seq_dim, keepdim=True)
        nqheads = q.size(nh_dim)
        nkheads = k.size(nh_dim)
        q_per_kv_heads = nqheads // nkheads
        if q_per_kv_heads > 1:
            # nheads_k => nheads_q
            km_broadcast = torch.repeat_interleave(km, q_per_kv_heads, dim=nh_dim)
        else:
            km_broadcast = km
        if return_lse:
            if tensor_layout == "NHD":
                lse_correction = torch.matmul(q.transpose(1, 2), km_broadcast.transpose(1, 2).transpose(2, 3)).squeeze(-1).to(torch.float32)
            else:
                lse_correction = torch.matmul(q, km_broadcast.transpose(2, 3)).squeeze(-1).to(torch.float32)
    else:
        km = None

    if dtype == torch.bfloat16 or dtype == torch.float32:
        v = v.to(torch.float16)

    if sm_scale is None:
        sm_scale = 1.0 / (head_dim_og ** 0.5)

    config = {
        "BLOCK_M": 128,
        "BLOCK_N": 128,
        "waves_per_eu": 2,
        "num_warps": 4,
        "num_ctas": 1,
        "num_stages": 1,
        "WARPQ": 16,
        "WARPK": 128,
        "QK_QUANT_TYPE": qk_quant_gran
    }

    if qk_quant_gran == "per_block":
        q_int8, q_scale, k_int8, k_scale = per_block_int8(q, k, km=km, sm_scale=sm_scale, tensor_layout=tensor_layout)
    elif qk_quant_gran == "per_thread":
        q_int8, q_scale, k_int8, k_scale = per_thread_int8_triton(q, k, km, tensor_layout=tensor_layout, 
                                                BLKQ=config["BLOCK_M"], WARPQ=config["WARPQ"], BLKK=config["BLOCK_N"], WARPK=config["WARPK"], swizzle_k=True)
    elif qk_quant_gran == "per_token":
        q_int8, q_scale = per_token_int8_triton(q)
        k_int8, k_scale = per_token_int8_triton(k, km)
    elif qk_quant_gran == "per_thread-block":
        q_int8, q_scale, k_int8, k_scale = per_thread_block_int8(q, k, km=km, BLKQ=config["BLOCK_M"], WARPQ=config["WARPQ"], BLKK=config["BLOCK_N"], sm_scale=sm_scale, tensor_layout=tensor_layout)
        k_int8 = k_int8.reshape(k_int8.size(0),k_int8.size(1),k_int8.size(2),k_int8.size(3)//8,2,4).permute(0,1,2,4,3,5).reshape(k_int8.size(0),k_int8.size(1),k_int8.size(2),k_int8.size(3)).contiguous()
    else:
        raise NotImplementedError(f"qk_quant_gran {qk_quant_gran} not supported")

    if attn_mask is not None:
        if tensor_layout == "HND":
            target_shape = (q.shape[0], q.shape[1], q.shape[2], k.shape[2])
        elif tensor_layout == "NHD":
            target_shape = (q.shape[0], q.shape[2], q.shape[1], k.shape[1])
        else:
            raise ValueError(f"tensor_layout {tensor_layout} not supported")
        try:
            attn_mask = attn_mask.expand(target_shape)
        except Exception:
            raise AssertionError(f"attn_mask shape {attn_mask.shape} cannot be broadcast to {target_shape}")

    v_fp8, v_scale, _ = per_channel_fp8_swizzle_triton(v, tensor_layout=tensor_layout, scale_max=240.0, smooth_v=False, swizzle_block=config["BLOCK_N"])
    # v_fp8 = v_fp8.reshape(v_fp8.size(0),v_fp8.size(1),v_fp8.size(2),v_fp8.size(3)//config["BLOCK_N"], config["BLOCK_N"] // 8,2,4).permute(0,1,2,3,5,4,6).reshape(v_fp8.size(0),v_fp8.size(1),v_fp8.size(2),v_fp8.size(3)).contiguous()
    # v_fp8 = v_fp8.permute(0,3,2,1)[:,:32760,:,:].to(torch.float16).contiguous()
    
    if use_triton:
        if qk_quant_gran == "per_block":
            o, lse = attn_false(q_int8, k_int8, v_fp8, q_scale, k_scale, v_scale, tensor_layout=tensor_layout, output_dtype=dtype, return_lse=return_lse)
        else:
            o, lse = attn_false_thread(q_int8, k_int8, v_fp8, q_scale, k_scale, v_scale, tensor_layout=tensor_layout, output_dtype=dtype, return_lse=return_lse, WARPQ=16, WARPK=128)
    else:
        assert qk_quant_gran in ["per_thread", "per_thread-block"], "gluon sageAttn only support per_thread quant gran now"
        o = torch.zeros((q.shape[:-1] + v.shape[-1:]), dtype=q.dtype, device=q.device)
        # only bsnd, not support varlen
        batch, seqlen_q, num_q_heads = q.shape[:-1]
        seqlen_k = k.shape[1]
        num_k_heads = k.shape[2]
        
        qk_head_dim = q.shape[-1]
        v_head_dim = v.shape[-1]
        pe_head_dim = qk_head_dim - v_head_dim
        # padding for head_dim. Power of 2 or 16
        BLOCK_DMODEL_POW2 = max(triton.next_power_of_2(v_head_dim), 16)
        BLOCK_DMODEL_PE_POW2 = (
            0 if pe_head_dim == 0 else max(triton.next_power_of_2(pe_head_dim), 16)
        )
        assert (pe_head_dim == 0 and BLOCK_DMODEL_PE_POW2 == 0) or (
            v_head_dim == BLOCK_DMODEL_POW2 and pe_head_dim == BLOCK_DMODEL_PE_POW2
        ), "Positional encoding support requires NOPE and PE head sizes to be unpadded powers of 2."

        softmax_lse = torch.zeros(
            (batch, num_q_heads, seqlen_q), device=q.device, dtype=torch.float32
        )
        stride_lse_z, stride_lse_h, stride_lse_m = softmax_lse.stride()

        # exp_scores [batch, num_q_heads, seqlen_q, seqlen_k]
        enable_dropout = dropout_p > 0.0

        # Flash Attention 2: we also launch blocks over sequence length
        grid = lambda META: (  # noqa: E731
            batch * num_q_heads * triton.cdiv(seqlen_q, META["BLOCK_M"]),
        )

        buffer_size = 16  # we want to load contiguous 128 bits at a time
        size_per_thread_d = buffer_size // q_int8.element_size()
        size_per_thread_m = triton.cdiv(
            config["BLOCK_M"] // (config["num_warps"] * 64), size_per_thread_d
        )
        size_per_thread_m = max(1, size_per_thread_m)
        size_per_thread_n = triton.cdiv(
            config["BLOCK_N"] // (config["num_warps"] * 64), size_per_thread_d
        )
        size_per_thread_n = max(1, size_per_thread_n)

        mfma_instr_shape_m, mfma_instr_shape_n, mfma_instr_shape_k = _get_mfma_instr_shape(
            q_int8.dtype
        )

        num_blocks = triton.cdiv(seqlen_q, config["BLOCK_M"])
        
        q_strides = (q_int8.stride(0), q_int8.stride(2), q_int8.stride(1), q_int8.stride(3))
        k_strides = (k_int8.stride(0), k_int8.stride(2), k_int8.stride(1), k_int8.stride(3))
        v_strides = (v_fp8.stride(0), v_fp8.stride(1), v_fp8.stride(3), v_fp8.stride(2))
        o_strides = (o.stride(0), o.stride(2), o.stride(1), o.stride(3))

        def fn():
            return _attn_fwd[grid](
                q_int8,
                k_int8,
                v_fp8,
                q_scale,
                k_scale,
                v_scale,
                o,
                softmax_lse,
                *q_strides,
                *k_strides,
                *v_strides,
                q_scale.stride(0) if q_scale is not None else 0,
                q_scale.stride(1) if q_scale is not None else 0,
                k_scale.stride(0) if k_scale is not None else 0,
                k_scale.stride(1) if k_scale is not None else 0,
                v_scale.stride(0) if v_scale is not None else 0,
                v_scale.stride(1) if v_scale is not None else 0,
                *o_strides,
                stride_lse_z if softmax_lse is not None else 0,
                stride_lse_h if softmax_lse is not None else 0,
                stride_lse_m if softmax_lse is not None else 0,
                sm_scale,
                None,
                None,
                SEQLEN_Q=seqlen_q,
                SEQLEN_K=seqlen_k,
                IS_CAUSAL=is_causal,
                NUM_Q_HEADS=num_q_heads,
                NUM_K_HEADS=num_k_heads,
                BLOCK_DMODEL=v_head_dim,
                BLOCK_DMODEL_POW2=BLOCK_DMODEL_POW2,
                RETURN_SCORES=False,
                ENABLE_DROPOUT=enable_dropout,
                VARLEN=False,
                BATCH=batch,
                NUM_XCD=get_num_xcds(),
                USE_INT64_STRIDES=True,
                MFMA_INSTR_SHAPE_M=mfma_instr_shape_m,
                MFMA_INSTR_SHAPE_N=mfma_instr_shape_n,
                MFMA_INSTR_SHAPE_K=mfma_instr_shape_k,
                SIZE_PER_THREAD_M=size_per_thread_m,
                SIZE_PER_THREAD_N=size_per_thread_n,
                SIZE_PER_THREAD_D=size_per_thread_d,
                NUM_BLOCKS=num_blocks,
                **config,
            )

        fn()
        # ms = triton.testing.do_bench(fn)
        # print(f"ms: {ms}")
        

        if return_lse:
            return o, softmax_lse
        else:
            return o

    o = o[..., :head_dim_og]

    if return_lse:
        return o, lse / 1.44269504 + lse_correction * sm_scale if smooth_k else lse / 1.44269504
    else:
        return o