try:
    import triton.experimental.gluon.language as gl
except ImportError:
    gl = None

try:
    from triton.experimental import gluon
except ImportError:
    gluon = None

# provide a mock gluon if gluon is missing during deployment
if gluon is None:
    import inspect

    class MockGluon:
        @staticmethod
        def jit(fn):
            sig = inspect.signature(fn)
            params = [
                type("Param", (), {"name": name})()
                for name in sig.parameters
            ]
            fn.params = params
            return fn
    gluon = MockGluon()

# provide a mock gl if gluon is missing during deployment
if gl is None:
    class MockConstExpr:
        def __init__(self, value):
            self.value = value

    class MockSharedMemoryDescriptor:
        def __init__(self, *args, **kwargs):
            pass

        def index(self, idx):
            return self

        def store(self, value):
            pass

        def load(self, layout=None):
            return MockTensor()

    class MockTensor:
        def __init__(self, *args, **kwargs):
            pass

        def to(self, dtype):
            return self

        @staticmethod
        def expand_dims(axis):
            return MockTensor()

    class MockSliceLayout:
        def __init__(self, *args, **kwargs):
            pass

    class MockBlockedLayout:
        def __init__(self, *args, **kwargs):
            pass

    class MockDotOperandLayout:
        def __init__(self, operand_index, parent, k_width):
            pass

    class MockAMDMFMALayout:
        def __init__(self, version, instr_shape, transposed, warps_per_cta):
            pass

    class MockSwizzledSharedLayout:
        def __init__(self, vec, per_phase, max_phase, order):
            pass

    class MockLanguage:
        constexpr = MockConstExpr
        shared_memory_descriptor = MockSharedMemoryDescriptor
        tensor = MockTensor
        SliceLayout = MockSliceLayout
        BlockedLayout = MockBlockedLayout
        DotOperandLayout = MockDotOperandLayout
        AMDMFMALayout = MockAMDMFMALayout
        SwizzledSharedLayout = MockSwizzledSharedLayout

        @staticmethod
        def cdiv(a, b):
            return (a + b - 1) // b

        @staticmethod
        def arange(start, end, layout=None):
            return MockTensor()

        @staticmethod
        def zeros(shape, dtype, layout):
            return MockTensor()

        @staticmethod
        def load(ptr, mask=None):
            return MockTensor()

        @staticmethod
        def program_id(axis):
            return 0

        @staticmethod
        def allocate_shared_memory(dtype, shape, layout):
            return MockSharedMemoryDescriptor()

    gl = MockLanguage()
