import triton
from triton import runtime

# do_bench function of triton can not control repeat times,
# so we need to implement it by ourselves.
def triton_bench(fn, warmup=25, rep=100):
    di = runtime.driver.active.get_device_interface()

    fn()
    di.synchronize()

    cache = runtime.driver.active.get_empty_cache_for_benchmark()

    # Warm-up
    for _ in range(warmup):
        fn()
    # Benchmark
    for i in range(rep):
        # we clear the L2 cache before each run
        runtime.driver.active.clear_cache(cache)
        # record time of `fn`
        fn()
    # Record clocks
    di.synchronize()