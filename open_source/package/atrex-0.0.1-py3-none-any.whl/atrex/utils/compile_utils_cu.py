import functools
import os
import shlex
import shutil
import subprocess
import sys
import sysconfig
from typing import Dict, List, Optional, Tuple, Union


SHARED_FLAG = "-shared"
LIB_EXT = ".so"
SUBPROCESS_DECODE_ARGS = ()


def executable_path(executable: str) -> str:
    """
    Return the path to the executable.

    Args:
        executable (str): The name of the executable.

    Returns:
        The path to the executable.
    """
    path = shutil.which(executable)
    if not path:
        home = _find_nvcc_home()
        if home:
            path = shutil.which(os.path.join(home, "bin", executable))
        assert (
            path is not None
        ), f"Could not find {executable} in PATH or ROCM_HOME({home})"
    return os.path.realpath(path)


def get_nvcc_version():
    try:
        nvccconfig = executable_path("nvcc")
        output = subprocess.check_output([nvccconfig, "--version"], text=True)
        return output
    except Exception:
        # raise RuntimeError("CUDA version file not found")
        return None

def _find_nvcc_home() -> Optional[str]:
    """Find the CUDA install path."""
    # Guess #1
    rocm_home = os.environ.get("CUDA_HOME") or os.environ.get("CUDAPATH")
    if rocm_home is None:
        # Guess #2
        hipcc_path = shutil.which("nvcc")
        if hipcc_path is not None:
            rocm_home = os.path.dirname(
                os.path.dirname(
                    os.path.realpath(hipcc_path)))
        else:
            # Guess #3
            fallback_path = "/usr/local/cuda"
            if os.path.exists(fallback_path):
                rocm_home = fallback_path
    if rocm_home is None:
        print(
            f"No Cuda runtime is found, using CUDA_HOME='{rocm_home}'",
            file=sys.stderr)
    return rocm_home


NVCC_VERSION = get_nvcc_version()
CUDA_HOME = _find_nvcc_home()
NVCC_HOME = os.path.join(CUDA_HOME, "nvcc") if CUDA_HOME else None
IS_HIP_EXTENSION = False


def _get_pybind11_abi_build_flags():
    # Note [Pybind11 ABI constants]
    #
    # Pybind11 before 2.4 used to build an ABI strings using the following pattern:
    # f"__pybind11_internals_v{PYBIND11_INTERNALS_VERSION}{PYBIND11_INTERNALS_KIND}{PYBIND11_BUILD_TYPE}__"
    # Since 2.4 compier type, stdlib and build abi parameters are also encoded like this:
    # f"__pybind11_internals_v{PYBIND11_INTERNALS_VERSION}{PYBIND11_INTERNALS_KIND}{PYBIND11_COMPILER_TYPE}{PYBIND11_STDLIB}{PYBIND11_BUILD_ABI}{PYBIND11_BUILD_TYPE}__"
    #
    # This was done in order to further narrow down the chances of compiler ABI incompatibility
    # that can cause a hard to debug segfaults.
    # For PyTorch extensions we want to relax those restrictions and pass compiler, stdlib and abi properties
    # captured during PyTorch native library compilation in
    # torch/csrc/Module.cpp
    import torch

    abi_cflags = []
    for pname in ["COMPILER_TYPE", "STDLIB", "BUILD_ABI"]:
        pval = getattr(torch._C, f"_PYBIND11_{pname}", None)
        if pval is not None:
            abi_cflags.append(f'-DPYBIND11_{pname}=\\"{pval}\\"')
    return abi_cflags


def _get_glibcxx_abi_build_flags():
    import torch

    glibcxx_abi_cflags = [
        "-D_GLIBCXX_USE_CXX11_ABI=" + str(int(torch._C._GLIBCXX_USE_CXX11_ABI))
    ]
    return glibcxx_abi_cflags


def is_ninja_available():
    """Return ``True`` if the `ninja <https://ninja-build.org/>`_ build system is available on the system, ``False`` otherwise."""
    try:
        subprocess.check_output("ninja --version".split())
    except Exception:
        return False
    else:
        return True


def verify_ninja_availability():
    """Raise ``RuntimeError`` if `ninja <https://ninja-build.org/>`_ build system is not available on the system, does nothing otherwise."""
    if not is_ninja_available():
        raise RuntimeError("Ninja is required to load C++ extensions")


def get_cxx_compiler():
    return os.environ.get("CXX", "c++")


def executable_path(executable: str) -> str:
    """
    Return the path to the executable.

    Args:
        executable (str): The name of the executable.

    Returns:
        The path to the executable.
    """
    path = shutil.which(executable)
    if not path:
        home = _find_nvcc_home()
        if home:
            path = shutil.which(os.path.join(home, "bin", executable))
        assert (
            path is not None
        ), f"Could not find {executable} in PATH or ROCM_HOME({home})"
    return os.path.realpath(path)


def _prepare_ldflags(
    extra_ldflags, with_cuda, verbose, is_standalone, torch_exclude, prebuild
):
    extra_ldflags.append("-mcmodel=large")
    extra_ldflags.append("-ffunction-sections")
    extra_ldflags.append("-fdata-sections ")
    extra_ldflags.append("-Wl,--gc-sections")
    extra_ldflags.append("-Wl,--cref")
    if not torch_exclude:
        import torch

        _TORCH_PATH = os.path.join(os.path.dirname(torch.__file__))
        TORCH_LIB_PATH = os.path.join(_TORCH_PATH, "lib")
        extra_ldflags.append(f"-L{TORCH_LIB_PATH}")
        if prebuild != 1:
            extra_ldflags.append("-lc10")
            if with_cuda:
                extra_ldflags.append(
                    "-lc10_hip" if IS_HIP_EXTENSION else "-lc10_cuda")
            extra_ldflags.append("-ltorch_cpu")
            if with_cuda:
                extra_ldflags.append(
                    "-ltorch_hip" if IS_HIP_EXTENSION else "-ltorch_cuda"
                )
            extra_ldflags.append("-ltorch")
            if not is_standalone:
                extra_ldflags.append("-ltorch_python")

        if is_standalone:
            extra_ldflags.append(f"-Wl,-rpath,{TORCH_LIB_PATH}")

    return extra_ldflags


def include_paths(cuda: bool = False) -> List[str]:
    """
    Get the include paths required to build a C++ or CUDA extension.

    Args:
        cuda: If `True`, includes CUDA-specific include paths.

    Returns:
        A list of include path strings.
    """
    import torch

    _TORCH_PATH = os.path.join(os.path.dirname(torch.__file__))
    lib_include = os.path.join(_TORCH_PATH, "include")
    paths = [
        lib_include,
        # Remove this once torch/torch.h is officially no longer supported for
        # C++ extensions.
        os.path.join(lib_include, "torch", "csrc", "api", "include"),
        # Some internal (old) Torch headers don't properly prefix their includes,
        # so we need to pass -Itorch/lib/include/TH as well.
        os.path.join(lib_include, "TH"),
        os.path.join(lib_include, "THC"),
    ]

    paths.append(os.path.join(lib_include, "THH"))
    paths.append(os.path.join(CUDA_HOME, "include"))
    return paths


def _write_ninja_file_to_build_library(
    path,
    name,
    sources,
    extra_cflags,
    extra_cuda_cflags,
    extra_ldflags,
    extra_include_paths,
    with_cuda,
    is_python_module,
    is_standalone,
    torch_exclude,
    prebuild=0,
) -> None:
    extra_cflags = [flag.strip() for flag in extra_cflags]
    extra_cuda_cflags = [flag.strip() for flag in extra_cuda_cflags]
    extra_ldflags = [flag.strip() for flag in extra_ldflags]
    extra_include_paths = [flag.strip() for flag in extra_include_paths]
    # include_paths() gives us the location of torch/extension.h
    system_includes = [] if torch_exclude else include_paths(with_cuda)

    # FIXME: build python module excluded with torch, use `pybind11`
    # But we can't use this now because all aiter op based on torch
    # which means pybind11 related build flags must from torch now
    common_cflags = []
    if torch_exclude and is_python_module:
        import pybind11

        extra_include_paths.append(pybind11.get_include())
        common_cflags += [f"{x}" for x in _get_pybind11_abi_build_flags()]
        common_cflags += [f"{x}" for x in _get_glibcxx_abi_build_flags()]

    # sysconfig.get_path('include') gives us the location of Python.h
    # Explicitly specify 'posix_prefix' scheme on non-Windows platforms to workaround error on some MacOS
    # installations where default `get_path` points to non-existing
    # `/Library/Python/M.m/include` folder
    if is_python_module:
        python_include_path = sysconfig.get_path(
            "include", scheme="posix_prefix")
        if python_include_path is not None:
            system_includes.append(python_include_path)

    # Turn into absolute paths so we can emit them into the ninja build
    # file wherever it is.
    user_includes = [os.path.abspath(file) for file in extra_include_paths]

    if not torch_exclude:
        if prebuild == 0:
            common_cflags.append(f"-DTORCH_EXTENSION_NAME={name}")
        else:
            common_cflags.append(f"-DTORCH_EXTENSION_NAME=aiter_")
        common_cflags.append("-DTORCH_API_INCLUDE_EXTENSION_H")
        common_cflags += [f"{x}" for x in _get_pybind11_abi_build_flags()]
        common_cflags += [f"{x}" for x in _get_glibcxx_abi_build_flags()]

    # Windows does not understand `-isystem` and quotes flags later.
    common_cflags += [f"-I{shlex.quote(include)}" for include in user_includes]
    common_cflags += [
        f"-isystem {shlex.quote(include)}" for include in system_includes]

    cflags = common_cflags + ["-Xcompiler -fPIC", "-std=c++20"] + extra_cflags

    def object_file_path(source_file: str) -> str:
        # '/path/to/file.cpp' -> 'file'
        file_name = os.path.splitext(os.path.basename(source_file))[0]
        if with_cuda:
            # Use a different object filename in case a C++ and CUDA file have
            # the same filename but different extension (.cpp vs. .cu).
            target = f"{file_name}.cuda.o"
        else:
            target = f"{file_name}.o"
        return target

    objects = [object_file_path(src) for src in sources]
    ldflags = [SHARED_FLAG] + extra_ldflags

    ext = LIB_EXT
    library_target = f"{name}{ext}"
    if prebuild == 2:
        library_target = "aiter_.so"

    cuda_flags = cflags + extra_cuda_cflags

    _write_ninja_file(
        path=path,
        cflags=cflags,
        post_cflags=None,
        cuda_cflags=cuda_flags,
        cuda_post_cflags=None,
        cuda_dlink_post_cflags=None,
        sources=sources,
        objects=objects,
        ldflags=ldflags,
        library_target=library_target,
        with_cuda=with_cuda,
        prebuild=prebuild,
    )


def _maybe_write(filename, new_content):
    r"""
    Equivalent to writing the content into the file but will not touch the file
    if it already had the right content (to avoid triggering recompile).
    """
    if os.path.exists(filename):
        with open(filename) as f:
            content = f.read()

        if content == new_content:
            # The file already contains the right thing!
            return

    with open(filename, "w") as source_file:
        source_file.write(new_content)


def _write_ninja_file(
    path,
    cflags,
    post_cflags,
    cuda_cflags,
    cuda_post_cflags,
    cuda_dlink_post_cflags,
    sources,
    objects,
    ldflags,
    library_target,
    with_cuda,
    prebuild=0,
) -> None:
    r"""Write a ninja file that does the desired compiling and linking.

    `path`: Where to write this file
    `cflags`: list of flags to pass to $cxx. Can be None.
    `post_cflags`: list of flags to append to the $cxx invocation. Can be None.
    `cuda_cflags`: list of flags to pass to $nvcc. Can be None.
    `cuda_postflags`: list of flags to append to the $nvcc invocation. Can be None.
    `sources`: list of paths to source files
    `objects`: list of desired paths to objects, one per source.
    `ldflags`: list of flags to pass to linker. Can be None.
    `library_target`: Name of the output library. Can be None; in that case,
                      we do no linking.
    `with_cuda`: If we should be compiling with CUDA.
    """

    def sanitize_flags(flags):
        if flags is None:
            return []
        else:
            return [flag.strip() for flag in flags]

    cflags = sanitize_flags(cflags)
    post_cflags = sanitize_flags(post_cflags)
    cuda_cflags = sanitize_flags(cuda_cflags)
    cuda_post_cflags = sanitize_flags(cuda_post_cflags)
    cuda_dlink_post_cflags = sanitize_flags(cuda_dlink_post_cflags)
    ldflags = sanitize_flags(ldflags)

    # Sanity checks...
    assert len(sources) == len(objects)
    assert len(sources) > 0

    compiler = get_cxx_compiler()

    # Version 1.3 is required for the `deps` directive.
    config = ["ninja_required_version = 1.3"]
    config.append(f"cxx = {compiler}")
    if with_cuda or cuda_dlink_post_cflags:
        nvcc = os.path.join(CUDA_HOME, "bin", "nvcc")
        config.append(f"nvcc = {nvcc}")

    flags = [f'cflags = {" ".join(cflags)}']
    flags.append(f'post_cflags = {" ".join(post_cflags)}')
    if with_cuda:
        flags.append(f'cuda_cflags = {" ".join(cuda_cflags)}')
        flags.append(f'cuda_post_cflags = {" ".join(cuda_post_cflags)}')
    flags.append(
        f'cuda_dlink_post_cflags = {" ".join(cuda_dlink_post_cflags)}')

    # Turn into absolute paths so we can emit them into the ninja build
    # file wherever it is.
    sources = [os.path.abspath(file) for file in sources]

    # See https://ninja-build.org/build.ninja.html for reference.
    compile_rule = ["rule compile"]
    compile_rule.append(
        "  command = $cxx -MMD -MF $out.d $cflags -c $in -o $out $post_cflags"
    )
    compile_rule.append("  depfile = $out.d")
    compile_rule.append("  deps = gcc")

    if with_cuda:
        cuda_compile_rule = ["rule cuda_compile"]
        nvcc_gendeps = ""
        cuda_compile_rule.append(
            f"  command = $nvcc {nvcc_gendeps} $cuda_cflags -c $in -o $out $cuda_post_cflags"
        )

    # Emit one build rule per source to enable incremental build.
    build = []
    for source_file, object_file in zip(sources, objects):
        rule = "cuda_compile" if with_cuda else "compile"

        source_file = source_file.replace(" ", "$ ")
        object_file = object_file.replace(" ", "$ ")
        build.append(f"build {object_file}: {rule} {source_file}")

    flags.append(f'ldflags = {" ".join(ldflags)}')
    if cuda_dlink_post_cflags:
        devlink_out = os.path.join(os.path.dirname(objects[0]), "dlink.o")
        devlink_rule = ["rule cuda_devlink"]
        devlink_rule.append(
            "  command = $nvcc $in -o $out $cuda_dlink_post_cflags")
        devlink = [f'build {devlink_out}: cuda_devlink {" ".join(objects)}']
        objects += [devlink_out]
    else:
        devlink_rule, devlink = [], []

    if library_target is not None:
        link_rule = ["rule link"]

        link_rule.append(
            "  command = $cxx @$out.rsp $ldflags -o $out\n  rspfile = $out.rsp\n  rspfile_content = $in"
        )

        link = [f'build {library_target}: link {" ".join(objects)}']

        default = [f"default {library_target}"]
    else:
        link_rule, link, default = [], [], []

    # 'Blocks' should be separated by newlines, for visual benefit.
    blocks = [config, flags, compile_rule]
    if with_cuda:
        blocks.append(cuda_compile_rule)  # type: ignore[possibly-undefined]
    blocks += [devlink_rule, link_rule, build, devlink, link, default]
    content = "\n\n".join("\n".join(b) for b in blocks)
    # Ninja requires a new lines at the end of the .ninja file
    content += "\n"
    _maybe_write(path, content)


def _get_num_workers(verbose: bool) -> Optional[int]:
    max_jobs = os.environ.get("MAX_JOBS")
    if max_jobs is not None and max_jobs.isdigit():
        if int(max_jobs) > int(max(1, os.cpu_count() * 0.8)):
            max_jobs = int(max(1, os.cpu_count() * 0.8))
        if verbose:
            print(
                f"Using envvar MAX_JOBS ({max_jobs}) as the number of workers...",
                file=sys.stderr,
            )
    else:
        max_jobs = int(max(1, os.cpu_count() * 0.8))
        print(
            f"Using 0.8*cpu_cnt MAX_JOBS ({max_jobs}) as the number of workers...",
            file=sys.stderr,
        )
    prebuild_thread_num = os.environ.get("PREBUILD_THREAD_NUM")
    if prebuild_thread_num is not None:
        max_jobs = int(max_jobs) / int(prebuild_thread_num)
    return int(max_jobs)


def _run_ninja_build(
        build_directory: str,
        verbose: bool,
        error_prefix: str) -> None:
    command = ["ninja", "-v"]
    num_workers = _get_num_workers(verbose)
    if num_workers is not None:
        command.extend(["-j", str(num_workers)])
    env = os.environ.copy()

    try:
        sys.stdout.flush()
        sys.stderr.flush()
        # Warning: don't pass stdout=None to subprocess.run to get output.
        # subprocess.run assumes that sys.__stdout__ has not been modified and
        # attempts to write to it by default.  However, when we call _run_ninja_build
        # from ahead-of-time cpp extensions, the following happens:
        # 1) If the stdout encoding is not utf-8, setuptools detachs __stdout__.
        #    https://github.com/pypa/setuptools/blob/7e97def47723303fafabe48b22168bbc11bb4821/setuptools/dist.py#L1110
        #    (it probably shouldn't do this)
        # 2) subprocess.run (on POSIX, with no stdout override) relies on
        #    __stdout__ not being detached:
        #    https://github.com/python/cpython/blob/c352e6c7446c894b13643f538db312092b351789/Lib/subprocess.py#L1214
        # To work around this, we pass in the fileno directly and hope that
        # it is valid.
        stdout_fileno = 1
        subprocess.run(
            command,
            stdout=stdout_fileno if verbose else subprocess.PIPE,
            stderr=subprocess.STDOUT,
            cwd=build_directory,
            check=True,
            env=env,
        )
    except subprocess.CalledProcessError as e:
        # Python 2 and 3 compatible way of getting the error object.
        _, error, _ = sys.exc_info()
        # error.output contains the stdout and stderr of the build attempt.
        message = error_prefix
        # `error` is a CalledProcessError (which has an `output`) attribute, but
        # mypy thinks it's Optional[BaseException] and doesn't narrow
        if hasattr(
                error,
                "output") and error.output:  # type: ignore[union-attr]
            # type: ignore[union-attr]
            message += f": {error.output.decode(*SUBPROCESS_DECODE_ARGS)}"
        raise RuntimeError(message) from e


def _write_ninja_file_and_build_library(
    name,
    sources: List[str],
    extra_cflags,
    extra_cuda_cflags,
    extra_ldflags,
    extra_include_paths,
    build_directory: str,
    verbose: bool,
    with_cuda: Optional[bool],
    is_python_module: bool,
    is_standalone: bool = False,
    torch_exclude: bool = False,
    prebuild: int = 0,
) -> None:
    verify_ninja_availability()

    compiler = get_cxx_compiler()

    extra_ldflags = _prepare_ldflags(
        extra_ldflags or [],
        with_cuda,
        verbose,
        is_standalone,
        torch_exclude,
        prebuild)
    build_file_path = os.path.join(build_directory, "build.ninja")
    if verbose:
        print(
            f"Emitting ninja build file {build_file_path}...",
            file=sys.stderr)
    # NOTE: Emitting a new ninja build file does not cause re-compilation if
    # the sources did not change, so it's ok to re-emit (and it's fast).
    _write_ninja_file_to_build_library(
        path=build_file_path,
        name=name,
        sources=sorted(set(sources)),
        extra_cflags=extra_cflags or [],
        extra_cuda_cflags=extra_cuda_cflags or [],
        extra_ldflags=extra_ldflags or [],
        extra_include_paths=extra_include_paths or [],
        with_cuda=with_cuda,
        is_python_module=is_python_module,
        is_standalone=is_standalone,
        torch_exclude=torch_exclude,
        prebuild=prebuild,
    )

    if verbose:
        print(f"Building extension module {name}...", file=sys.stderr)
    _run_ninja_build(
        build_directory,
        verbose,
        error_prefix=f"Error building extension '{name}'")


def _import_module_from_library(
        module_name,
        path,
        is_python_module,
        torch_exclude):
    filepath = os.path.join(path, f"{module_name}{LIB_EXT}")
    if is_python_module:
        return None
        # https://stackoverflow.com/questions/67631/how-to-import-a-module-given-the-full-path
        spec = importlib.util.spec_from_file_location(module_name, filepath)
        assert spec is not None
        module = importlib.util.module_from_spec(spec)
        assert isinstance(spec.loader, importlib.abc.Loader)
        spec.loader.exec_module(module)
        return module
    else:
        if not torch_exclude:
            import torch

            torch.ops.load_library(filepath)


def jit_compile_cu(
    name,
    sources,
    extra_cflags,
    extra_cuda_cflags,
    extra_ldflags,
    extra_include_paths,
    build_directory: str,
    verbose: bool,
    with_cuda: Optional[bool],
    is_python_module,
    is_standalone,
    keep_intermediates=True,
    torch_exclude=False,
    hipify=True,
    prebuild=0,
) -> None:
    torch_path = os.path.join("")
    if not torch_exclude:
        import torch

        _TORCH_PATH = os.path.join(os.path.dirname(torch.__file__))
        torch_path = os.path.join(_TORCH_PATH, "*")

    _write_ninja_file_and_build_library(
        name=name,
        sources=sources,
        extra_cflags=extra_cflags or [],
        extra_cuda_cflags=extra_cuda_cflags or [],
        extra_ldflags=extra_ldflags or [],
        extra_include_paths=extra_include_paths or [],
        build_directory=build_directory,
        verbose=verbose,
        with_cuda=with_cuda,
        is_python_module=is_python_module,
        is_standalone=is_standalone,
        torch_exclude=torch_exclude,
        prebuild=prebuild,
    )

    if verbose:
        print(f"Loading extension module {name}...", file=sys.stderr)

    return _import_module_from_library(
        name, build_directory, is_python_module, torch_exclude
    )
