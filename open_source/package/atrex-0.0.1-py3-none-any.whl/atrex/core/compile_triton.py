import binascii
import functools
import json
import os
from collections import namedtuple, defaultdict
from itertools import product
from pathlib import Path
from typing import Callable

import triton
from triton.runtime.driver import driver
from triton.backends.compiler import GPUTarget

from atrex.utils.compile_utils_triton import build_dir as triton_build_dir
from atrex.utils.compile_utils_triton import find_file, compile_module_from_src, make_launcher, ty_to_cpp, include_dirs, HIPUtils, OpDumper


def is_constant(s):
    try:
        eval(s)
    except BaseException:
        return False
    return True


def constexpr(s):
    try:
        ret = int(s)
        return ret
    except ValueError:
        pass
    try:
        ret = float(s)
        return ret
    except ValueError:
        pass
    return None


def is_divisible_by_16(num):
    return num % 16 == 0


def expand_signature(signature_str):
    elements = []
    name_exts = []
    current_pos = 0

    while current_pos < len(signature_str):
        while current_pos < len(signature_str) and signature_str[current_pos] in [' ', ',']:
            current_pos += 1

        if current_pos >= len(signature_str):
            break

        if signature_str[current_pos] == '[':
            end_pos = signature_str.index(']', current_pos)
            if end_pos == -1:
                raise ValueError(f"Invalid signature string: missing ']' after position {current_pos}")
            list_str = signature_str[current_pos + 1:end_pos]
            list_elements = [item.strip() for item in list_str.split(',')]
            elements.append(list_elements)
            name_exts.append(list_elements)
            current_pos = end_pos + 1
        else:
            end_pos = current_pos
            while end_pos < len(signature_str) and signature_str[end_pos] not in [',', '[']:
                end_pos += 1
            element = signature_str[current_pos:end_pos].strip()
            if element:
                elements.append([element])
            current_pos = end_pos

    all_combinations = list(product(*elements))
    all_name_exts = list(product(*name_exts))
    result_sig = []
    result_ext = []
    for combo in all_combinations:
        result_sig.append(', '.join(combo))
    for combo in all_name_exts:
        result_ext.append('_'.join(combo))
    return result_sig, result_ext


def get_directory():
    if os.getenv("TRITON_PREBUILD"):
        current_dir = os.getenv("TRITON_PREBUILD") + "/../../python/atrex/core/"
        build_dir = os.getenv("TRITON_PREBUILD")
    else:
        current_dir = os.path.dirname(os.path.abspath(__file__))
        build_dir = triton_build_dir
    os.makedirs(build_dir, exist_ok=True)
    return current_dir, build_dir


def prepare_compile_metadata(current_dir, module_name, original_func):
    with open(current_dir + "/optCompilerConfig.json", "r") as file:
        data = json.load(file)
        if isinstance(data, dict):
            compile_args = data.get(module_name)
        else:
            raise TypeError(
                "please use dict_format to write 'optCompilerConfig.json'! ")
    assert compile_args['target'] == 'gfx942', "target other than AMD not supported!"
    arg_names = [p.name for p in original_func.params]
    need_aot = compile_args["need_aot"]
    sig_str_list, name_ext_list = expand_signature(compile_args["signature"])
    compile_metadatas = []
    for sig_str, name_ext in zip(sig_str_list, name_ext_list):
        sigs = [item.strip() for item in sig_str.split(",")]
        hints = {(i, ): constexpr(s.split(":")[1]) for i, s in enumerate(sigs) if ":" in s}
        hints = {k: v for k, v in hints.items() if v is not None}
        assert len(sigs) == len(arg_names), "length of signature not equal to len of function args!"
        constants = {arg_names[i]: constexpr(s) for i, s in enumerate(sigs)}
        constants = {k: v for k, v in constants.items() if v is not None}
        signature = {}
        constexprs = {}
        attrs = defaultdict(list)
        # compiler hints
        for idx, (name, value) in enumerate(zip(arg_names, sigs)):
            if is_constant(value):
                signature[name] = "constexpr"
                constexprs[(idx,)] = eval(value)
                if is_divisible_by_16(eval(value)):
                    attrs[(idx,)].append(["tt.divisibility", 16])
            elif value.endswith(":16"):
                signature[name] = value[:-3]
                attrs[(idx,)].append(["tt.divisibility", 16])
            elif value.endswith(":16S"):
                signature[name] = value[:-4]
                attrs[(idx,)].append(["tt.divisibility", 16])
                attrs[(idx,)].append(["tt.pointer_range", 32])
            else:
                signature[name] = value
        compile_metadata = {"signature": signature, "constexprs": constexprs, "constants": constants, "attrs": attrs, "compile_args": compile_args,
                            "hints": hints, "need_aot": need_aot, "arg_names": arg_names, "name_ext": name_ext}
        CompileMetadata = namedtuple('CompileMetadata', sorted(list(compile_metadata.keys())))
        compile_metadata = CompileMetadata(**compile_metadata)
        compile_metadatas.append(compile_metadata)
    return compile_metadatas


def canonicalize_metadata(metadata):
    target = metadata['target']
    metadata['target'] = GPUTarget(target['backend'], target['arch'], target['warp_size'])
    KernelMetadata = namedtuple('KernelMetadata', sorted(list(metadata.keys())))
    metadata = KernelMetadata(**metadata)
    return metadata


def load_kernel(kernel_path):
    file = Path(kernel_path)
    kernel = file.read_bytes()
    return kernel


__kernel_cache = {}


class CompiledKernel:
    def __init__(self, kernel, metadata, signature):
        driver_utils = HIPUtils()
        self.device = driver.active.get_current_device()
        self.stream = driver.active.get_current_stream(self.device)
        _, self.function, _, _, _ = driver_utils.load_binary(metadata.name, kernel, metadata.shared, self.device)
        self.launch_cooperative_grid = metadata.launch_cooperative_grid
        self.packed_metadata = (
            metadata.num_warps,
            metadata.num_ctas,
            metadata.shared,
            metadata.cluster_dims[0],
            metadata.cluster_dims[1],
            metadata.cluster_dims[2],
        )
        src = make_launcher(signature, metadata.warp_size)
        self.launcher = compile_module_from_src(src=src, kernel_name=metadata.name, module_name="__triton_launcher", include_dirs=include_dirs)

    def __getitem__(self, grid):
        if callable(grid):
            raise TypeError("callable grid not supported!")

        def runner(*args, **kwargs):
            gridX = grid[0]
            gridY = grid[1] if len(grid) > 1 else 1
            gridZ = grid[2] if len(grid) > 2 else 1
            args += tuple(kwargs.values())
            self.launcher.launch(self.launch_cooperative_grid, gridX, gridY, gridZ, self.stream, self.function, None, self.packed_metadata, None, None, None, *args)
        return runner


def triton_kernel():
    """
    atrex's triton jit function that bypass triton's original jit
    and cache machanism, and support triton aot to avoid version
    comflict issue.
    """

    def decorator(func: Callable) -> Callable:
        # Save the original function
        original_func = func

        @functools.wraps(func)
        def wrapper(*args, **kwargs):
            return original_func(*args, **kwargs)

        if not os.getenv("TRITON_AOT"):
            return original_func
        module_name = func.__name__
        if module_name in __kernel_cache:
            return __kernel_cache[module_name]
        current_dir, build_dir = get_directory()
        op_dir = f"{build_dir}/{func.__name__}"
        os.makedirs(op_dir, exist_ok=True)
        os.environ["TRITON_HOME"] = op_dir
        is_hip = triton.runtime.driver.active.get_current_target().backend == "hip"
        # retrieve compiled kernel for execution
        json_path = find_file(op_dir, f"{module_name}.json")
        bin_path = find_file(op_dir, f"{module_name}.hsaco") if is_hip else find_file(op_dir, f"{module_name}.ptx")
        if bin_path and json_path:
            with open(json_path, "r") as file:
                metadata = json.load(file)
            compile_metadata = prepare_compile_metadata(current_dir, module_name, original_func)
            if len(compile_metadata) > 1:
                print("Warning: the behaviour of launching kernel with more than one signature is not defined.")
            compile_metadata = compile_metadata[0]
            metadata = canonicalize_metadata(metadata)
            kernel = load_kernel(bin_path)
            compiled_kernel = CompiledKernel(kernel, metadata, compile_metadata.signature)
            __kernel_cache[module_name] = compiled_kernel
            return compiled_kernel
        # AOT, after the compilation, original func is a JITFunction object.
        # 1. retrieve signature for kernel compilation
        compile_metadatas = prepare_compile_metadata(current_dir, module_name, original_func)
        if not compile_metadatas[0].need_aot:
            return original_func
        target = GPUTarget("hip", 'gfx942', 64)
        backend = triton.compiler.make_backend(target)
        options = {"num_warps": compile_metadatas[0].compile_args["num_warps"], "num_stages": compile_metadatas[0].compile_args["num_stages"]}
        options = backend.parse_options(options)
        from triton.experimental.gluon._runtime import GluonASTSource
        source_cls = GluonASTSource if original_func.is_gluon() else triton.compiler.ASTSource
        op_dir = f"{build_dir}/{func.__name__}"
        out_cpp = Path(f"{op_dir}/{func.__name__}.cpp")
        out_h = Path(f"{op_dir}/{func.__name__}.h")
        op_dumper = OpDumper(out_cpp, out_h)
        for compile_metadata in compile_metadatas:
            src = source_cls(fn=original_func, signature=compile_metadata.signature, constexprs=compile_metadata.constexprs, attrs=compile_metadata.attrs)
            # 2. compile kernel
            ccinfo = triton.compile(src=src, target=target, options=options.__dict__)
            json_path = find_file(op_dir, f"{module_name}.json")
            bin_path = find_file(op_dir, f"{module_name}.hsaco") if is_hip else find_file(op_dir, f"{module_name}.ptx")
            with open(json_path, "r") as file:
                metadata = json.load(file)
            target = GPUTarget(metadata['target']['backend'], metadata['target']['arch'], metadata['target']['warp_size'])
            metadata['target'] = target
            KernelMetadata = namedtuple('KernelMetadata', sorted(list(metadata.keys())))
            metadata = KernelMetadata(**metadata)
            file = Path(bin_path)
            kernel = file.read_bytes()
            # 2.5 (optional: generate the c wrapper)
            if compile_metadata.compile_args["need_c_wrapper"]:
                arg_names = []
                arg_types = []
                arg_names_not_1 = []
                arg_types_not_1 = []
                for i, arg_name in enumerate(compile_metadata.arg_names):
                    if arg_name not in compile_metadata.constants:
                        arg_names.append(arg_name)
                        arg_types.append(compile_metadata.signature[arg_name])
                        arg_names_not_1.append(arg_name)
                        arg_types_not_1.append(compile_metadata.signature[arg_name])
                    elif compile_metadata.hints.get((i, ), None) == 1:
                        arg_names.append(arg_name)
                        arg_types.append("i32")

                # dump C stub code
                func_name = module_name + compile_metadata.name_ext
                asm = ccinfo.asm[backend.binary_ext]  # store binary data once

                hex_ = str(binascii.hexlify(asm))[2:-1]

                doc_string = [f"{k}={v}" for k, v in compile_metadata.constants.items()]
                num_warps = compile_metadata.compile_args["num_warps"]
                num_stages = compile_metadata.compile_args["num_stages"]
                doc_string += [f"num_warps={num_warps}", f"num_stages={num_stages}"]
                const_sig = 'x'.join([str(v) for v in compile_metadata.constants.values()])
                meta_sig = f"warps{num_warps}xstages{num_stages}"
                params = {
                    "kernel_name": func_name,
                    "triton_kernel_name": module_name,
                    "bin_size": len(asm),
                    "bin_data": ", ".join([f"0x{x}{y}" for x, y in zip(hex_[::2], hex_[1::2])]),
                    "signature": ", ".join([f"{ty_to_cpp(ty)} {name}" for name, ty in zip(arg_names_not_1, arg_types_not_1)]),
                    "full_signature": ", ".join([f"{ty_to_cpp(ty)} {name}" for name, ty in zip(arg_names, arg_types)]),
                    "arg_pointers": ", ".join([f"&{arg}" for arg in arg_names_not_1] + ["&global_scratch"] + ["&profile_scratch"]),
                    "num_args": len(arg_names_not_1) + 2,  # +2 for global and profile scratch
                    "kernel_docstring": doc_string,
                    "shared": ccinfo.metadata.shared,
                    "num_warps": num_warps,
                    "algo_info": "_".join([const_sig, meta_sig]),
                    "_placeholder": "",
                }
                op_dumper.push_to_params_list(params)
        op_dumper.dump()
        # 3. return pybind function
        if len(compile_metadatas) > 1:
            print("Warning: the behaviour of launching kernel with more than one signature is not defined.")
        compiled_kernel = CompiledKernel(kernel, metadata, compile_metadatas[0].signature)
        __kernel_cache[module_name] = compiled_kernel
        return compiled_kernel

    return decorator
