import importlib
import os
import json
import re
import traceback
import sys
from functools import wraps, lru_cache, reduce
import inspect
import torch
from torch.profiler import profile, ProfilerActivity
import shutil
import pandas as pd
import operator
import logging
import multiprocessing as mp

from atrex.utils.compile_utils import check_and_set_ninja_worker, get_src_files, AUTOTUNE_KERNEL_TYPE
from atrex.utils.compile_utils_cu import jit_compile_cu
from atrex.utils.logging_utils import setup_logging

current_dir = os.path.dirname(os.path.abspath(__file__))
src_dir = os.path.abspath(f"{current_dir}/../src")
build_dir = os.path.abspath(f"{current_dir}/../build")
config_dir = os.path.abspath(f"{current_dir}/../configs")

cutlass_dir = f"{build_dir}/cutlass"
cutlass_thirdparty_dir = f"{current_dir}/../third_party/cutlass"

os.makedirs(build_dir, exist_ok=True)
os.makedirs(config_dir, exist_ok=True)
os.makedirs(cutlass_dir, exist_ok=True)

@lru_cache(maxsize=1024)
def get_module(module_name):
    spec = importlib.util.spec_from_file_location(
        module_name, f"{build_dir}/{module_name}/build/{module_name}.so")
    module = importlib.util.module_from_spec(spec)
    sys.modules[module_name] = module
    spec.loader.exec_module(module)
    return module


def get_args_of_build(ops_name: str, exclude=[]):
    d_opt_build_args = {
        "srcs": [],
        "md_name": "",
        "flags_extra_cc": [],
        "flags_extra_hip": [],
        "extra_ldflags": None,
        "extra_include": [],
        "verbose": False,
        "is_python_module": True,
        "is_standalone": False,
        "torch_exclude": False,
        "hip_clang_path": None,
        "blob_gen_cmd": "",
    }

    def convert(d_ops: dict):
        for k, val in d_ops.items():
            if isinstance(val, list):
                for idx, el in enumerate(val):
                    if isinstance(el, str):
                        if "torch" in el:
                            import torch as torch
                        val[idx] = eval(el)
                d_ops[k] = val
            elif isinstance(val, str):
                d_ops[k] = eval(val)
            else:
                pass

        # undefined compile features will be replaced with default value
        d_opt_build_args.update(d_ops)
        return d_opt_build_args

    with open(current_dir + "/optCompilerConfig.json", "r") as file:
        data = json.load(file)
        if isinstance(data, dict):
            compile_ops_ = data.get(ops_name)
            return convert(compile_ops_)
        else:
            raise TypeError(
                "please use dict_format to write 'optCompilerConfig.json'! ")

@lru_cache()
def recopy_cutlass():
    if os.path.exists(cutlass_dir):
        os.system(f"rm -rf {cutlass_dir}")
    shutil.copytree(cutlass_thirdparty_dir, cutlass_dir, dirs_exist_ok=True)

###### NVIDIA GPU compile #########
def build_nv_module(
    md_name,
    srcs,
    flags_extra_cc,
    flags_extra_hip,
    blob_gen_cmd,
    extra_include,
    extra_ldflags,
    verbose,
    is_python_module,
    is_standalone,
    torch_exclude,
    hipify=False,
    prebuild=0,
):
    target_name = f"{md_name}.so"
    op_dir = f"{build_dir}/{md_name}"
    logging.info(f"start build [{md_name}] under {op_dir}")

    OP_build_dir = f"{op_dir}/build"
    op_src_dir = f"{op_dir}/build/srcs"
    os.makedirs(op_src_dir, exist_ok=True)
    flags_cc = ["-O3", "-std=c++20"]

    code_cc = torch.cuda.get_device_capability()
    flags_hip = [
        f"-gencode=arch=compute_{code_cc[0]}{code_cc[1]},code=sm_{code_cc[0]}{code_cc[1]}"
    ]

    flags_cc += flags_extra_cc
    flags_hip += flags_extra_hip

    flags_hip = sorted(set(flags_hip))  # remove same flags
    check_and_set_ninja_worker()

    # autogen ck headers
    BLOB_DIR = f"{op_dir}/blob"
    os.makedirs(BLOB_DIR, exist_ok=True)
    has_python = shutil.which("python") is not None
    has_python3 = shutil.which("python3") is not None
    assert has_python or has_python3, "please install python or python3 !!!"
    cmd_python = "python" if has_python else "python3"
    for sub_blob_gen_cmd in blob_gen_cmd:
        logging.debug(f"autogen start: {cmd_python} {sub_blob_gen_cmd.format(BLOB_DIR)}")
        os.system(f"{cmd_python} {sub_blob_gen_cmd.format(BLOB_DIR)}")

    srcs += get_src_files(BLOB_DIR, ".cu")
    extra_include_paths = [
        f"{op_dir}/blob",
    ] + extra_include

    try:
        jit_compile_cu(
            md_name,
            sorted(set(srcs)),
            extra_cflags=flags_cc,
            extra_cuda_cflags=flags_hip,
            extra_ldflags=extra_ldflags,
            extra_include_paths=extra_include_paths,
            build_directory=OP_build_dir,
            verbose=verbose,
            with_cuda=True,
            is_python_module=is_python_module,
            is_standalone=is_standalone,
            torch_exclude=torch_exclude,
            hipify=hipify,
            prebuild=prebuild,
        )
    except Exception as e:
        tag = f"\033[31mfailed jit build [{md_name}]\033[0m"
        raise TypeError(
            f"{tag}\u2193\u2193\u2193\u2193\u2193\u2193\u2193\u2193\u2193\u2193\n-->[History]: {{}}{tag}\u2191\u2191\u2191\u2191\u2191\u2191\u2191\u2191\u2191\u2191".format(
                re.sub(
                    "error:",
                    "\033[31merror:\033[0m",
                    "-->".join(traceback.format_exception(*sys.exc_info())),
                    flags=re.I,
                ),
            )
        )
        raise SystemExit(
            f"build [{md_name}] under {opbd_dir} failed !!!!!!"
        ) from e

    logging.info(f"build finished for {md_name}")

def get_valid_config(pd_usptd, config, module_name):
    pd_usptd = pd_usptd[(pd_usptd['platform'] == torch.cuda.get_device_name(0)) & (pd_usptd['kernel_name'] == module_name)]
    csv_explore_keys = [k for k in pd_usptd.keys() if k not in ['platform', 'kernel_name']]
    config_tuple = config[csv_explore_keys].apply(tuple, axis=1)
    df_tuple = pd_usptd[csv_explore_keys].apply(tuple, axis=1)
    mask = config_tuple.isin(df_tuple)
    config = config[~mask]
    return config

def compile_worker(module_name, config_v, explore_keys, result_queue):
    d_args = get_args_of_build(module_name)
    srcs = d_args["srcs"]
    flags_extra_cc = d_args["flags_extra_cc"]
    flags_extra_hip = d_args["flags_extra_hip"]
    blob_gen_cmd = d_args["blob_gen_cmd"]
    extra_include = d_args["extra_include"] + \
                    [cutlass_dir+"/include", cutlass_dir+"/tools/util/include"]
    extra_ldflags = d_args["extra_ldflags"]
    verbose = d_args["verbose"]
    is_python_module = d_args["is_python_module"]
    is_standalone = d_args["is_standalone"]
    torch_exclude = d_args["torch_exclude"]
    hipify = d_args.get("hipify", False)
    prebuild = d_args.get("prebuild", 0)

    pack_name = module_name
    pd_dict = {'platform': [torch.cuda.get_device_name(0)], 'kernel_name': [module_name]}
    for j,k in enumerate(explore_keys):
        blob_gen_cmd[0] += " --{} {} ".format(k, config_v[j])
        pack_name += "_{}".format(config_v[j])
        pd_dict[k] = [config_v[j]]

    try:
        build_nv_module(
            pack_name,
            srcs,
            flags_extra_cc,
            flags_extra_hip,
            blob_gen_cmd,
            extra_include,
            extra_ldflags,
            verbose,
            is_python_module,
            is_standalone,
            torch_exclude,
            hipify,
            prebuild,
        )

        result_queue.put(('success', pd_dict))
    except Exception as e:
        result_queue.put(('error', pd_dict))
    
    if os.path.isdir(f"{build_dir}/{pack_name}"):
        shutil.rmtree(f"{build_dir}/{pack_name}", ignore_errors=True)

explore_supported_cache = []
def compile_explore(explore_keys, config, module_name):
    if explore_keys:
        assert type(config) is pd.core.frame.DataFrame, "type of config in compile_explore only support pd.core.frame.DataFrame!"
        d_args = get_args_of_build(module_name)
        blob_gen_cmd = d_args["blob_gen_cmd"]
        # config_pd = config.copy()
        if len(blob_gen_cmd) > 0:
            assert len(blob_gen_cmd) == 1, "only support one blob gen cmd!"
            pd_dict = {'platform': [torch.cuda.get_device_name(0)], 'kernel_name': [module_name]}
            logging.info("start compile exploration.")
            
            # use cache to jump compile
            explore_cache = []
            config_unique_set = ()
            for i in config.index:
                unique_cache = tuple(config[k][i] for k in explore_keys)
                
                if unique_cache in config_unique_set or unique_cache in explore_supported_cache:
                    continue
                config_unique_set += (unique_cache,)

            mp.set_start_method('spawn', force=True)
            
            max_workers = int(os.getenv("EXPLORE_MAX_WORKERS", 12))
            if not os.getenv("MAX_JOBS"):
                os.environ["MAX_JOBS"] = '4'
            for i in range(0, len(config_unique_set), max_workers):
                logging.info(f"start explore tasks batch {i}, batch_size = {max_workers}")
                processes = []
                config_unique_set_ = config_unique_set[i:i+max_workers]
                for j, config_v in enumerate(config_unique_set_):
                    q = mp.Queue()
                    p = mp.Process(target=compile_worker, args=(module_name, config_v, explore_keys, q))
                    p.start()
                    processes.append([p, q])

                for j, [p, q] in enumerate(processes):
                    status, info = q.get()
                    p.join()
                    
                    if status == 'success':
                        logging.info(f"supported: {info}")
                        explore_supported_cache.append(config_unique_set[i+j])
                    else:
                        logging.info(f"unsupported: {info}")
                        explore_cache.append(i+j)

            pd_usptd = pd.DataFrame(columns=pd_dict.keys())
            for i in explore_cache:
                for j,k in enumerate(explore_keys):
                    pd_dict[k] = [config_unique_set[i][j]]
                pd_usptd = pd.concat([pd_usptd, pd.DataFrame(pd_dict)])
            
            if len(explore_cache) > 0:
                config = get_valid_config(pd_usptd, config, module_name)

            if os.path.exists(
                f"{config_dir}/{module_name}_unsupported.csv"):
                df = pd.read_csv(f"{config_dir}/{module_name}_unsupported.csv", encoding='utf-8')
                df = pd.concat([df, pd_usptd]).drop_duplicates()
                df.to_csv(f"{config_dir}/{module_name}_unsupported.csv", index=False)
            else:
                pd_usptd.to_csv(f"{config_dir}/{module_name}_unsupported.csv", index=False)
        
        return config
    else:
        logging.info("No explore config, skip compile explore.")
        return config

def bench_worker(gpu_id, module_name, func_name, kwargs, result_queue, key_name=None):
    setup_logging()
    torch.cuda.set_device(gpu_id)
    for k,v in kwargs.items():
        kwargs[k] = v.to(f'cuda:{gpu_id}') if isinstance(v, torch.Tensor) else v
    try:
        module = get_module(module_name)
        op = getattr(module, func_name)
        if os.getenv("AUTOTUNE_TORCH_PROFILER") == "1":
            with profile(activities=[ProfilerActivity.CPU, ProfilerActivity.CUDA],
                         record_shapes=True) as prof:
                if os.getenv("AUTOTUNE_CPPEVENT") == "1":
                    result = op(**kwargs)
                else:
                    from ..utils.autotune_utils import triton_bench
                    triton_bench(
                        lambda: op(**kwargs),
                        warmup=5,
                        rep=20
                    )
            
            assert key_name is not None, "Please set key_name if use AUTOTUNE_TORCH_PROFILER."
            event_time = []
            for evt in prof.events():
                if key_name in evt.name:
                    event_time.append(evt.device_time)
            
            result = sum(event_time[-20:]) / 20 / 1000 # repeat > 20 times
            result_queue.put(('success', result))
        elif os.getenv("AUTOTUNE_CPPEVENT") == "1":
            result = op(**kwargs)
            result_queue.put(('success', result))
        else:
            import triton
            quantiles = [0.5, 0.2, 0.8]
            result, _, _ = triton.testing.do_bench(
                lambda: op(**kwargs),
                quantiles=quantiles
            )
            result_queue.put(('success', result))
    # throw other exception 
    except RuntimeError as re:
        result_queue.put(('error', -2.0))
        debug_kwargs = {k:v for k,v in kwargs.items() if not isinstance(v, torch.Tensor)}
        logging.warning(f"bench config {debug_kwargs} failed: {re} ")
    except ValueError as ve:
        result_queue.put(('error', -3.0))
        debug_kwargs = {k:v for k,v in kwargs.items() if not isinstance(v, torch.Tensor)}
        logging.warning(f"bench config {debug_kwargs} failed: {ve} ")
    except Exception as e:
        result_queue.put(('error', -1.0))
        debug_kwargs = {k:v for k,v in kwargs.items() if not isinstance(v, torch.Tensor)}
        logging.warning(f"bench config {debug_kwargs} failed: {e} ")

def autotune_func(all_kwargs, kernel_type, module_name, func_name, config, key_name=None):
    kernel_params = {}
    # Only support gemm kernel now.
    # Developers can add more kernel type for autotuning.
    if kernel_type in AUTOTUNE_KERNEL_TYPE.keys():
        assert all(v in all_kwargs.keys() for v in AUTOTUNE_KERNEL_TYPE[kernel_type]), f"{kernel_type} decorator need {AUTOTUNE_KERNEL_TYPE[kernel_type]} argument!"
        kernel_params = {k: all_kwargs[k] for k in AUTOTUNE_KERNEL_TYPE[kernel_type]}

    min_ms = float('inf')
    best_kwargs = all_kwargs.copy()
    pd_dict = {'platform': [torch.cuda.get_device_name(0)], 'kernel_name': [module_name], **kernel_params, 'best_ms': 0.0}
    logging.info(f"start tuning for {kernel_params}. please wait...")
    num_gpus = torch.cuda.device_count()

    mp.set_start_method('spawn', force=True)
    for i_c in range(0, len(config.index), num_gpus):
        config_indx_ = config.index[i_c:i_c+num_gpus]
        processes = []
        for n_i, i in enumerate(config_indx_):
            gpu_id = n_i % num_gpus
            info = ""
            for k,v in config.items():
                all_kwargs[k] = v[i]
                info += f"{k}: {v[i]} "
        
            q = mp.Queue()
            p = mp.Process(target=bench_worker, args=(gpu_id, module_name, func_name, all_kwargs, q, key_name))
            processes.append([p, q])
            p.start()
        
        for n_i, [p, q] in enumerate(processes):
            status, ms = q.get()
            p.join()
            
            if status == 'success':
                logging.debug(f"Task {i_c+n_i} succeeded")
            else:
                logging.debug(f"Task {i_c+n_i} unsupported: {info}")
                if ms == -3.0: # ValueError (config not support)
                    # stop all subprocesses
                    for stop_i in range(n_i+1, num_gpus):
                        processes[stop_i][0].terminate()
                        processes[stop_i][0].join()
                    return -3.0
                continue
            
            if ms <= 0:
                continue

            logging.info(f"{info} cost time: {ms}")
            if ms < min_ms:
                min_ms = ms
                # best_kwargs.update(all_kwargs)
                pd_dict['best_ms'] = [min_ms]
                i = config_indx_[n_i]
                for k,v in config.items():
                    pd_dict[k] = [v[i]]
                    best_kwargs[k] = v[i]
    
    logging.info(f"best config is {pd_dict}")

    # update old file
    os_config_path = os.getenv("AUTOTUNE_CONFIG_PATH")
    csv_file = f"{config_dir}/{module_name}.csv" if not os_config_path else f"{os_config_path}/{module_name}.csv"
    if os.path.exists(csv_file):
        df = pd.read_csv(csv_file, encoding='utf-8')
        mask = reduce(operator.and_, [df[k] == pd_dict[k] for k in AUTOTUNE_KERNEL_TYPE[kernel_type]])
        row_ = df.loc[mask & (df['platform'] == torch.cuda.get_device_name(0))].index
        if (len(row_) > 0 and pd_dict["best_ms"] < df["best_ms"][row_[0]]) or len(row_) == 0:
            logging.info(f"get new best config for {kernel_params}, update old csv file")
            df = pd.concat([df, pd.DataFrame(pd_dict)]).drop_duplicates(subset=[k for k in AUTOTUNE_KERNEL_TYPE[kernel_type]], keep='last')
            df.to_csv(csv_file, index=False)
    else:
        df = pd.DataFrame(pd_dict)
        df.to_csv(csv_file, index=False)

    return pd_dict["best_ms"][0]

def cuda_kernel(
    default_config: dict = {}, 
    kernel_type: str = None, 
    link_kernel: str = None,
    explore_keys: list = None,
    key_name: str = None
):
    """
        - default_config: config used for autotune.
        - kernel_type: kernel type defined for autotune.
        - link_kernel: Some sub-kernels share the same so file with the main kernel.
    """
    def decorator(func):
        @wraps(func)
        def wrapped_function(*args, **kwargs):
            recopy_cutlass()

            module_name = func.__name__
            func_name = func.__name__
            if link_kernel:
                module_name = link_kernel
            sig = inspect.signature(func)
            bound_args = sig.bind(*args, **kwargs)
            bound_args.apply_defaults()

            all_kwargs = bound_args.arguments
            config = all_kwargs.pop("config", None)
            if config == {}:
                config = None
            
            if os.getenv("AUTOTUNE_MODE") == "1" and (kernel_type != None and link_kernel == None):
                # AUTOTUNE MODE
                if not config:
                    config = default_config     
                assert all(isinstance(v, list) for v in config.values()), "type of config value must be list!"
                first_len = len(next(iter(config.values())))
                assert all(len(v) == first_len for v in config.values()), "length of config value must be same!"
                config = pd.DataFrame(config)

                if os.path.exists(
                    f"{config_dir}/{module_name}_unsupported.csv"):
                    df = pd.read_csv(f"{config_dir}/{module_name}_unsupported.csv", encoding='utf-8')
                    config = get_valid_config(df, config, module_name)

                if os.getenv("COMPILE_EXPLORE") == "1" and explore_keys:
                    config = compile_explore(explore_keys, config, module_name)
            
                if os.path.exists(
                        f"{build_dir}/{module_name}/build/{module_name}.so"):
                    if os.getenv("ATREX_JIT_RECOMPILE") == "1":
                        # recompile for unset AUTOTUNE_CPPEVENT
                        logging.warning(f"{module_name} kernel will be recompiled...")
                        shutil.rmtree(f"{build_dir}/{pack_name}", ignore_errors=True)
                        os.environ["ATREX_JIT_RECOMPILE"] = '0'
                    else:
                        # TODO: cache tuned config to accelerate autotune
                        ms =  autotune_func(all_kwargs, kernel_type, module_name, func_name, config, key_name)
                        if ms == -3.0: # ValueError (config not support, need recompile)
                            logging.warning(f"{module_name} kernel execute unsupport")
                            logging.info(f"recompile {module_name} kernel...")
                            os.remove(f"{build_dir}/{module_name}/build/{module_name}.so") if os.path.exists(f"{build_dir}/{module_name}/build/{module_name}.so") else None
                        else:
                            return ms
                
                if not os.path.exists(
                        f"{build_dir}/{module_name}/build/{module_name}.so"):
                    d_args = get_args_of_build(module_name)
                    srcs = d_args["srcs"]
                    flags_extra_cc = d_args["flags_extra_cc"]
                    flags_extra_hip = d_args["flags_extra_hip"]
                    if os.getenv("AUTOTUNE_CPPEVENT") == "1":
                        flags_extra_hip += ["-DAUTOTUNE_CPPEVENT"]
                        logging.info("Use CPPEVENT to support autotune.")
                    blob_gen_cmd = d_args["blob_gen_cmd"]
                    if len(blob_gen_cmd) > 0:
                        for k,v_l in config.items():
                            blob_gen_cmd[0] += " --{} ".format(k)
                            for v in v_l:
                                blob_gen_cmd[0] += "{} ".format(v)

                    extra_include = d_args["extra_include"] + \
                                    [cutlass_dir+"/include", cutlass_dir+"/tools/util/include"]
                    extra_ldflags = d_args["extra_ldflags"]
                    verbose = d_args["verbose"]
                    is_python_module = d_args["is_python_module"]
                    is_standalone = d_args["is_standalone"]
                    torch_exclude = d_args["torch_exclude"]
                    hipify = d_args.get("hipify", False)
                    build_nv_module(
                        module_name,
                        srcs,
                        flags_extra_cc,
                        flags_extra_hip,
                        blob_gen_cmd,
                        extra_include,
                        extra_ldflags,
                        verbose,
                        is_python_module,
                        is_standalone,
                        torch_exclude,
                        hipify,
                    )

                return autotune_func(all_kwargs, kernel_type, module_name, func_name, config, key_name)
            else:
                # EXECUTE MODE
                if os.getenv("AUTOTUNE_MODE") == "1":
                    logging.warning(f"{module_name} kernel not support autotune mode, use execute mode instead.")
                pack_name = module_name
                build_config = {**default_config}
                
                if config:
                    # use config defined by user to execute
                    for k,v in config.items():
                        all_kwargs[k] = v[0]
                        build_config[k].extend(v)
                else:
                    for k,v in default_config.items():
                        all_kwargs[k] = v[0]
                
                if os.path.exists(
                        f"{build_dir}/{pack_name}/build/{pack_name}.so"):
                    if os.getenv("ATREX_JIT_RECOMPILE") == "1":
                        # recompile for unset AUTOTUNE_CPPEVENT
                        logging.warning(f"{module_name} kernel will be recompiled...")
                        shutil.rmtree(f"{build_dir}/{pack_name}", ignore_errors=True)
                        os.environ["ATREX_JIT_RECOMPILE"] = '0'
                    else:
                        module = get_module(pack_name)
                        op = getattr(module, func_name)
                        try:
                            return op(**all_kwargs)
                        except ValueError as ve:
                            logging.warning(f"{module_name} kernel execute failed: {ve} ")
                            logging.info(f"recompile {module_name} kernel...")
                            shutil.rmtree(f"{build_dir}/{pack_name}", ignore_errors=True)

                if not os.path.exists(
                        f"{build_dir}/{pack_name}/build/{pack_name}.so"):
                    # get best config from csv to compile so file
                    if os.path.exists(
                        f"{config_dir}/{module_name}.csv") or os.getenv("AUTOTUNE_CONFIG_PATH"):
                        os_config_path = os.getenv("AUTOTUNE_CONFIG_PATH")
                        csv_file = f"{config_dir}/{module_name}.csv" if not os_config_path else f"{os_config_path}/{module_name}.csv"
                        logging.info(f"load {csv_file} to get best config")

                        df = pd.read_csv(csv_file, encoding='utf-8')
                        module_row = df.loc[(df['platform'] == torch.cuda.get_device_name(0)) & (df['kernel_name']==module_name)].index
                        for k in default_config.keys():
                            build_config[k].extend(df[k][module_row].tolist())
                    
                    d_args = get_args_of_build(module_name)
                    srcs = d_args["srcs"]
                    flags_extra_cc = d_args["flags_extra_cc"]
                    flags_extra_hip = d_args["flags_extra_hip"]
                    # add cpp event for debug
                    if os.getenv("AUTOTUNE_CPPEVENT") == "1":
                        flags_extra_hip += ["-DAUTOTUNE_CPPEVENT"]
                        logging.warning("get AUTOTUNE_CPPEVENT == 1. Use cpp event for debug which will effect performance.")
                    blob_gen_cmd = d_args["blob_gen_cmd"]
                    if len(blob_gen_cmd) > 0:
                        for k,v_l in build_config.items():
                            blob_gen_cmd[0] += " --{} ".format(k)
                            assert type(v_l) is list, "value type of tune config must be list!"
                            logging.debug(f"key {k} has value lens = {len(v_l)}")
                            for v in v_l:
                                blob_gen_cmd[0] += "{} ".format(v)

                    extra_include = d_args["extra_include"] + \
                                    [cutlass_dir+"/include", cutlass_dir+"/tools/util/include"]
                    extra_ldflags = d_args["extra_ldflags"]
                    verbose = d_args["verbose"]
                    is_python_module = d_args["is_python_module"]
                    is_standalone = d_args["is_standalone"]
                    torch_exclude = d_args["torch_exclude"]
                    hipify = d_args.get("hipify", False)
                    build_nv_module(
                        pack_name,
                        srcs,
                        flags_extra_cc,
                        flags_extra_hip,
                        blob_gen_cmd,
                        extra_include,
                        extra_ldflags,
                        verbose,
                        is_python_module,
                        is_standalone,
                        torch_exclude,
                        hipify,
                    )
                module = get_module(pack_name)
                op = getattr(module, func_name)
                return op(**all_kwargs)
        wrapped_function.default_config = default_config
        return wrapped_function
    return decorator
