import importlib
import shutil
import os
import json
import re
import traceback
import sys
from functools import wraps, lru_cache
from packaging.version import Version, parse
import inspect

from atrex.utils.compile_utils import get_hip_version, check_and_set_ninja_worker, hip_flag_checker, jit_compile, get_src_files, get_directories
from atrex.utils.chip_info import get_gfx, validate_and_update_archs

current_dir = os.path.dirname(os.path.abspath(__file__))
src_dir, build_dir = get_directories(current_dir)

ck_dir = f"{build_dir}/ck"
ck_thirdparty_dir = f"{current_dir}/../third_party/composable_kernel"
ck_helper_dir = f"{current_dir}/../third_party/ck_helper"

os.makedirs(build_dir, exist_ok=True)
os.makedirs(ck_dir, exist_ok=True)


@lru_cache(maxsize=1024)
def get_module(module_name):
    spec = importlib.util.spec_from_file_location(
        module_name, f"{build_dir}/{module_name}/build/{module_name}.so")
    module = importlib.util.module_from_spec(spec)
    sys.modules[module_name] = module
    spec.loader.exec_module(module)
    return module


def get_args_of_build(ops_name: str, exclude=[]):
    d_opt_build_args = {
        "srcs": [],
        "md_name": "",
        "flags_extra_cc": [],
        "flags_extra_hip": [],
        "extra_ldflags": None,
        "extra_include": [],
        "verbose": False,
        "is_python_module": True,
        "is_standalone": False,
        "torch_exclude": False,
        "hip_clang_path": None,
        "blob_gen_cmd": "",
    }

    def convert(d_ops: dict):
        for k, val in d_ops.items():
            if isinstance(val, list):
                for idx, el in enumerate(val):
                    if isinstance(el, str):
                        if "torch" in el:
                            import torch as torch
                        val[idx] = eval(el)
                d_ops[k] = val
            elif isinstance(val, str):
                d_ops[k] = eval(val)
            else:
                pass

        # undefined compile features will be replaced with default value
        d_opt_build_args.update(d_ops)
        return d_opt_build_args

    with open(current_dir + "/optCompilerConfig.json", "r") as file:
        data = json.load(file)
        if isinstance(data, dict):
            compile_ops_ = data.get(ops_name)
            return convert(compile_ops_)
        else:
            raise TypeError(
                "please use dict_format to write 'optCompilerConfig.json'! ")


@lru_cache()
def recopy_ck():
    config_path = f"{ck_dir}/include/ck/config.h"
    if os.path.exists(config_path):
        return
    if os.path.exists(ck_dir):
        os.system(f"rm -rf {ck_dir}")
    shutil.copytree(ck_thirdparty_dir, ck_dir, dirs_exist_ok=True)
    shutil.copy(f"{ck_helper_dir}/config.h", config_path)


def build_module(
    md_name,
    srcs,
    flags_extra_cc,
    flags_extra_hip,
    blob_gen_cmd,
    extra_include,
    extra_ldflags,
    verbose,
    is_python_module,
    is_standalone,
    torch_exclude,
    hipify=False,
    prebuild=0,
):
    target_name = f"{md_name}.so"
    op_dir = f"{build_dir}/{md_name}"
    print(f"start build [{md_name}] under {op_dir}")

    op_build_dir = f"{op_dir}/build"
    op_src_dir = f"{op_dir}/build/srcs"
    os.makedirs(op_src_dir, exist_ok=True)
    recopy_ck()
    flags_cc = ["-O3", "-std=c++20"]
    flags_hip = [
        "-DLEGACY_HIPBLAS_DIRECT",
        "-DUSE_PROF_API=1",
        "-D__HIP_PLATFORM_HCC__=1",
        "-D__HIP_PLATFORM_AMD__=1",
        "-U__HIP_NO_HALF_CONVERSIONS__",
        "-U__HIP_NO_HALF_OPERATORS__",
        "-mllvm --amdgpu-kernarg-preload-count=16",
        "-Wno-unused-result",
        "-Wno-switch-bool",
        "-Wno-vla-cxx-extension",
        "-Wno-undefined-func-template",
        "-Wno-macro-redefined",
        "-Wno-missing-template-arg-list-after-template-kw",
        "-fgpu-flush-denormals-to-zero",
    ]

    # Imitate
    # https://github.com/ROCm/composable_kernel/blob/c8b6b64240e840a7decf76dfaa13c37da5294c4a/CMakeLists.txt#L190-L214
    hip_version = parse(get_hip_version().split()
                        [-1].rstrip("-").replace("-", "+"))
    if hip_version <= Version("6.3.42132"):
        flags_hip += ["-mllvm --amdgpu-enable-max-ilp-scheduling-strategy=1"]
    if hip_version > Version("5.5.00000"):
        flags_hip += ["-mllvm --lsr-drop-solution=1"]
    if hip_version > Version("5.7.23302"):
        flags_hip += ["-fno-offload-uniform-block"]
    if hip_version > Version("6.1.40090"):
        flags_hip += ["-mllvm -enable-post-misched=0"]
    if hip_version > Version("6.2.41132"):
        flags_hip += [
            "-mllvm -amdgpu-early-inline-all=true",
            "-mllvm -amdgpu-function-calls=false",
        ]
    if hip_version > Version("6.2.41133"):
        flags_hip += ["-mllvm -amdgpu-coerce-illegal-types=1"]
    if get_gfx() == "gfx950" and int(os.getenv("AITER_FP4x2", "1")) > 0:
        flags_hip += ["-D__Float4_e2m1fn_x2"]

    if not torch_exclude:
        import torch

        if hasattr(torch, "float4_e2m1fn_x2"):
            flags_hip += ["-DTORCH_Float4_e2m1fn_x2"]

    flags_cc += flags_extra_cc
    flags_hip += flags_extra_hip
    archs = validate_and_update_archs()
    flags_hip += [f"--offload-arch={arch}" for arch in archs]
    flags_hip = sorted(set(flags_hip))  # remove same flags
    flags_hip = [el for el in flags_hip if hip_flag_checker(el)]
    check_and_set_ninja_worker()

    # autogen ck headers
    blob_dir = f"{op_dir}/blob"
    os.makedirs(blob_dir, exist_ok=True)
    for sub_blob_gen_cmd in blob_gen_cmd:
        os.system(f"python {sub_blob_gen_cmd.format(blob_dir)}")
    srcs += get_src_files(blob_dir, ".cu")
    extra_include_paths = [
        f"{ck_dir}/include",
        f"{ck_dir}/library/include",
        f"{src_dir}/ck/include",
        f"{op_dir}/blob",
    ] + extra_include

    try:
        jit_compile(
            md_name,
            sorted(set(srcs)),
            extra_cflags=flags_cc,
            extra_cuda_cflags=flags_hip,
            extra_ldflags=extra_ldflags,
            extra_include_paths=extra_include_paths,
            build_directory=op_build_dir,
            verbose=verbose,
            with_cuda=True,
            is_python_module=is_python_module,
            is_standalone=is_standalone,
            torch_exclude=torch_exclude,
            hipify=hipify,
            prebuild=prebuild,
        )
    except Exception as e:
        tag = f"\033[31mfailed jit build [{md_name}]\033[0m"
        raise TypeError(
            f"{tag}\u2193\u2193\u2193\u2193\u2193\u2193\u2193\u2193\u2193\u2193\n-->[History]: {{}}{tag}\u2191\u2191\u2191\u2191\u2191\u2191\u2191\u2191\u2191\u2191".format(
                re.sub(
                    "error:",
                    "\033[31merror:\033[0m",
                    "-->".join(traceback.format_exception(*sys.exc_info())),
                    flags=re.I,
                ),
            )
        )
        raise SystemExit(
            f"build [{md_name}] under {opbd_dir} failed !!!!!!"
        ) from e

    print(f"build finished for {md_name}")


def ck_kernel(params: list[list[str]]):
    def decorator(func):
        @wraps(func)
        def wrapped_function(*args, **kwargs):
            module_name = func.__name__
            sig = inspect.signature(func)
            bound_args = sig.bind(*args, **kwargs)
            bound_args.apply_defaults()
            pack_name = module_name
            for param in params:
                for k in param:
                    pack_name += f"_{dict(bound_args.arguments)[k]}"

            if not os.path.exists(
                    f"{build_dir}/{pack_name}/build/{pack_name}.so"):
                d_args = get_args_of_build(module_name)
                srcs = d_args["srcs"]
                flags_extra_cc = d_args["flags_extra_cc"]
                flags_extra_hip = d_args["flags_extra_hip"]
                blob_gen_cmd = d_args["blob_gen_cmd"]
                for i, param in enumerate(params):
                    if i > len(blob_gen_cmd):
                        raise ValueError(
                            f"please add more blob_gen_cmd in optCompilerConfig.json for {pack_name}"
                        )
                    for k in param:
                        blob_gen_cmd[i] += " --{} {}".format(
                            k, dict(bound_args.arguments)[k])
                extra_include = d_args["extra_include"]
                extra_ldflags = d_args["extra_ldflags"]
                verbose = d_args["verbose"]
                is_python_module = d_args["is_python_module"]
                is_standalone = d_args["is_standalone"]
                torch_exclude = d_args["torch_exclude"]
                hipify = d_args.get("hipify", False)
                build_module(
                    pack_name,
                    srcs,
                    flags_extra_cc,
                    flags_extra_hip,
                    blob_gen_cmd,
                    extra_include,
                    extra_ldflags,
                    verbose,
                    is_python_module,
                    is_standalone,
                    torch_exclude,
                    hipify,
                )
            module = get_module(pack_name)
            op = getattr(module, module_name)
            return op(*args, **kwargs)
        return wrapped_function
    return decorator
