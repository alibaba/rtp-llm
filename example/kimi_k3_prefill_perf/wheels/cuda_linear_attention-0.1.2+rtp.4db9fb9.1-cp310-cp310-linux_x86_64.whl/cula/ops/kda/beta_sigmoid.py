# Copyright 2025-2026 Ant Group Co., Ltd.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

"""Single-launch FP32 sigmoid preprocessing for KDA beta logits."""

from __future__ import annotations

import torch
import triton
import triton.language as tl


@triton.jit
def _beta_sigmoid_fwd_kernel(
    x,
    y,
    n_elements,
    BLOCK_SIZE: tl.constexpr,
):
    offsets = tl.program_id(0).to(tl.int64) * BLOCK_SIZE + tl.arange(
        0, BLOCK_SIZE
    ).to(tl.int64)
    mask = offsets < n_elements
    values = tl.load(x + offsets, mask=mask, other=0).to(tl.float32)
    tl.store(y + offsets, tl.sigmoid(values), mask=mask)


@triton.jit
def _beta_sigmoid_bwd_kernel(
    x,
    dy,
    dx,
    n_elements,
    BLOCK_SIZE: tl.constexpr,
):
    offsets = tl.program_id(0).to(tl.int64) * BLOCK_SIZE + tl.arange(
        0, BLOCK_SIZE
    ).to(tl.int64)
    mask = offsets < n_elements
    values = tl.load(x + offsets, mask=mask, other=0).to(tl.float32)
    gradients = tl.load(dy + offsets, mask=mask, other=0).to(tl.float32)
    sigmoid = tl.sigmoid(values)
    tl.store(
        dx + offsets,
        gradients * sigmoid * (1.0 - sigmoid),
        mask=mask,
    )


class _BetaSigmoidFunction(torch.autograd.Function):
    @staticmethod
    def forward(ctx, x: torch.Tensor) -> torch.Tensor:
        if not x.is_cuda or not x.is_contiguous():
            raise ValueError("KDA beta logits must be contiguous CUDA input")
        y = torch.empty_like(x, dtype=torch.float32)
        block_size = 2048
        _beta_sigmoid_fwd_kernel[(triton.cdiv(x.numel(), block_size),)](
            x,
            y,
            x.numel(),
            BLOCK_SIZE=block_size,
            num_warps=8,
        )
        ctx.save_for_backward(x)
        return y

    @staticmethod
    def backward(ctx, dy: torch.Tensor):
        (x,) = ctx.saved_tensors
        dx = torch.empty_like(x)
        block_size = 2048
        _beta_sigmoid_bwd_kernel[(triton.cdiv(x.numel(), block_size),)](
            x,
            dy.contiguous(),
            dx,
            x.numel(),
            BLOCK_SIZE=block_size,
            num_warps=8,
        )
        return dx


def beta_sigmoid(x: torch.Tensor) -> torch.Tensor:
    """Convert CUDA beta logits to contiguous sigmoid probabilities in FP32.

    Non-contiguous views are materialized before entering the flat Triton
    kernel. Keeping ``contiguous()`` outside the custom autograd function also
    lets PyTorch map the returned gradient back through the original view.
    """

    if not x.is_cuda:
        raise ValueError("KDA beta logits must be CUDA input")
    return _BetaSigmoidFunction.apply(x.contiguous())
