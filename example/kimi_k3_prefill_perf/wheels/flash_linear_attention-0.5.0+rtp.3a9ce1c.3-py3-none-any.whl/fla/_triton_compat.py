# Copyright (c) 2023-2026, Songlin Yang, Yu Zhang, Zhiyuan Li
#
# This source code is licensed under the MIT license found in the
# LICENSE file in the root directory of this source tree.
# For a list of all contributors, visit:
#   https://github.com/fla-org/flash-linear-attention/graphs/contributors

"""Compatibility helpers for supported Python and Triton combinations."""

from __future__ import annotations

import functools
import inspect
import linecache
import re
import sys
import textwrap
from collections.abc import Callable
from typing import Any


def _has_function_definition(fn: Callable[..., Any]) -> bool:
    source = textwrap.dedent("".join(inspect.getsourcelines(fn)[0]))
    return re.search(r"^(?:async\s+)?def\s+\w+\s*\(", source, re.MULTILINE) is not None


def _move_first_line_to_definition(fn: Callable[..., Any]) -> None:
    if _has_function_definition(fn):
        return

    filename = inspect.getsourcefile(fn)
    if filename is None:
        return

    lines = linecache.getlines(filename)
    start = max(fn.__code__.co_firstlineno - 1, 0)
    pattern = re.compile(rf"^\s*(?:async\s+)?def\s+{re.escape(fn.__name__)}\s*\(")
    for line_number in range(start, min(start + 256, len(lines))):
        if pattern.search(lines[line_number]) is not None:
            fn.__code__ = fn.__code__.replace(co_firstlineno=line_number + 1)
            return


def install_triton_jit_py310_compat() -> None:
    """Work around Python 3.10 source lookup for multiline decorators.

    On Python 3.10, ``inspect.getsourcelines`` can return only the outermost
    multiline decorator of a function. Triton then cannot find the function
    definition while constructing ``JITFunction``. Python 3.11 fixed the
    underlying source-position behavior.
    """
    if sys.version_info >= (3, 11):
        return

    import triton

    original_jit = triton.jit
    if getattr(original_jit, "_fla_py310_compatible", False):
        return

    @functools.wraps(original_jit)
    def compatible_jit(fn=None, *args, **kwargs):
        def decorate(func):
            if getattr(func, "__module__", "").startswith("fla."):
                _move_first_line_to_definition(func)
            return original_jit(func, *args, **kwargs)

        return decorate if fn is None else decorate(fn)

    compatible_jit._fla_py310_compatible = True
    triton.jit = compatible_jit
