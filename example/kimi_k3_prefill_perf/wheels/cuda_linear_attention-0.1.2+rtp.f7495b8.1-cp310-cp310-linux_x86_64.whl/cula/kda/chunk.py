# Copyright 2025-2026 Ant Group Co., Ltd.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

# Copyright (c) 2023-2025, Songlin Yang, Yu Zhang
# Related files are modified and supported by the Moonshot AI Team

"""SM100 modular chunk KDA public API and autograd wrapper"""

from typing import Literal

import torch
from fla.modules.l2norm import l2norm_bwd, l2norm_fwd
from fla.ops.cp import FLACPContext
from fla.ops.utils.index import prepare_chunk_indices
from fla.utils import autocast_custom_bwd, autocast_custom_fwd, input_guard

from cula.kda.chunk_bwd import chunk_kda_bwd
from cula.kda.chunk_fwd import chunk_kda_fwd
from cula.ops.kda.cp_mode import CPMode


class ChunkKDAFunction(torch.autograd.Function):
    @staticmethod
    @input_guard
    @autocast_custom_fwd
    def forward(
        ctx,
        q: torch.Tensor,
        k: torch.Tensor,
        v: torch.Tensor,
        g: torch.Tensor,
        beta: torch.Tensor,
        A_log: torch.Tensor,
        dt_bias: torch.Tensor,
        scale: float,
        initial_state: torch.Tensor,
        output_final_state: bool = False,
        use_qk_l2norm_in_kernel: bool = False,
        use_gate_in_kernel: bool = False,
        cu_seqlens: torch.IntTensor | None = None,
        cu_seqlens_cpu: torch.IntTensor | None = None,
        safe_gate: bool = False,
        lower_bound: float | None = None,
        disable_recompute: bool = False,
        return_intermediate_states: bool = False,
        cp_context: FLACPContext | None = None,
        use_intracard_cp: CPMode | None = None,
        checkpoint_states: torch.Tensor | None = None,
        checkpoint_interval: int | None = None,
    ):
        chunk_size = 64

        # Apply l2norm
        q_rstd, k_rstd = None, None
        if use_qk_l2norm_in_kernel:
            q, q_rstd = l2norm_fwd(q)
            k, k_rstd = l2norm_fwd(k)

        chunk_indices = (
            prepare_chunk_indices(cu_seqlens, chunk_size, cu_seqlens_cpu=cu_seqlens_cpu) if cu_seqlens is not None else None
        )

        g_org = g if use_gate_in_kernel else None

        (o, final_state, g, Aqk, Akk, w, u, qg, kg, v_new, h, initial_state) = chunk_kda_fwd(
            q=q,
            k=k,
            v=v,
            g=g,
            beta=beta,
            scale=scale,
            initial_state=initial_state,
            output_final_state=output_final_state,
            cu_seqlens=cu_seqlens,
            cu_seqlens_cpu=cu_seqlens_cpu,
            chunk_indices=chunk_indices,
            safe_gate=safe_gate,
            lower_bound=lower_bound,
            use_gate_in_kernel=use_gate_in_kernel,
            A_log=A_log,
            dt_bias=dt_bias,
            disable_recompute=disable_recompute,
            return_intermediate_states=return_intermediate_states,
            cp_context=cp_context,
            use_intracard_cp=use_intracard_cp,
            checkpoint_states=checkpoint_states,
            checkpoint_interval=checkpoint_interval,
        )

        if checkpoint_states is not None:
            assert torch.is_inference_mode_enabled(), (
                "FP32 checkpoint states are inference-only"
            )
            return o.type_as(q), final_state, checkpoint_states
        if return_intermediate_states:
            assert torch.is_inference_mode_enabled(), "return_intermediate_states is only allowed in inference mode"
            assert disable_recompute is False, "return_intermediate_states must be used with disable_recompute=False"
            return o.type_as(q), final_state, h

        ctx.save_for_backward(
            q,
            q_rstd,
            k,
            k_rstd,
            v,
            g,
            g_org,
            beta,
            A_log,
            dt_bias,
            Aqk,
            Akk,
            w,
            u,
            qg,
            kg,
            v_new,
            h,
            initial_state,
            cu_seqlens,
            chunk_indices,
        )
        ctx.chunk_size = chunk_size
        ctx.safe_gate = safe_gate
        ctx.scale = scale
        ctx.lower_bound = lower_bound
        ctx.use_qk_l2norm_in_kernel = use_qk_l2norm_in_kernel
        ctx.use_gate_in_kernel = use_gate_in_kernel
        ctx.disable_recompute = disable_recompute
        ctx.cp_context = cp_context
        return o.type_as(q), final_state

    @staticmethod
    @input_guard
    @autocast_custom_bwd
    def backward(
        ctx,
        do: torch.Tensor,
        dht: torch.Tensor,
        dcheckpoint_states: torch.Tensor | None = None,
    ):
        (
            q,
            q_rstd,
            k,
            k_rstd,
            v,
            g,
            g_org,
            beta,
            A_log,
            dt_bias,
            Aqk,
            Akk,
            w,
            u,
            qg,
            kg,
            v_new,
            h,
            initial_state,
            cu_seqlens,
            chunk_indices,
        ) = ctx.saved_tensors

        dq, dk, dv, db, dg, dh0, dA, dbias = chunk_kda_bwd(
            q=q,
            k=k,
            v=v,
            g=g,
            beta=beta,
            Aqk=Aqk,
            Akk=Akk,
            scale=ctx.scale,
            initial_state=initial_state,
            do=do,
            dht=dht,
            cu_seqlens=cu_seqlens,
            chunk_indices=chunk_indices,
            chunk_size=ctx.chunk_size,
            safe_gate=ctx.safe_gate,
            g_org=g_org,
            lower_bound=ctx.lower_bound,
            use_gate_in_kernel=ctx.use_gate_in_kernel,
            A_log=A_log,
            dt_bias=dt_bias,
            disable_recompute=ctx.disable_recompute,
            w=w,
            u=u,
            qg=qg,
            kg=kg,
            v_new=v_new,
            h=h,
            cp_context=ctx.cp_context,
        )
        if ctx.use_qk_l2norm_in_kernel:
            dq = l2norm_bwd(q, q_rstd, dq)
            dk = l2norm_bwd(k, k_rstd, dk)

        return (
            dq.to(q),
            dk.to(k),
            dv.to(v),
            dg.to(g),
            db.to(beta),
            dA,
            dbias,
            None,
            dh0,
            None,
            None,
            None,
            None,
            None,
            None,
            None,
            None,
            None,
            None,
            None,
            None,
            None,
        )


@torch.compiler.disable
def chunk_kda(
    q: torch.Tensor,
    k: torch.Tensor,
    v: torch.Tensor,
    g: torch.Tensor,
    beta: torch.Tensor,
    scale: float | None = None,
    initial_state: torch.Tensor | None = None,
    output_final_state: bool = False,
    use_qk_l2norm_in_kernel: bool = False,
    use_gate_in_kernel: bool = False,
    cu_seqlens: torch.IntTensor | None = None,
    cu_seqlens_cpu: torch.IntTensor | None = None,
    safe_gate: bool = False,
    lower_bound: float | None = None,
    disable_recompute: bool = False,
    return_intermediate_states: bool = False,
    cp_context: FLACPContext = None,
    use_intracard_cp: Literal["auto"] | bool | None = None,
    use_beta_sigmoid_in_kernel: bool = False,
    checkpoint_interval: int | None = None,
    checkpoint_states: torch.Tensor | None = None,
    **kwargs,
):
    r"""
    Args:
        q (torch.Tensor):
            queries of shape `[B, T, H, K]`.
        k (torch.Tensor):
            keys of shape `[B, T, H, K]`.
        v (torch.Tensor):
            values of shape `[B, T, H, V]`.
        g (torch.Tensor):
            (forget) gating tensor (in log space!) of shape `[B, T, H, K]`.
        beta (torch.Tensor):
            betas of shape `[B, T, H]`.
        scale (Optional[float]):
            Scale factor for the KDA attention scores.
            If not provided, it will default to `1 / sqrt(K)`. Default: `None`.
        initial_state (Optional[torch.Tensor]):
            Initial state of shape `[N, H, K, V]` for `N` input sequences.
            For equal-length input sequences, `N` equals the batch size `B`.
            Default: `None`.
        output_final_state (Optional[bool]):
            Whether to output the final state of shape `[N, H, K, V]`. Default: `False`.
        use_qk_l2norm_in_kernel (bool):
            Whether to apply L2norm to the q,k tensor internally. Default: `False`.
        use_gate_in_kernel (bool):
            Whether to compute the log-space KDA decay internally.
            - If `True`:
              The passed `g` acts as the raw input for `-exp(A_log).view(H, -1) * softplus(g + dt_bias.view(H, K))`.
              Note that as part of the input arguments,
              `A_log` (shape `[H]`) and the optional `dt_bias` (shape `[H * K]`) should be provided.
            - If `False`, `g` is expected to be the pre-computed decay value.
            Default: `False`.
        cu_seqlens (torch.IntTensor):
            Cumulative sequence lengths of shape `[N+1]` used for variable-length training,
            consistent with the FlashAttention API. Must be int32.
        cu_seqlens_cpu (torch.IntTensor):
            Cumulative sequence lengths of shape `[N+1]` used for variable-length training,
            consistent with the FlashAttention API. Must be int32.
        safe_gate (bool):
            Whether the kernel can assume the input gate values `g` are in a safe range.
            When `True`, the kernel can use M=16 TensorCore acceleration.
            The safe range is approximately [-5, 0). Default: `False`.
        lower_bound (Optional[float]):
            Lower bound for the forget gate activation function when `use_gate_in_kernel=True`.
            This parameter modifies the internal forget gate activation and is recommended
            to be set to `-5` when `safe_gate` is enabled. Default: `None`.
        disable_recompute (bool):
            Whether to disable gradient recomputation in the kernel. When `True`, the kernel
            will save all intermediate activations for backward pass, which is beneficial
            for training small models at the cost of increased memory usage. Default: `False`.
        return_intermediate_states (bool):
            If True, returns intermediate state `h` for inference scenarios (e.g., vLLM).
            Must be used within `torch.inference_mode()` and will return a 3-tuple instead of 2-tuple.
            This is not intended for training as it bypasses autograd. Default: `False`.
        use_beta_sigmoid_in_kernel (bool):
            Whether `beta` contains logits that must be passed through sigmoid
            before KDA. The activation is launched inside this public call.
        checkpoint_interval (Optional[int]):
            When set, publish exact FP32 recurrent states at this token
            interval and return them as the third output. The interval must be
            a positive multiple of the 64-token chunk size.
        checkpoint_states (Optional[torch.Tensor]):
            Optional preallocated contiguous FP32 output with shape
            `[N, C, HV, K, V]`. If omitted, it is allocated automatically.

    Returns:
        - Normal mode (return_intermediate_states=False): A tuple (o, final_state)
            o (torch.Tensor):
                Outputs of shape `[B, T, H, V]`.
            final_state (torch.Tensor):
                Final state of shape `[N, H, K, V]` if `output_final_state=True` else `None`.
        - Inference mode (return_intermediate_states=True): A tuple (o, final_state, h)
            o (torch.Tensor):
                Outputs of shape `[B, T, H, V]`.
            final_state (torch.Tensor):
                Final state of shape `[N, H, K, V]` if `output_final_state=True` else `None`.
            h (torch.Tensor):
                Intermediate states of shape `[B, NT, H, K, V]` and dtype `bfloat16` for caching or further processing.
                - For equal-length sequences: `NT = #chunks_per_sequence` (typically `ceil(T / chunk_size)`)
                - For variable-length sequences (cu_seqlens): B is always 1 (flattened), NT is the total number of chunks across all sequences, determined by `prepare_chunk_indices(cu_seqlens, chunk_size)`

    Examples::
        >>> import torch
        >>> import torch.nn.functional as F
        >>> from einops import rearrange
        >>> from fla.ops.kda import chunk_kda
        # inputs with equal lengths
        >>> B, T, H, K, V = 4, 2048, 4, 512, 512
        >>> q = torch.randn(B, T, H, K, dtype=torch.bfloat16, device='cuda')
        >>> k = torch.randn(B, T, H, K, dtype=torch.bfloat16, device='cuda')
        >>> v = torch.randn(B, T, H, V, dtype=torch.bfloat16, device='cuda')
        >>> beta = torch.rand(B, T, H, dtype=torch.bfloat16, device='cuda')
        >>> g = torch.rand(B, T, H, K, dtype=torch.bfloat16, device='cuda')
        >>> h0 = torch.randn(B, H, K, V, dtype=torch.bfloat16, device='cuda')
        >>> A_log = torch.randn(H, dtype=torch.float32, device='cuda')
        >>> dt_bias = torch.randn(H * K, dtype=torch.float32, device='cuda')
        >>> o, ht = chunk_kda(
            q, k, v, g, beta,
            A_log=A_log,
            dt_bias=dt_bias,
            use_qk_l2norm_in_kernel=True,
            use_gate_in_kernel=True,
            initial_state=h0,
            output_final_state=True
        )
        # for variable-length inputs, the batch size `B` is expected to be 1 and `cu_seqlens` is required
        >>> q, k, v, beta, g = map(lambda x: rearrange(x, 'b t ... -> 1 (b t) ...'), (q, k, v, beta, g))
        # for a batch with 4 sequences, `cu_seqlens` with 5 start/end positions are expected
        >>> cu_seqlens = q.new_tensor([0, 2048, 4096, 6144, 8192], dtype=torch.int32)
        >>> o, ht = chunk_kda(
            q, k, v, g, beta,
            A_log=A_log,
            dt_bias=dt_bias,
            use_qk_l2norm_in_kernel=True,
            use_gate_in_kernel=True,
            initial_state=h0,
            output_final_state=True,
            cu_seqlens=cu_seqlens
        )
    """

    use_intracard_cp = CPMode.parse(use_intracard_cp)

    if cp_context is not None:
        if use_intracard_cp is CPMode.FORCE:
            raise ValueError("use_intracard_cp=True cannot be combined with FLA cp_context.")
        use_intracard_cp = CPMode.OFF
        assert initial_state is None, "Initial state is not supported for CP"
        assert output_final_state is False, "Output final state is not supported for CP"
        assert cp_context.cu_seqlens is not None, "cu_seqlens is required for CP"
        # Override cu_seqlens and cu_seqlens_cpu with the ones from the context
        cu_seqlens = cp_context.cu_seqlens
        if cp_context.cu_seqlens_cpu is not None:
            cu_seqlens_cpu = cp_context.cu_seqlens_cpu

    if return_intermediate_states:
        if use_intracard_cp is CPMode.FORCE:
            raise ValueError("use_intracard_cp=True is not supported with return_intermediate_states=True.")
        use_intracard_cp = CPMode.OFF

    if checkpoint_interval is None:
        if checkpoint_states is not None:
            raise ValueError(
                "checkpoint_states requires checkpoint_interval"
            )
    else:
        if not torch.is_inference_mode_enabled():
            raise ValueError("FP32 checkpoint states are inference-only")
        if return_intermediate_states:
            raise ValueError(
                "checkpoint_interval cannot be combined with "
                "return_intermediate_states"
            )
        if cp_context is not None:
            raise ValueError(
                "checkpoint_interval is not supported with inter-rank CP"
            )
        if checkpoint_interval <= 0 or checkpoint_interval % 64 != 0:
            raise ValueError(
                "checkpoint_interval must be a positive multiple of 64, "
                f"got {checkpoint_interval}"
            )

    if cu_seqlens is not None:
        if q.shape[0] != 1:
            raise ValueError(
                f"The batch size is expected to be 1 rather than {q.shape[0]} when using `cu_seqlens`."
                f"Please flatten variable-length inputs before processing.",
            )
        if initial_state is not None and initial_state.shape[0] != len(cu_seqlens) - 1:
            raise ValueError(
                f"The number of initial states is expected to be equal to the number of input sequences, "
                f"i.e., {len(cu_seqlens) - 1} rather than {initial_state.shape[0]}.",
            )
        assert cu_seqlens.dtype == torch.int32, "cu_seqlens must be in int32"
    if initial_state is not None:
        assert initial_state.dtype == torch.float32, "initial_state must be in float32."

    A_log, dt_bias = kwargs.pop("A_log", None), kwargs.pop("dt_bias", None)
    if kwargs:
        raise TypeError(f"chunk_kda() got unexpected keyword arguments: {sorted(kwargs)}")
    if use_gate_in_kernel:
        assert A_log is not None, "A_log must be provided when use_gate_in_kernel=True."

    if safe_gate and use_gate_in_kernel:
        if lower_bound is None:
            raise ValueError("`lower_bound` must be specified when `safe_gate=True` and `use_gate_in_kernel=True`.")
        if not (-5 <= lower_bound < 0):
            raise ValueError(f"`lower_bound` must be in the safe range [-5, 0), got {lower_bound}.")

    # Validate head dimensions for GVA
    B, T, H, K, HV = *q.shape, v.shape[2]
    assert q.shape == k.shape, f"q and k must have the same shape, got q={q.shape} vs k={k.shape}"
    assert q.dtype == k.dtype == v.dtype == torch.bfloat16, "q, k, v must be in bfloat16."
    assert beta.dtype == torch.bfloat16 or beta.dtype == torch.float32, "beta must be in bfloat16 or float32."
    assert q.shape[-1] == k.shape[-1] == v.shape[-1] == 128, "Currently we only support head dim of 128 for KDA"
    assert HV % H == 0, (
        f"For GVA, num_v_heads (HV={HV}) must be evenly divisible by num_qk_heads (H={H}), but got HV % H = {HV % H}"
    )
    assert g.shape == (B, T, HV, K), f"g must have shape [B, T, HV, K]={[B, T, HV, K]}, got {list(g.shape)}"
    assert beta.shape == (B, T, HV), f"beta must have shape [B, T, HV]={[B, T, HV]}, got {list(beta.shape)}"

    if use_beta_sigmoid_in_kernel:
        from cula.ops.kda.beta_sigmoid import beta_sigmoid

        beta = beta_sigmoid(beta)

    if checkpoint_interval is not None:
        if cu_seqlens is None:
            N = B
            max_sequence_length = T
        else:
            N = int(cu_seqlens.numel() - 1)
            cu_host = (
                cu_seqlens_cpu
                if cu_seqlens_cpu is not None
                else cu_seqlens.cpu()
            )
            cu_values = cu_host.tolist()
            max_sequence_length = max(
                cu_values[index + 1] - cu_values[index]
                for index in range(N)
            )
        checkpoint_count = (
            max_sequence_length + checkpoint_interval - 1
        ) // checkpoint_interval
        expected_checkpoint_shape = (
            N,
            checkpoint_count,
            HV,
            K,
            v.shape[-1],
        )
        if checkpoint_states is None:
            checkpoint_states = torch.empty(
                expected_checkpoint_shape,
                dtype=torch.float32,
                device=q.device,
            )
        elif (
            tuple(checkpoint_states.shape) != expected_checkpoint_shape
            or checkpoint_states.dtype != torch.float32
            or checkpoint_states.device != q.device
            or not checkpoint_states.is_contiguous()
        ):
            raise ValueError(
                "checkpoint_states must be contiguous FP32 on the input "
                f"device with shape {expected_checkpoint_shape}, got "
                f"shape={tuple(checkpoint_states.shape)} "
                f"dtype={checkpoint_states.dtype} "
                f"device={checkpoint_states.device}"
            )

    if scale is None:
        scale = k.shape[-1] ** -0.5
    return ChunkKDAFunction.apply(
        q,
        k,
        v,
        g,
        beta,
        A_log,
        dt_bias,
        scale,
        initial_state,
        output_final_state,
        use_qk_l2norm_in_kernel,
        use_gate_in_kernel,
        cu_seqlens,
        cu_seqlens_cpu,
        safe_gate,
        lower_bound,
        disable_recompute,
        return_intermediate_states,
        cp_context,
        use_intracard_cp,
        checkpoint_states,
        checkpoint_interval,
    )
