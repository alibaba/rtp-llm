// Includes' hash value: 9c500fb17e3e4beba9ec5a765efa873f

#include <deep_gemm/impls/sm100_fp8_fp4_gemm_1d1d.cuh>

using namespace deep_gemm;

static void __instantiate_kernel() {
    auto ptr = reinterpret_cast<void*>(&sm100_fp8_fp4_gemm_1d1d_impl<
        cute::UMMA::Major::K, cute::UMMA::Major::K, 128,
        128, 128,
        0, 6400, 7168,
        16, 128, 128,
        1,
        128, 128, 128,
        12,
        128, 128,
        2, true,
        148,
        1,
        true,
        GemmType::Normal, false,
        cutlass::float_e4m3_t, cutlass::float_e4m3_t, cutlass::bfloat16_t,
        epilogue::transform::EpilogueIdentity
    >);
};
