// Includes' hash value: cb6023cbba7654347977936456a40b19

#define DG_MEGA_MOE_NVLINK_BARRIER_TIMEOUT_SECS 3600
#include <deep_gemm/impls/sm100_fp8_fp4_mega_moe.cuh>

using namespace deep_gemm;

static void __instantiate_kernel() {
    auto ptr = reinterpret_cast<void*>(&sm100_fp8_fp4_mega_moe_impl<
        384,
        3584, 3072,
        896, 7168, 6144,
        16,
        16, 128, 256,
        8,
        128, 128,
        33408,
        534528,
        5,
        3584,
        128, 128, 256,
        148, 8,
        true, false, true, true
    >);
};
