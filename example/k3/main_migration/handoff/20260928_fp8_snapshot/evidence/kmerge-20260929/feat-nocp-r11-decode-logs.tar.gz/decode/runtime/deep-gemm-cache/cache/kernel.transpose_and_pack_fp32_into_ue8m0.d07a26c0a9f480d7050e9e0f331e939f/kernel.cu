// Includes' hash value: 9512609bbbd1830135394cab9e26a884

#include <deep_gemm/impls/smxx_layout.cuh>

using namespace deep_gemm;

static void __instantiate_kernel() {
    auto ptr = reinterpret_cast<void*>(&transpose_and_pack_fp32_into_ue8m0<
        512, 48, 4, 1, false
    >);
};
