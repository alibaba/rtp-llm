// Includes' hash value: 3bb579c24fe0c047424b13b132497588

#include <deep_gemm/impls/sm100_bf16_gemm.cuh>
#include <deep_gemm/impls/sm100_bf16_gemm_rs_policy.cuh>

using namespace deep_gemm;

static void __instantiate_kernel() {
    auto ptr = reinterpret_cast<void*>(&sm100_bf16_gemm_impl<
        cute::UMMA::Major::K, cute::UMMA::Major::MN,
        0, 7168, 1536,
        128, 256, 64,
        1,
        128, 128, 128,
        6,
        128, 128,
        2, false,
        148,
        128,
        0,
        true, GemmType::Normal, false,
        cutlass::bfloat16_t,
        100,
        epilogue::transform::EpilogueIdentity,
        SM100BF16GemmRSExecutionPolicySelector<false, 8>
    >);
};
