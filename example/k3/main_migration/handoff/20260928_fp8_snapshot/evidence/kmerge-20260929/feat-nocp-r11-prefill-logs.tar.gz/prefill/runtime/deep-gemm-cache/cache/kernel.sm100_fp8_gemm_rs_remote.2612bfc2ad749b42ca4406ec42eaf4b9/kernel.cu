// Includes' hash value: 5310df376267c953300ef6dcedebeed1

#include <deep_gemm/impls/sm100_fp8_fp4_gemm_1d1d.cuh>
#include <deep_gemm/impls/sm100_fp8_gemm_rs_policy.cuh>

using namespace deep_gemm;

static void __instantiate_kernel() {
    auto ptr = reinterpret_cast<void*>(&sm100_fp8_fp4_gemm_1d1d_impl<
        cute::UMMA::Major::K, cute::UMMA::Major::K, 128,
        128, 128,
        0, 7168, 1536,
        128, 192, 128,
        1,
        128, 128, 128,
        6,
        128, 128,
        2, false,
        146,
        0,
        true,
        GemmType::Normal, false,
        cutlass::float_e4m3_t, cutlass::float_e4m3_t, cutlass::bfloat16_t,
        epilogue::transform::EpilogueIdentity,
        SM100FP8GemmRSExecutionPolicy<8>
    >);
};
