// Includes' hash value: 4a8af8033f445a5f70eccd03442ef330

#include <deep_gemm/impls/sm100_bf16_gemm_rs_reduce.cuh>

using namespace deep_gemm;

static void __instantiate_kernel() {
    auto ptr = reinterpret_cast<void*>(&sm100_bf16_gemm_rs_reduce_impl<8, 256>);
};
