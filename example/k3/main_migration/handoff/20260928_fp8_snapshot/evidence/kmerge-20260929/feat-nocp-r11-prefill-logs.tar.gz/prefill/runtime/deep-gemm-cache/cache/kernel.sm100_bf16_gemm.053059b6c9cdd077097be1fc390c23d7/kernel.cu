// Includes' hash value: 609d59b565f0c4d626dcac299565b19d

#include <deep_gemm/impls/sm100_bf16_gemm.cuh>

using namespace deep_gemm;

static void __instantiate_kernel() {
    auto ptr = reinterpret_cast<void*>(&sm100_bf16_gemm_impl<
        cute::UMMA::Major::K, cute::UMMA::Major::MN,
        0, 3072, 512,
        128, 256, 64,
        1,
        128, 128, 128,
        6,
        128, 128,
        2, false,
        148,
        128,
        0,
        true,
        GemmType::Normal, false, cutlass::bfloat16_t,
        100, epilogue::transform::EpilogueHeadSplits<128, 64, 128>
    >);
};
