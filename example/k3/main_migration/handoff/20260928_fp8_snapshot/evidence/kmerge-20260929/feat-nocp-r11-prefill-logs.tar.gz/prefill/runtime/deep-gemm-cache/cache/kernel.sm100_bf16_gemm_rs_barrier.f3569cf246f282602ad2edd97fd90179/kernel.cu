// Includes' hash value: 342c1eefc96b7518f41c4e5babed2176

#include <deep_gemm/impls/sm100_bf16_gemm_rs_barrier.cuh>

using namespace deep_gemm;

static void __instantiate_kernel() {
    auto ptr = reinterpret_cast<void*>(
        &sm100_bf16_gemm_rs_barrier_impl<8, 32>);
};
