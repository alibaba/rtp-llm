
#include <deep_gemm/impls/sm100_fp8_fp4_mega_moe_situ.cuh>

using namespace deep_gemm;

static void __instantiate_kernel() {
    auto ptr = reinterpret_cast<void*>(&sm100_fp8_fp4_mega_moe_situ_impl<
        9600,
        3584, 3072,
        896, 0,
        16, 240, 128,
        128,
        40, 256,
        128,
        528000,
        8448000,
        5,
        3584,
        128, 128, 256,
        148, 8,
        0x1p+2f,
        0x1.9p+4f,
        true,
        cutlass::detail::float_e2m1_unpacksmem_t
    >);
};
