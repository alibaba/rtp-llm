#include "rtp_llm/cpp/cache/block_tree_cache/load/BlockTreeLoader.h"

#include <algorithm>
#include <cassert>
#include <chrono>
#include <exception>
#include <limits>
#include <numeric>
#include <unordered_set>
#include <utility>

#include "rtp_llm/cpp/cache/block_tree_cache/BlockTreeTaskPool.h"
#include "rtp_llm/cpp/cache/block_tree_cache/ScopeRollback.h"
#include "rtp_llm/cpp/cache/block_tree_cache/transfer/BlockTransferDispatcher.h"
#include "rtp_llm/cpp/utils/AssertUtils.h"
#include "rtp_llm/cpp/utils/Logger.h"
#include "rtp_llm/cpp/utils/TimeUtil.h"

namespace rtp_llm {

PinnedLocalFallback::~PinnedLocalFallback() {
    if (!transferred_to_request) {
        for (const auto& resource : resources) {
            group_sets[resource.group_set_id]->unreferenceBlocks(resource);
        }
    }
}

BlockTreeLoader::BlockTreeLoader(BlockTree*                      tree,
                                 BlockTreeEvictor&               evictor,
                                 BlockTransferDispatcher*        transfer_dispatcher,
                                 BlockTreeTaskPool*              task_pool,
                                 BlockTreeCacheMetricsReporter&  metrics_reporter,
                                 std::mutex&                     mutex,
                                 int                             disk_timeout_ms,
                                 int                             host_timeout_ms,
                                 bool                            enable_device_cache,
                                 std::shared_ptr<StorageBackend> storage_backend,
                                 SettledFn                       settled):
    tree_(tree),
    evictor_(evictor),
    transfer_dispatcher_(transfer_dispatcher),
    task_pool_(task_pool),
    metrics_reporter_(metrics_reporter),
    mutex_(mutex),
    enable_device_cache_(enable_device_cache),
    storage_backend_(std::move(storage_backend)),
    settled_(std::move(settled)),
    load_task_runner_(tree_->groupSets(), host_timeout_ms, disk_timeout_ms),
    load_join_registry_(tree),
    load_context_coordinator_(std::make_shared<LoadContextCoordinator>(
        [this](const std::shared_ptr<LoadAsyncContext>& context) { return commitLoad(context); },
        [this](LoadAsyncContext& context) {
            std::lock_guard<std::mutex> lock(mutex_);
            abortLoadLocked(
                context.loadDescs(), context.joinedLoads(), 0, context.contextId(), /*release_transferred_refs=*/false);
        })) {}

BlockTreeMatchResult BlockTreeLoader::matchLocked(const CacheKeysType& cache_keys,
                                                   const std::function<bool(size_t)>& valid_prefix,
                                                   const PartialTailMatchRequest* partial_tail) {
    std::optional<BlockTreeMatchResult> local;
    std::optional<PrefixCachePlanPoint> farthest_fork;
    std::vector<BlockTreeContentRange> ranges;
    if (partial_tail != nullptr && partial_tail->tokens != nullptr && partial_tail->endpoint_key
        && partial_tail->valid_endpoint) {
        ranges = tree_->contentMatchRanges(
            *partial_tail->tokens, partial_tail->endpoint_key, partial_tail->source_identity, &farthest_fork);
        local = preciseLocalMatchLocked(*partial_tail, ranges);
        if (local.has_value() && storage_backend_ && !local->short_leaf
            && local->matched_device_endpoint < partial_tail->remote_ceiling) {
            // Complete local candidates keep the established local+remote
            // path, including its ready prefix and lower-tier load sources.
            for (const auto& resource : local->matched_device_resources) {
                tree_->groupSets()[resource.group_set_id]->unreferenceBlocks(resource);
            }
            local.reset();
        }
        if (local.has_value() && (!storage_backend_ || local->matched_device_endpoint >= partial_tail->remote_ceiling)) {
            local->farthest_fork = farthest_fork;
            return std::move(*local);
        }
    }
    if (cache_keys.empty()) {
        if (local.has_value()) {
            local->farthest_fork = farthest_fork;
            return std::move(*local);
        }
        RTP_LLM_LOG_DEBUG("empty cache_keys, returning empty result");
        BlockTreeMatchResult result;
        result.farthest_fork = farthest_fork;
        return result;
    }

    // A farther complete-key backend candidate competes with the pinned local
    // short leaf as a whole. Starting a HOST/DISK load for the older local path
    // would make a later remote miss inherit its pending source references and
    // could splice those groups into the short leaf. Query complete keys from
    // an empty local path instead; a remote hit loads complete groups normally.
    std::vector<TreeNode*> path = local.has_value() ? std::vector<TreeNode*>{} : tree_->findNode(cache_keys);
    // A short leaf is reusable only after the exact-token, joint-group check
    // above. The legacy validator counts each node as a full physical block;
    // feeding it a short leaf could revive a candidate whose real SWA window
    // crosses a missing ancestor.
    if (!path.empty() && tree_->isShortLeaf(path.back())) {
        path.pop_back();
    }
    BlockTreeMatchResult   result = createMatchResult(path, cache_keys, valid_prefix);
    if (local.has_value()) {
        if (result.async_context != nullptr && result.async_context->needBackendMatch()
            && local->matched_device_endpoint > result.matched_device_endpoint) {
            auto fallback = std::make_shared<PinnedLocalFallback>();
            fallback->endpoint           = local->matched_device_endpoint;
            fallback->path_nodes         = local->matched_device_blocks;
            fallback->group_sets         = tree_->groupSets();
            fallback->resources          = std::move(local->matched_device_resources);
            fallback->resource_endpoints = std::move(local->precise_resource_endpoints);
            result.async_context->setLocalFallback(fallback->endpoint, partial_tail->reuse_unit_tokens);
            result.local_fallback = std::move(fallback);
        } else if (result.async_context == nullptr && local->matched_device_endpoint > result.matched_device_endpoint) {
            for (const auto& resource : result.matched_device_resources) {
                tree_->groupSets()[resource.group_set_id]->unreferenceBlocks(resource);
            }
            local->farthest_fork = farthest_fork;
            return std::move(*local);
        } else {
            for (const auto& resource : local->matched_device_resources) {
                tree_->groupSets()[resource.group_set_id]->unreferenceBlocks(resource);
            }
        }
    }
    RTP_LLM_LOG_DEBUG("matched %zu device blocks, cache_keys=%zu, tree_nodes=%zu",
                      result.matched_device_blocks,
                      cache_keys.size(),
                      tree_->size());
    result.farthest_fork = farthest_fork;
    return result;
}

std::optional<BlockTreeMatchResult> BlockTreeLoader::preciseLocalMatchLocked(
    const PartialTailMatchRequest& request, const std::vector<BlockTreeContentRange>& ranges) {
    std::vector<size_t> endpoints;
    std::vector<size_t> boundary_strides{1};
    size_t              joint_boundary = 1;
    for (const auto& group : tree_->groupSets()) {
        if (!group->localOnly() || group->groupType() != CacheGroupType::SWA) {
            continue;
        }
        const int window = group->group(group->groupTags().front()).policy.sliding_window_size;
        if (window <= 0) {
            continue;
        }
        const size_t stride = static_cast<size_t>(window);
        boundary_strides.push_back(stride);
        const size_t factor = stride / std::gcd(joint_boundary, stride);
        joint_boundary      = joint_boundary > std::numeric_limits<size_t>::max() / factor ?
                                  std::numeric_limits<size_t>::max() :
                                  joint_boundary * factor;
    }
    // With several zero-demand groups, the last jointly empty compression
    // boundary may precede every group's individual last boundary.
    boundary_strides.push_back(joint_boundary);
    std::sort(boundary_strides.begin(), boundary_strides.end());
    boundary_strides.erase(std::unique(boundary_strides.begin(), boundary_strides.end()), boundary_strides.end());
    for (const auto& range : ranges) {
        for (const size_t stride : boundary_strides) {
            size_t endpoint = std::min(range.matched_end, request.tokens->size() - 1);
            endpoint -= endpoint % stride;
            while (endpoint > 0 && request.preceding_valid_endpoint) {
                const size_t legal = request.preceding_valid_endpoint(endpoint);
                if (legal >= endpoint) {
                    break;
                }
                endpoint = legal - legal % stride;
            }
            if (endpoint > 0 && endpoint <= range.matched_end && request.valid_endpoint(endpoint)) {
                endpoints.push_back(endpoint);
            }
        }
    }
    std::sort(endpoints.begin(), endpoints.end(), std::greater<size_t>());
    endpoints.erase(std::unique(endpoints.begin(), endpoints.end()), endpoints.end());
    for (const size_t endpoint : endpoints) {
        // Each group resolves the same G, but its physical data may come from
        // different matched siblings (e.g. FULL at 700, LINEAR state at 600).
        // A later recurrent state is never truncated to an earlier endpoint.
        BlockTreeMatchResult                      result;
        std::vector<std::pair<TreeNode*, size_t>> matched_nodes;
        bool                                      ready = true;
        for (size_t group_id = 0; group_id < tree_->groupSets().size(); ++group_id) {
            const auto sources = tree_->coveredDeviceGroupPath(ranges, endpoint, group_id);
            if (!sources) {
                ready = false;
                break;
            }
            if (sources->empty()) {
                continue;
            }
            MultiNodeResource   pinned{group_id, Tier::DEVICE};
            std::vector<size_t> source_endpoints;
            for (auto* source : *sources) {
                pinned.node_blocks.emplace_back(nullptr,
                                                source->group_set_resources[group_id].getBlocks(Tier::DEVICE));
                source_endpoints.push_back(source->token_end);
                matched_nodes.emplace_back(source, group_id);
            }
            result.matched_device_resources.push_back(std::move(pinned));
            result.precise_resource_endpoints.push_back(std::move(source_endpoints));
        }
        if (!ready) {
            continue;
        }
        // Descriptor construction above acquires no references. Failed joint
        // candidates therefore leave no partial holds behind.
        for (const auto& resource : result.matched_device_resources) {
            tree_->groupSets()[resource.group_set_id]->referenceBlocks(resource);
        }
        result.matched_device_blocks   = (endpoint + request.reuse_unit_tokens - 1) / request.reuse_unit_tokens;
        result.matched_device_endpoint = endpoint;
        result.precise_local           = true;
        result.short_leaf              = endpoint % request.reuse_unit_tokens != 0;
        evictor_.onMatchedResources(matched_nodes);
        return result;
    }
    return std::nullopt;
}

bool BlockTreeLoader::validMatch(std::vector<TreeNode*>& path,
                                  std::vector<bool>&       candidate_valid,
                                  const std::function<bool(size_t)>& valid_prefix) const {
    size_t valid_block_count = 0;
    candidate_valid.reserve(path.size());
    std::vector<std::unique_ptr<MatchValidator>> match_validators;
    match_validators.reserve(tree_->groupSets().size());
    for (const GroupSetPtr& group_set : tree_->groupSets()) {
        match_validators.push_back(group_set->createMatchValidator());
    }
    for (size_t i = 0; i < path.size(); ++i) {
        TreeNode* node             = path[i];
        bool      all_groups_valid = true;
        for (size_t group_set_id = 0; group_set_id < tree_->groupSets().size(); ++group_set_id) {
            bool is_group_valid = false;
            if (tree_->groupSets()[group_set_id]->localOnly()) {
                const std::vector<TreeNode*> prefix(path.begin(), path.begin() + static_cast<std::ptrdiff_t>(i + 1));
                is_group_valid = tree_->groupSets()[group_set_id]->hasDeviceCoverage(prefix, node->token_end);
            } else {
                is_group_valid = match_validators[group_set_id]->validate(node->group_set_resources[group_set_id]);
                // A local DEVICE candidate is usable only if the complete-key
                // endpoint satisfies the same retained-window contract as the
                // exact matcher. Lower-tier candidates remain valid here and
                // continue through the existing load/fallback paths.
                if (is_group_valid && node->group_set_resources[group_set_id].hasCompleteDeviceValue()) {
                    const std::vector<TreeNode*> prefix(path.begin(),
                                                        path.begin() + static_cast<std::ptrdiff_t>(i + 1));
                    is_group_valid = tree_->groupSets()[group_set_id]->hasDeviceCoverage(prefix, node->token_end);
                }
            }
            if (!is_group_valid) {
                all_groups_valid = false;
            }
        }
        all_groups_valid = all_groups_valid && (!valid_prefix || valid_prefix(i + 1));
        if (all_groups_valid) {
            valid_block_count = i + 1;
        }
        candidate_valid.push_back(all_groups_valid);
    }

    path.resize(valid_block_count);
    candidate_valid.resize(valid_block_count);
    return valid_block_count > 0;
}

BlockIndicesType BlockTreeLoader::matchedBlocksForGroup(std::string_view                      group_tag,
                                                        const std::vector<MultiNodeResource>& matched_resources) const {
    const ReusableGroupLocation* location = tree_->reusableGroupLocation(group_tag);
    if (location == nullptr) {
        return {};
    }
    for (const MultiNodeResource& resource : matched_resources) {
        if (resource.group_set_id != location->group_set_id) {
            continue;
        }
        BlockIndicesType blocks;
        blocks.reserve(resource.node_blocks.size());
        for (const auto& [_, node_blocks] : resource.node_blocks) {
            blocks.push_back(node_blocks[location->member_group_id]);
        }
        return blocks;
    }
    return {};
}

std::vector<BlockTreeCacheReuseTimeMetricsSnapshot> BlockTreeLoader::collectReuseTimeSnapshots(
    const std::vector<TreeNode*>& path, size_t matched_device_blocks, int64_t access_time_us) const {
    std::vector<BlockTreeCacheReuseTimeSample> reuse_time_samples;
    reuse_time_samples.reserve(path.size() * tree_->groupSets().size());
    for (size_t group_set_id = 0; group_set_id < tree_->groupSets().size(); ++group_set_id) {
        const GroupSetPtr& group_set = tree_->groupSets()[group_set_id];
        const size_t       ready_reuse_count =
            std::min(group_set->computeReuseBlockCount(matched_device_blocks), matched_device_blocks);
        for (size_t i = matched_device_blocks - ready_reuse_count; i < matched_device_blocks; ++i) {
            const GroupSetResource& resource       = path[i]->group_set_resources[group_set_id];
            const CandidateMeta&    candidate_meta = resource.candidate_meta;
            reuse_time_samples.push_back({Tier::DEVICE,
                                          group_set->groupType(),
                                          candidate_meta.insert_time_us,
                                          candidate_meta.last_access_time_us,
                                          access_time_us});
        }

        const size_t logical_reuse_count = std::min(group_set->computeReuseBlockCount(path.size()), path.size());
        for (size_t i = std::max(path.size() - logical_reuse_count, matched_device_blocks); i < path.size(); ++i) {
            const GroupSetResource& resource       = path[i]->group_set_resources[group_set_id];
            const CandidateMeta&    candidate_meta = resource.candidate_meta;
            reuse_time_samples.push_back({resource.getTopTier(),
                                          group_set->groupType(),
                                          candidate_meta.insert_time_us,
                                          candidate_meta.last_access_time_us,
                                          access_time_us});
        }
    }
    return metrics_reporter_.collectCacheReuseTimeMetrics(reuse_time_samples);
}

BlockTreeMatchResult BlockTreeLoader::createMatchResult(std::vector<TreeNode*>&            path,
                                                        const CacheKeysType&               cache_keys,
                                                        const std::function<bool(size_t)>& valid_prefix) {
    BlockTreeMatchResult result;
    std::vector<bool>    candidate_valid;
    if (!path.empty() && !validMatch(path, candidate_valid, valid_prefix) && !storage_backend_) {
        return result;
    }
    const int64_t access_time_us = currentTimeUs();

    for (size_t candidate_count = path.size(); candidate_count > 0; --candidate_count) {
        if (!candidate_valid[candidate_count - 1]) {
            continue;
        }
        bool all_groups_ready = true;
        for (size_t group_set_id = 0; group_set_id < tree_->groupSets().size(); ++group_set_id) {
            const GroupSetPtr& group_set = tree_->groupSets()[group_set_id];
            const std::vector<TreeNode*> prefix(path.begin(), path.begin() + static_cast<std::ptrdiff_t>(candidate_count));
            // Legacy complete keys and the exact matcher must agree on physical
            // coverage. A present block ID cannot repair a missing SWA slot in
            // the model's retained window. Lower-tier candidates still follow
            // the existing HOST/DISK/REMOTE load paths below.
            if (!group_set->hasDeviceCoverage(prefix, prefix.back()->token_end)) {
                all_groups_ready = false;
                break;
            }
        }
        if (all_groups_ready) {
            result.matched_device_blocks = candidate_count;
            result.matched_device_endpoint = path[candidate_count - 1]->token_end;
            break;
        }
    }

    result.reuse_time_metrics_snapshots = collectReuseTimeSnapshots(path, result.matched_device_blocks, access_time_us);
    std::vector<TransferDescriptor> pending_load_descs;
    std::vector<bool>               joined_loads;
    for (size_t group_set_id = 0; group_set_id < tree_->groupSets().size(); ++group_set_id) {
        const GroupSetPtr& group_set = tree_->groupSets()[group_set_id];
        const size_t       ready_reuse_count =
            std::min(group_set->computeReuseBlockCount(result.matched_device_blocks), result.matched_device_blocks);
        MultiNodeResource matched_device_resource{group_set_id, Tier::DEVICE};
        const std::vector<TreeNode*> matched_path(path.begin(),
                                                  path.begin() + static_cast<std::ptrdiff_t>(result.matched_device_blocks));
        const auto required = group_set->localOnly() && !matched_path.empty() ?
                                  group_set->requiredPathIndices(matched_path, matched_path.back()->token_end) :
                                  std::vector<size_t>{};
        const size_t start = group_set->localOnly() ? 0 : result.matched_device_blocks - ready_reuse_count;
        for (size_t i = start; i < result.matched_device_blocks; ++i) {
            if (group_set->localOnly() && std::find(required.begin(), required.end(), i) == required.end()) {
                continue;
            }
            const GroupSetResource& resource = path[i]->group_set_resources[group_set_id];
            matched_device_resource.node_blocks.emplace_back(
                group_set->localOnly() ? path[i] : nullptr, resource.getBlocks(Tier::DEVICE));
        }
        if (!matched_device_resource.node_blocks.empty()) {
            group_set->referenceBlocks(matched_device_resource);
            result.matched_device_resources.push_back(std::move(matched_device_resource));
        }

        const size_t logical_reuse_count = group_set->localOnly() ? 0 :
            std::min(group_set->computeReuseBlockCount(path.size()), path.size());
        for (size_t i = std::max(path.size() - logical_reuse_count, result.matched_device_blocks); i < path.size();
             ++i) {
            GroupSetResource&  resource    = path[i]->group_set_resources[group_set_id];
            const Tier         source_tier = resource.getTopTier();
            TreeNode* const    source_node = source_tier == Tier::DEVICE ? nullptr : path[i];
            TransferDescriptor desc{
                source_node, group_set_id, i, source_tier, Tier::DEVICE, resource.getBlocks(source_tier)};
            const bool is_joined = resource.transfer_state == GroupSetTransferState::LOADING;
            if (!is_joined) {
                const MultiNodeResource source_resource{group_set_id, source_tier, {{source_node, desc.source_blocks}}};
                if (source_tier == Tier::DEVICE) {
                    group_set->referenceBlocks(source_resource);
                } else {
                    group_set->referenceBlocks(source_resource, BlockTreeRefType::LOAD);
                    resource.transfer_state = GroupSetTransferState::LOAD_PENDING;
                    evictor_.suspendCandidate(path[i], group_set_id, source_tier);
                }
            }
            pending_load_descs.emplace_back(std::move(desc));
            joined_loads.push_back(is_joined);
        }
    }
    evictor_.onMatched(path);

    StorageRequest storage_request;
    if (storage_backend_ && path.size() < cache_keys.size()) {
        storage_request = makeStorageRequest(cache_keys, path.size());
    }
    const bool use_storage = !storage_request.empty();
    if (!pending_load_descs.empty() || use_storage) {
        result.async_context = load_context_coordinator_->create(pending_load_descs,
                                                                 joined_loads,
                                                                 path.size(),
                                                                 use_storage ? storage_backend_ : nullptr,
                                                                 std::move(storage_request));
        if (result.async_context == nullptr) {
            abortLoadLocked(pending_load_descs, joined_loads, 0, 0, /*release_transferred_refs=*/true);
        } else if (!load_join_registry_.join(result.async_context)
                   || !load_context_coordinator_->registerContext(result.async_context)) {
            abortLoadLocked(result.async_context->loadDescs(),
                            result.async_context->joinedLoads(),
                            0,
                            result.async_context->contextId(),
                            /*release_transferred_refs=*/true);
            result.async_context = nullptr;
        } else {
            const size_t join_dependency_count = static_cast<size_t>(std::count(
                result.async_context->joinedLoads().begin(), result.async_context->joinedLoads().end(), true));
            if (join_dependency_count != 0) {
                result.async_context->startJoinWait(currentTimeUs());
                metrics_reporter_.reportLoadJoin(join_dependency_count);
            }
        }
    }
    if (result.async_context) {
        result.async_context->setValidPrefix(valid_prefix);
    }
    return result;
}

StorageRequest BlockTreeLoader::makeStorageRequest(const CacheKeysType& cache_keys,
                                                   size_t               local_matched_blocks_num) const {
    StorageRequest request{std::make_shared<CacheKeysType>(cache_keys),
                           std::vector<std::vector<StorageBlockHandle>>(cache_keys.size()),
                           local_matched_blocks_num};
    for (auto& key_handles : request.handles) {
        for (const auto& group_set : tree_->groupSets()) {
            if (group_set->localOnly()) {
                continue;
            }
            for (const auto& tag : group_set->groupTags()) {
                key_handles.push_back({tag, NULL_BLOCK_IDX});
            }
        }
    }
    return request;
}

bool BlockTreeLoader::abortPendingLoad(const std::shared_ptr<AsyncContext>& context) {
    std::shared_ptr<LoadAsyncContext> load_context = std::dynamic_pointer_cast<LoadAsyncContext>(context);
    if (load_context == nullptr) {
        RTP_LLM_LOG_WARNING("context is not owned by BlockTreeCache");
        return false;
    }
    return load_context->abortPending();
}

void BlockTreeLoader::shutdown() {
    load_context_coordinator_->shutdown();
}

bool BlockTreeLoader::commitLoad(const std::shared_ptr<LoadAsyncContext>& context) {
    std::lock_guard<std::mutex>            lock(mutex_);
    const std::vector<TransferDescriptor>& load_descs          = context->loadDescs();
    const std::vector<bool>&               joined_loads        = context->joinedLoads();
    const uint64_t                         context_id          = context->contextId();
    size_t                                 prepared_desc_count = 0;
    block_tree_cache_detail::ScopeRollback rollback_guard(
        [this, &load_descs, &joined_loads, &prepared_desc_count, context_id]() {
            abortLoadLocked(load_descs,
                            joined_loads,
                            prepared_desc_count,
                            context_id,
                            /*release_transferred_refs=*/false);
        });

    for (size_t i = 0; i < load_descs.size(); ++i) {
        const auto& desc = load_descs[i];
        if (!joined_loads[i] && desc.node && desc.node->group_set_resources[desc.group_set_id].transfer_detached) {
            abortLoadLocked(load_descs, joined_loads, 0, context_id, false);
            rollback_guard.dismiss();
            context->setSettlementReadyCallback(
                [this](const auto& ready) { scheduleContextSettlement(nullptr, ready); });
            context->cancelUnsubmittedTransfers();
            return true;
        }
    }

    for (size_t desc_index = 0; desc_index < load_descs.size(); ++desc_index) {
        const TransferDescriptor& desc = load_descs[desc_index];
        if (desc.source_tier == Tier::DEVICE || joined_loads[desc_index]) {
            ++prepared_desc_count;
            continue;
        }
        if (!changeTransferState(
                desc.node, desc.group_set_id, GroupSetTransferState::LOAD_PENDING, GroupSetTransferState::LOADING)) {
            RTP_LLM_LOG_ERROR("committed load source is not LOAD_PENDING, group_set_id=%zu", desc.group_set_id);
            return false;
        }
        RTP_LLM_CHECK(load_join_registry_.start(desc.node, desc.group_set_id, desc.target_blocks, context));
        tree_->groupSets()[desc.group_set_id]->referenceBlocks(
            MultiNodeResource{desc.group_set_id, Tier::DEVICE, {{desc.node, desc.target_blocks}}},
            BlockTreeRefType::LOAD);
        ++prepared_desc_count;
    }

    LoadTaskRunner::TaskPtr task = load_task_runner_.createTask(context);
    context->setSettlementReadyCallback([this, task](const std::shared_ptr<LoadAsyncContext>& ready_context) {
        scheduleContextSettlement(task, ready_context);
    });
    if (task) {
        const int64_t queue_begin = currentTimeUs();
        auto          on_timeout  = [this, task, queue_begin]() {
            metrics_reporter_.reportQueueWaitMetric(false,
                                                    "business",
                                                    cacheTransferOperationName(CacheTransferOperation::LOAD),
                                                    Tier::NONE,
                                                    Tier::NONE,
                                                    currentTimeUs() - queue_begin);
            const size_t descriptor_count = task->load_descs.size();
            RTP_LLM_LOG_WARNING("load expired in business queue, descriptor_count=%zu", descriptor_count);
            if (!task->context->completeTransfers(descriptor_count, false)) {
                RTP_LLM_LOG_WARNING("failed to record expired load, descriptor_count=%zu", descriptor_count);
            }
        };
        const TransferTask& queue_task =
            task->disk_to_device_task.descriptors().empty() ? task->host_to_device_task : task->disk_to_device_task;
        if (queue_task.expired()) {
            on_timeout();
            rollback_guard.dismiss();
            return true;
        }
        const auto deadline = queue_task.deadline();
        if (!task_pool_->submit(
                BlockTreeTaskClass::LOAD,
                [this, task, queue_begin]() {
                    metrics_reporter_.reportQueueWaitMetric(false,
                                                            "business",
                                                            cacheTransferOperationName(CacheTransferOperation::LOAD),
                                                            Tier::NONE,
                                                            Tier::NONE,
                                                            currentTimeUs() - queue_begin);
                    runLoadTask(task);
                },
                deadline,
                std::move(on_timeout))) {
            return false;
        }
    }

    rollback_guard.dismiss();
    return true;
}

void BlockTreeLoader::abortLoadLocked(const std::vector<TransferDescriptor>& load_descs,
                                      const std::vector<bool>&               joined_loads,
                                      size_t                                 prepared_desc_count,
                                      uint64_t                               context_id,
                                      bool                                   release_transferred_refs) {
    bool                          device_refs_released = false;
    std::unordered_set<TreeNode*> detached_nodes;
    for (size_t desc_index = 0; desc_index < load_descs.size(); ++desc_index) {
        const TransferDescriptor& desc           = load_descs[desc_index];
        const bool                joined_load    = joined_loads[desc_index];
        const bool                fully_prepared = desc_index < prepared_desc_count;
        if (joined_load || (desc.source_tier != Tier::DEVICE && fully_prepared)) {
            const bool erased = load_join_registry_.eraseForContext(desc.node, desc.group_set_id, context_id);
            if (!erased) {
                if (joined_load) {
                    RTP_LLM_LOG_DEBUG("joined load context is no longer registered, group_set=%zu", desc.group_set_id);
                } else {
                    RTP_LLM_LOG_WARNING("failed to erase aborted load context, group_set=%zu", desc.group_set_id);
                }
            }
            if (!joined_load || release_transferred_refs) {
                const MultiNodeResource target_resource{
                    desc.group_set_id, Tier::DEVICE, {{desc.node, desc.target_blocks}}};
                if (joined_load) {
                    tree_->groupSets()[desc.group_set_id]->unreferenceBlocks(target_resource);
                } else {
                    tree_->groupSets()[desc.group_set_id]->unreferenceBlocks(target_resource, BlockTreeRefType::LOAD);
                }
            }
        }
        if (joined_load) {
            device_refs_released = device_refs_released || release_transferred_refs;
            continue;
        }

        MultiNodeResource resource{desc.group_set_id, desc.source_tier, {{desc.node, desc.source_blocks}}};
        if (desc.source_tier == Tier::DEVICE) {
            if (release_transferred_refs) {
                tree_->groupSets()[desc.group_set_id]->unreferenceBlocks(resource);
                device_refs_released = true;
            }
            continue;
        }
        tree_->groupSets()[desc.group_set_id]->unreferenceBlocks(resource, BlockTreeRefType::LOAD);
        if (desc.node->group_set_resources[desc.group_set_id].transfer_detached) {
            evictor_.discardDetachedTransfer({desc});
            detached_nodes.insert(desc.node);
            continue;
        }
        const GroupSetTransferState expected_state =
            fully_prepared ? GroupSetTransferState::LOADING : GroupSetTransferState::LOAD_PENDING;
        if (!changeTransferState(desc.node, desc.group_set_id, expected_state, GroupSetTransferState::IDLE)) {
            RTP_LLM_LOG_WARNING(
                "load rollback state mismatch, group_set=%zu source=%s", desc.group_set_id, tierName(desc.source_tier));
        } else {
            evictor_.admitCandidate(desc.node, desc.group_set_id, desc.source_tier);
        }
    }
    tree_->removePendingNodes(detached_nodes);
    if (device_refs_released) {
        settled_(true);
    }
}

void BlockTreeLoader::runLoadTask(const LoadTaskRunner::TaskPtr& task) {
    const auto complete = [task](ErrorInfo error) {
        const size_t descriptor_count = task->load_descs.size();
        if (!task->context->completeTransfers(descriptor_count, error.ok())) {
            RTP_LLM_LOG_WARNING("failed to record load copy completion, descriptor_count=%zu", descriptor_count);
        }
    };
    try {
        load_task_runner_.runTransfer(task, *transfer_dispatcher_, metrics_reporter_, complete);
    } catch (const std::exception& error) {
        RTP_LLM_LOG_ERROR("load task runner failed with exception: %s", error.what());
        complete(ErrorInfo(ErrorCode::EXECUTION_EXCEPTION, error.what()));
    } catch (...) {
        RTP_LLM_LOG_ERROR("load task runner failed with unknown exception");
        complete(ErrorInfo(ErrorCode::EXECUTION_EXCEPTION, "unknown load task runner exception"));
    }
}

void BlockTreeLoader::scheduleContextSettlement(const LoadTaskRunner::TaskPtr&           task,
                                                const std::shared_ptr<LoadAsyncContext>& context) {
    auto settle = [this, task, context]() {
        bool                                           settlement_success = context->aggregateSuccess();
        std::vector<std::shared_ptr<LoadAsyncContext>> joined_contexts;
        if (task) {
            {
                std::lock_guard<std::mutex> lock(mutex_);
                settlement_success = settleLoadLocked(*task, settlement_success, joined_contexts);
            }
            for (const std::shared_ptr<LoadAsyncContext>& joined_context : joined_contexts) {
                bool    join_completed       = false;
                int64_t join_wait_latency_us = 0;
                if (!joined_context->completeJoinedOne(settlement_success, join_completed, join_wait_latency_us)) {
                    RTP_LLM_LOG_WARNING("failed to complete joined load context");
                } else if (join_completed) {
                    metrics_reporter_.reportLoadJoinWait(join_wait_latency_us);
                }
            }
        }
        if (!context->settle(settlement_success)) {
            RTP_LLM_LOG_WARNING("failed to publish load context settlement, context_id=%lu", context->contextId());
        }
    };
    const int64_t queue_begin = currentTimeUs();
    if (!task_pool_->submitCompletion([this, settle, queue_begin]() mutable {
            metrics_reporter_.reportQueueWaitMetric(true,
                                                    "business",
                                                    cacheTransferOperationName(CacheTransferOperation::LOAD),
                                                    Tier::NONE,
                                                    Tier::NONE,
                                                    currentTimeUs() - queue_begin);
            settle();
        })) {
        RTP_LLM_LOG_WARNING("load completion queue is closed; settling context inline");
        settle();
    }
}

bool BlockTreeLoader::validateLoadTaskLocked(const LoadTaskRunner::Task& task) const {
    bool valid = true;
    for (const TransferDescriptor& desc : task.load_descs) {
        const GroupSetResource& resource = desc.node->group_set_resources[desc.group_set_id];
        if (resource.transfer_detached) {
            RTP_LLM_LOG_WARNING("load transfer detached before completion, group_set=%zu", desc.group_set_id);
            valid = false;
            continue;
        }
        if (resource.transfer_state != GroupSetTransferState::LOADING) {
            RTP_LLM_LOG_ERROR("load state mismatch during settlement, group_set_id=%zu", desc.group_set_id);
            valid = false;
        }
    }
    return valid;
}

bool BlockTreeLoader::settleLoadLocked(LoadTaskRunner::Task&                           task,
                                       bool                                            aggregate_success,
                                       std::vector<std::shared_ptr<LoadAsyncContext>>& joined_contexts) {
    std::vector<BlockTreeEvictor::InvalidationSource> corrupted;
    const auto collect_corrupted = [this, &corrupted](const TransferTask& transfer, const TransferResult& result) {
        for (size_t index = 0; index < result.block_errors.size(); ++index) {
            const auto& desc = transfer.descriptors()[index];
            if (result.block_errors[index] != CacheCopyError::CRC_MISMATCH
                || desc.node->group_set_resources[desc.group_set_id].transfer_detached) {
                continue;
            }
            CacheKeysType cache_keys;
            for (TreeNode* node = desc.node; node != tree_->root(); node = node->parent) {
                cache_keys.push_back(node->cache_key);
            }
            std::reverse(cache_keys.begin(), cache_keys.end());
            corrupted.push_back({std::move(cache_keys), desc.group_set_id, desc.source_tier});
        }
    };
    // Capture both tiers before resource settlement or a cascading drop can destroy a source node.
    collect_corrupted(task.host_to_device_task, task.host_result);
    collect_corrupted(task.disk_to_device_task, task.disk_result);

    const bool                    settlement_success = aggregate_success && validateLoadTaskLocked(task);
    bool                          state_settled      = false;
    std::unordered_set<TreeNode*> detached_nodes;

    const auto& descriptors = task.load_descs;
    for (size_t desc_index = 0; desc_index < descriptors.size(); ++desc_index) {
        const TransferDescriptor& desc      = descriptors[desc_index];
        const GroupSetPtr&        group_set = tree_->groupSets()[desc.group_set_id];
        MultiNodeResource source_protection{desc.group_set_id, desc.source_tier, {{desc.node, desc.source_blocks}}};
        group_set->unreferenceBlocks(source_protection, BlockTreeRefType::LOAD);

        GroupSetResource& resource = desc.node->group_set_resources[desc.group_set_id];
        if (resource.transfer_detached) {
            evictor_.discardDetachedTransfer({desc});
            detached_nodes.insert(desc.node);
            state_settled     = true;
            continue;
        }
        if (settlement_success) {
            if (enable_device_cache_) {
                MultiNodeResource target_holder{desc.group_set_id, Tier::DEVICE, {{desc.node, desc.target_blocks}}};
                resource.setBlocks(Tier::DEVICE, desc.target_blocks);
                group_set->referenceBlocks(target_holder, BlockTreeRefType::CACHE);
                group_set->unreferenceBlocks(target_holder, BlockTreeRefType::LOAD);
                group_set->unreferenceBlocks(source_protection, BlockTreeRefType::CACHE);
                resource.evictFromTier(desc.source_tier);
                task.target_installed[desc_index] = true;
            }
            const bool state_changed = changeTransferState(
                desc.node, desc.group_set_id, GroupSetTransferState::LOADING, GroupSetTransferState::IDLE);
            assert(state_changed);
            (void)state_changed;
            state_settled = true;
            if (enable_device_cache_) {
                evictor_.onLoaded(desc.node, desc.group_set_id);
            } else {
                evictor_.admitCandidate(desc.node, desc.group_set_id, desc.source_tier);
            }
            continue;
        }

        // Ordinary copy failures still retain a reusable source.
        if (!changeTransferState(
                desc.node, desc.group_set_id, GroupSetTransferState::LOADING, GroupSetTransferState::IDLE)) {
            RTP_LLM_LOG_WARNING(
                "loading state mismatch, group_set=%zu source=%s", desc.group_set_id, tierName(desc.source_tier));
        } else {
            evictor_.admitCandidate(desc.node, desc.group_set_id, desc.source_tier);
            state_settled = true;
        }
    }
    load_task_runner_.releaseTaskResources(task);
    for (const TransferDescriptor& desc : task.load_descs) {
        if (!load_join_registry_.finish(desc.node, desc.group_set_id, joined_contexts)) {
            RTP_LLM_LOG_WARNING("failed to finish loading record, group_set=%zu", desc.group_set_id);
        }
    }
    tree_->removePendingNodes(detached_nodes);
    evictor_.invalidateSources(corrupted);
    settled_(state_settled);
    return settlement_success;
}

bool BlockTreeLoader::changeTransferState(TreeNode*             node,
                                          size_t                group_set_id,
                                          GroupSetTransferState expected_state,
                                          GroupSetTransferState target_state) {
    GroupSetResource& resource = node->group_set_resources[group_set_id];
    if (resource.transfer_state != expected_state) {
        return false;
    }
    resource.transfer_state = target_state;
    tree_->refreshPublishedState(node);
    return true;
}

}  // namespace rtp_llm
