#include "rtp_llm/cpp/engine_base/stream/StreamCacheResource.h"
#include "rtp_llm/cpp/engine_base/stream/GenerateStream.h"
#include "rtp_llm/cpp/utils/AssertUtils.h"
#include "rtp_llm/cpp/utils/ProfilingScope.h"
#include "rtp_llm/cpp/utils/TimeUtil.h"
#include "rtp_llm/cpp/cache/AsyncContext.h"
#include "rtp_llm/cpp/cache/CacheTopology.h"
#include "rtp_llm/cpp/cache/MHAKVCacheSpec.h"
#include "rtp_llm/cpp/cache/Types.h"
#include "rtp_llm/cpp/cache/KVCacheHashUtil.h"
#include "rtp_llm/cpp/cache/block_tree_cache/load/LoadAsyncContext.h"
#include "rtp_llm/cpp/config/RoleTypes.h"
#include "rtp_llm/cpp/engine_base/stream/CompleteTokenIds.h"
#include "rtp_llm/cpp/metrics/RtpLLMMetrics.h"
#include <algorithm>
#include <limits>
#include <thread>
#include <unordered_map>

using namespace std;

namespace rtp_llm {

namespace {

std::shared_ptr<const CacheTopology> warmupCacheTopology() {
    static const auto topology = []() {
        constexpr auto kWarmupCacheTag  = "__warmup__";
        auto           spec             = std::make_shared<MHAKVCacheSpec>();
        spec->tag                       = kWarmupCacheTag;
        spec->seq_size_per_block        = 1;
        spec->kernel_seq_size_per_block = 1;

        GroupBase group;
        group.tag    = kWarmupCacheTag;
        group.spec   = std::move(spec);
        group.policy = defaultCacheGroupPolicy(CacheGroupType::FULL);
        return CacheTopology::create({std::move(group)}, {{0, {kWarmupCacheTag}}});
    }();
    return topology;
}

std::shared_ptr<const MallocInfo::RequestLayout> makeRequestTokenSnapshot(const BatchKVCacheResource& resource,
                                                                          CompleteTokenIds&           tokens,
                                                                          int  incr_seq_len_override,
                                                                          bool capture_theory_keys,
                                                                          bool capture_tokens,
                                                                          bool partial_tail_reuse = false) {
    auto snapshot                    = std::make_shared<MallocInfo::RequestLayout>();
    snapshot->match_keys             = resource.cacheKeys(0);
    snapshot->request_seq_len        = tokens.seqLength();
    snapshot->request_incr_seq_len   = incr_seq_len_override >= 0 ? incr_seq_len_override : tokens.seqLength();
    snapshot->request_common_seq_len = tokens.commonSeqLength();
    snapshot->request_total_seq_len  = tokens.totalSeqLength();
    snapshot->request_reserve_step   = tokens.getReserveStep();
    snapshot->partial_tail_reuse     = partial_tail_reuse;
    snapshot->original_input_tokens  = partial_tail_reuse ? static_cast<size_t>(tokens.seqLength()) : 0;
    if (capture_tokens) {
        snapshot->token_ids = tokens.completeTokenIdsVec(0);
        if (partial_tail_reuse) {
            snapshot->token_ids.resize(snapshot->original_input_tokens);
        }
    }
    if (capture_theory_keys) {
        std::vector<CacheKeysType> keys_by_batch;
        keys_by_batch.reserve(resource.batchSize());
        for (int batch = 0; batch < resource.batchSize(); ++batch) {
            auto batch_keys = resource.cacheKeys(batch);
            if (!resource.lastBlockAligned() && !batch_keys.empty()) {
                batch_keys.pop_back();
            }
            keys_by_batch.push_back(std::move(batch_keys));
        }
        snapshot->theory_window_keys = std::move(keys_by_batch);
    }
    return snapshot;
}

}  // namespace

void StreamCacheResource::init(int batch_size) {
    batch_kv_cache_resource_->resetBatchSize(batch_size);
    // cache manager is null when warmup
    const auto topology = resource_context_.cache_manager ?
                              resource_context_.cache_manager->cacheConfig().topologyPtr() :
                              warmupCacheTopology();
    batch_kv_cache_resource_->initGroups(topology);
    resource_released_ = false;
    prefix_cache_registration_.reset();
}

void StreamCacheResource::prepareRegisteredSave() {
    if (!prefix_cache_registration_ || resource_released_ || !partialTailReuseEnabled()) {
        return;
    }
    const size_t resume_endpoint = static_cast<size_t>(std::max(0, stream_->initialReuseLength()));
    resource_context_.cache_manager->prepareRegisteredSave(
        *prefix_cache_registration_, *batch_kv_cache_resource_, resume_endpoint, stream_->completeTokenIdsPtr().get());
}

absl::Status StreamCacheResource::prepareRequiredContinuation() {
    if (!prefix_cache_registration_ || resource_released_ || !partialTailReuseEnabled()) {
        return absl::OkStatus();
    }
    const size_t resume_endpoint = static_cast<size_t>(std::max(0, stream_->initialReuseLength()));
    const auto status = resource_context_.cache_manager->prepareRequiredContinuation(
        *prefix_cache_registration_, *batch_kv_cache_resource_, resume_endpoint);
    if (status == MallocStatus::NONE) {
        return absl::OkStatus();
    }
    if (status == MallocStatus::PERMANENT_RESOURCE_EXHAUSTED) {
        return absl::ResourceExhaustedError("request continuation exceeds usable kv cache capacity");
    }
    return absl::UnavailableError("kv cache continuation is temporarily unavailable");
}

const std::vector<TaggedBlockIdPair>& StreamCacheResource::registeredSaveCopyMapping() const {
    static const std::vector<TaggedBlockIdPair> empty;
    return prefix_cache_registration_ ? prefix_cache_registration_->copy_mappings : empty;
}

void StreamCacheResource::completeRegisteredSave(size_t completed_endpoint) {
    if (!prefix_cache_registration_ || !prefix_cache_registration_->prepared) {
        return;
    }
    bool any_completed = prefix_cache_registration_->content_completed;
    for (auto& point : prefix_cache_registration_->points) {
        if (point.endpoint.pos > completed_endpoint) {
            continue;
        }
        for (auto& binding : point.group_bindings) {
            if (binding.state == PrefixCacheSaveState::REGISTERED
                && binding.resource.hasCompleteDeviceValue()) {
                binding.state = PrefixCacheSaveState::CONTENT_COMPLETE;
                any_completed = true;
            }
        }
    }
    // T05 calls this only after every rank has completed its copies and writer.
    // Keeping source pins until request release would let completed optional
    // history compete with mandatory fallback runtime allocation.
    resource_context_.cache_manager->releaseRegisteredSourcePins(*prefix_cache_registration_);
    prefix_cache_registration_->copy_mappings.clear();
    prefix_cache_registration_->content_completed = any_completed;
}

bool StreamCacheResource::copyChunkKernelBlocks(int batch, const std::string& tag, int32_t* dst) const {
    if (!stream_->useChunkWindow() || stream_->isFakeStream()) {
        return false;
    }
    const auto& context = resource_context_;
    const auto& group   = context.cache_manager->cacheConfig().group(tag);
    const auto  tail    = static_cast<size_t>(stream_->seqLength() - 1) / group.seqSizePerBlock();
    const auto& ids     = batch_kv_cache_resource_->cacheResource(batch).blockIds(tag);
    if (group.policy.shared_chunk_state) {
        // HCA has no overlap. Aligned chunks start a new 128-token compression interval.
        RTP_LLM_CHECK_WITH_INFO(stream_->seqSizePerBlock() % 128 == 0 && stream_->prefixLength() % 128 == 0
                                    && group.seqSizePerBlock() % 128 == 0,
                                "shared HCA state requires compression-aligned chunks");
        // Completed intervals use this forward's raw KV; only the tail needs persistent state.
        const auto chunk_tail =
            static_cast<size_t>(stream_->prefixLength() + stream_->currentChunkLen() - 1) / group.seqSizePerBlock();
        ids.copySharedKernelBlocks(tail, chunk_tail, dst);
        return true;
    }
    const bool reuse = reuseCache();
    const auto banks =
        group.chunkCacheBlockCount(stream_->seqLength(), stream_->maxChunkSize(), reuse, stream_->reserveStep());
    if (banks == 0) {
        return false;
    }
    RTP_LLM_CHECK_WITH_INFO(
        stream_->prefixLength() % group.seqSizePerBlock() == 0 && stream_->currentChunkLen() <= stream_->maxChunkSize()
            && (!stream_->isMiddleChunk()
                || (stream_->prefixLength() + stream_->currentChunkLen()) % group.seqSizePerBlock() == 0),
        "cyclic chunk cache requires aligned prefixes and bounded grants");
    ids.copyCyclicKernelBlocks(tail, banks, dst);
    return true;
}

void StreamCacheResource::releaseResource() {
    RTP_LLM_PROFILE_FUNCTION();
    if (!resource_context_.cache_manager) {
        return;
    }
    // Check against double release
    if (resource_released_) {
        RTP_LLM_LOG_ERROR("=== DOUBLE RELEASE CACHE RESOURCE DETECTED ===");
        RTP_LLM_LOG_ERROR("  stream_ ptr:                   %p", static_cast<void*>(stream_));
        RTP_LLM_LOG_ERROR("  stream alive (magic check):    %s",
                          stream_->isStreamAlive() ? "YES" : "NO (stream already destroyed!)");
        if (stream_->isStreamAlive()) {
            RTP_LLM_LOG_ERROR("  stream id:                     %s", stream_->streamLogTag().c_str());
            RTP_LLM_LOG_ERROR("  stream state:                  %s",
                              StreamStateToString(stream_->generate_status_->status).c_str());
            RTP_LLM_LOG_ERROR("  stream hasError:                %d", stream_->hasErrorWithoutLock());
            RTP_LLM_LOG_ERROR("  stream hasNumBeams:            %d", stream_->hasNumBeams());
        }
        RTP_LLM_LOG_ERROR("  batch_kv_cache_resource_ use_count: %ld", batch_kv_cache_resource_.use_count());
        RTP_LLM_LOG_ERROR("  curBlocksNum:                  %d", curBlocksNum());
        RTP_LLM_LOG_ERROR("  need_release_resource:         %d", need_release_resource_);
        RTP_LLM_LOG_ERROR("  fake_inited:                   %d", fake_inited_);
        RTP_LLM_LOG_ERROR("  batch_kv_cache_resource:       %s", batch_kv_cache_resource_->debugString().c_str());
        RTP_LLM_LOG_ERROR("  thread id:                     %lu",
                          std::hash<std::thread::id>{}(std::this_thread::get_id()));
        abort();
    }
    if (allocator_load_context_) {
        if (!resource_context_.cache_manager->abortPendingLoad(allocator_load_context_)) {
            RTP_LLM_LOG_DEBUG("allocator load was already committed or completed before release");
        }
        allocator_load_context_.reset();
    }
    // do not reuse cache from stopped beam search streams, whose states are likely corrupted
    if (!need_release_resource_ && (!stream_->hasNumBeams() || !stream_->hasErrorWithoutLock())) {
        return;
    }
    RTP_LLM_LOG_DEBUG("releaseResource: stream=%ld, curBlocksNum=%d, pd_kvcache_ref=%p",
                      stream_->streamId(),
                      curBlocksNum(),
                      pd_kvcache_ref_.get());
    tryReleaseKVBlock(curBlocksNum());
    batch_kv_cache_resource_->clearBlocks();
    resource_released_ = true;
}

int StreamCacheResource::tryReleaseKVBlock(size_t nums) {
    RTP_LLM_PROFILE_FUNCTION();
    RTP_LLM_LOG_DEBUG("stream [%s] try release [%lu] blocks", stream_->streamLogTag().c_str(), nums);

    if (fake_inited_) {
        int max_blocks_num = curBlocksNum();
        int batch_size     = batch_kv_cache_resource_->batchSize();
        batch_kv_cache_resource_->clearBlocks();
        batch_kv_cache_resource_->resetBatchSize(batch_size);
        fake_inited_ = false;
        return max_blocks_num;
    }

    // NOTE: Currently only support releasing all blocks
    // Partial release (shrink) is not supported yet
    int total_blocks = curBlocksNum();
    RTP_LLM_CHECK(nums == total_blocks);

    if (total_blocks > 0) {
        if (reuseCache() && !stream_->hasErrorWithoutLock() && stream_->getStatus() == StreamState::FINISHED) {
            const Tier target_tier = storeTarget();
            RTP_LLM_LOG_DEBUG("tryReleaseKVBlock: stream=%ld, storing cache, curBlocksNum=%d, target_tier=%s",
                              stream_->streamId(),
                              total_blocks,
                              tierName(target_tier));
            if (target_tier != Tier::NONE) {
                InsertInfo insert_info{batch_kv_cache_resource_, stream_->completeTokenIdsPtr(), false, target_tier};
                insert_info.prefix_cache_registration = prefix_cache_registration_ ? &*prefix_cache_registration_ :
                                                                                       nullptr;
                size_t     resident_prefix_length = 0;
                resource_context_.cache_manager->insertIntoCache(insert_info, resident_prefix_length);
            }
        } else {
            RTP_LLM_LOG_DEBUG("tryReleaseKVBlock: stream=%ld, NOT storing cache, reuseCache=%d, hasError=%d, status=%s",
                              stream_->streamId(),
                              reuseCache(),
                              stream_->hasErrorWithoutLock(),
                              StreamStateToString(stream_->getStatus()).c_str());
        }

        FreeInfo free_info{batch_kv_cache_resource_, stream_->completeTokenIdsPtr()};
        free_info.request_id = stream_->streamId();

        resource_context_.cache_manager->free(free_info);
    }

    if (prefix_cache_registration_) {
        resource_context_.cache_manager->releaseRegisteredSave(*prefix_cache_registration_);
    }

    return total_blocks;
}

// TODO, 等待删除。
int StreamCacheResource::singleBatchNeedBlocks(int seq_len, int reserve_step) const {
    return resource_context_.cache_manager->singleBatchNeedBlocks(batch_kv_cache_resource_, seq_len, reserve_step);
}

int StreamCacheResource::estimatePeakNeedBlocks(
    int seq_len, int common_seq_len, int remaining_tokens, int reserve_step, int target_batch_size) const {
    return resource_context_.cache_manager->estimatePeakNeedBlocks(batch_kv_cache_resource_,
                                                                   seq_len,
                                                                   common_seq_len,
                                                                   remaining_tokens,
                                                                   reserve_step,
                                                                   reuseCache(),
                                                                   target_batch_size);
}

void StreamCacheResource::publishReuseLengths(int total, int host, int disk, int backend) {
    stream_->setReuseLength(total);
    stream_->setMtpTokenIndex(total);
    stream_->setInitialReuseLength(total);
    stream_->setLocalReuseLength(total - backend);
    stream_->setRemoteReuseLength(backend);
    stream_->setHostReuseLength(host);
    stream_->setDiskReuseLength(disk);
}

// TODO(xinfei.sxf) 保证这个函数的原子性
absl::Status StreamCacheResource::initKVBlock() {
    RTP_LLM_PROFILE_FUNCTION();
    // Decode side: first malloc should NOT use device cache, regardless of runtime config.
    // Follow-up allocations (incrKVBlock) use enableCacheLookup().
    if (fake_inited_) {
        return absl::InternalError("fake inited not allow to incr block");
    }

    MallocInfo malloc_info;
    malloc_info.batch_kv_cache_resource = batch_kv_cache_resource_;
    malloc_info.complete_token_ids      = stream_->completeTokenIdsPtr();
    malloc_info.request_id              = stream_->streamId();
    malloc_info.verbose                 = malloc_failed_times_ >= 10 ? malloc_failed_times_ % 100 == 0 : true;

    const bool disable_first_malloc_reuse =
        resource_context_.cache_manager->cacheConfig().disable_decode_first_malloc_device_reuse;
    const bool is_decode_role  = (resource_context_.role_type == RoleType::DECODE);
    const bool is_first_malloc = (batch_kv_cache_resource_->curBlocksNum() == 0);

    if (disable_first_malloc_reuse && is_decode_role && is_first_malloc) {
        malloc_info.reuse_cache         = false;
        malloc_info.enable_cache_lookup = false;
    } else {
        malloc_info.reuse_cache         = reuseCache();
        malloc_info.enable_cache_lookup = enableCacheLookup();
    }
    malloc_info.enable_remove_skipped_blocks = false;
    malloc_info.max_chunk_tokens =
        stream_->chunkedPrefillEnabled() && stream_->isContextStream() ? stream_->maxChunkSize() : 0;
    malloc_info.malloc_begin_time_us         = currentTimeUs();
    if (is_first_malloc && !batch_kv_cache_resource_->cacheKeysInitialized()) {
        initCacheKeys(batch_kv_cache_resource_, malloc_info.complete_token_ids, seqSizePerBlock());
        malloc_info.cache_keys_initialized_now = true;
    } else if (!is_first_malloc) {
        updateCacheKeys(batch_kv_cache_resource_, malloc_info.complete_token_ids, seqSizePerBlock());
    }
    malloc_info.cache_keys_prepared = true;
    if (is_first_malloc && !prefix_cache_registration_ && partialTailReuseEnabled()) {
        PrefixCacheRegistration registration;
        registration.token_ids             = malloc_info.complete_token_ids->completeTokenIdsVec(0);
        registration.original_input_tokens = static_cast<size_t>(malloc_info.complete_token_ids->seqLength());
        RTP_LLM_CHECK_WITH_INFO(registration.token_ids.size() >= registration.original_input_tokens,
                                "missing original input tokens for partial tail registration");
        registration.token_ids.resize(registration.original_input_tokens);
        registration.base_keys = batch_kv_cache_resource_->cacheKeys(0);

        const size_t base_tokens = static_cast<size_t>(seqSizePerBlock());
        const size_t full_unit   = static_cast<size_t>(reuseBlockTokens());
        const auto&  cache_config = resource_context_.cache_manager->cacheConfig();
        const auto&  groups       = cache_config.topology().groups();
        const size_t checkpoint_step = static_cast<size_t>(std::max(1, cache_config.linear_step));
        RTP_LLM_CHECK_WITH_INFO(base_tokens > 0 && full_unit >= base_tokens && full_unit % base_tokens == 0,
                                "invalid full checkpoint unit for partial tail registration");
        for (size_t pos = full_unit; pos <= registration.original_input_tokens; pos += full_unit) {
            // Sparse group managers retain step hits plus their active tail.
            // Use each tag's canonical physical slot: in CP, that may differ
            // from both the base-key index and the global checkpoint ordinal.
            const size_t checkpoint_index = pos / full_unit - 1;
            const bool original_checkpoint = std::all_of(groups.begin(), groups.end(), [&](const GroupBase& group) {
                if (group.policy.group_type == CacheGroupType::FULL || !group.policy.enable_prefix_reuse) {
                    return true;
                }
                const size_t slot = cache_config.canonicalBlockPosition(group.tag, checkpoint_index);
                const size_t local_tokens =
                    static_cast<size_t>(cache_config.localAllocTokens(group.tag,
                                                                       static_cast<int>(registration.original_input_tokens)));
                const size_t seq_slots = (local_tokens + group.seqSizePerBlock() - 1) / group.seqSizePerBlock();
                const size_t active_tail = std::max<size_t>(1, group.policy.active_tail_blocks);
                return (slot + 1) % checkpoint_step == 0
                       || (slot < seq_slots && slot >= seq_slots - std::min(seq_slots, active_tail));
            });
            if (!original_checkpoint) {
                continue;
            }
            const size_t index = pos / base_tokens - 1;
            RTP_LLM_CHECK_WITH_INFO(index < registration.base_keys.size(), "missing full checkpoint key");
            registration.points.push_back({{index, registration.base_keys[index], pos}, {}});
        }
        if (resource_context_.enable_prefill_partial_tail_reuse && registration.original_input_tokens > 0
            && (registration.points.empty()
                || registration.points.back().endpoint.pos != registration.original_input_tokens)) {
            const size_t index = (registration.original_input_tokens - 1) / base_tokens;
            RTP_LLM_CHECK_WITH_INFO(index < registration.base_keys.size(), "missing tail checkpoint key");
            registration.points.push_back(
                {{index, registration.base_keys[index], registration.original_input_tokens}, {}});
        }
        for (auto& point : registration.points) {
            for (const auto& group_set : resource_context_.cache_manager->blockTreeCache()->groupSets()) {
                PrefixCacheGroupSaveBinding binding;
                binding.group_set_id = group_set->groupSetId();
                point.group_bindings.push_back(std::move(binding));
            }
        }
        prefix_cache_registration_ = std::move(registration);
    }
    malloc_info.request_layout =
        makeRequestTokenSnapshot(*batch_kv_cache_resource_,
                                 *malloc_info.complete_token_ids,
                                 -1,
                                 is_first_malloc && malloc_info.cache_keys_initialized_now
                                     && resource_context_.cache_manager->needsPrefillHitSnapshot(),
                                 (is_first_malloc && partialTailReuseEnabled()),
                                 is_first_malloc && partialTailReuseEnabled());

    MallocResult result = resource_context_.cache_manager->malloc(malloc_info);
    recordCacheReuseMallocResult(result);
    if (!result.success) {
        malloc_failed_times_++;
        switch (result.status) {
            case MallocStatus::RETRYABLE_RESOURCE_EXHAUSTED:
                return absl::UnavailableError("kv cache is temporarily unavailable");
            case MallocStatus::PERMANENT_RESOURCE_EXHAUSTED:
                return absl::ResourceExhaustedError("request exceeds usable kv cache capacity");
            case MallocStatus::INTERNAL_ERROR:
                return absl::InternalError("malloc failed");
            case MallocStatus::NONE:
                RTP_LLM_LOG_ERROR("malloc returned failure without an error status, request_id=%ld",
                                  malloc_info.request_id);
                return absl::InternalError("malloc failed without an error status");
        }
        RTP_LLM_LOG_ERROR("malloc returned failure with unknown status=%d, request_id=%ld",
                          static_cast<int>(result.status),
                          malloc_info.request_id);
        return absl::InternalError("malloc failed with unknown status");
    }

    if (is_first_malloc && prefix_cache_registration_ && resource_context_.enable_prefill_common_prefix_recovery
        && result.farthest_fork) {
        auto& registration = *prefix_cache_registration_;
        const auto& fork = *result.farthest_fork;
        // The original checkpoint can already own F. Keep the value for the
        // request summary even when no internal-only point is appended.
        registration.farthest_fork = fork;
        if (fork.pos > 0 && fork.pos < registration.original_input_tokens
            && fork.pos <= static_cast<size_t>(std::numeric_limits<int>::max())
            && malloc_info.complete_token_ids->isValidReuseLength(static_cast<int>(fork.pos), 0)
            && std::none_of(registration.points.begin(), registration.points.end(), [&](const auto& point) {
                   return point.endpoint.pos == fork.pos;
               })) {
            PrefixCacheRegistrationPoint point;
            point.endpoint = fork;
            point.internal_only = true;
            for (const auto& group_set : resource_context_.cache_manager->blockTreeCache()->groupSets()) {
                PrefixCacheGroupSaveBinding binding;
                binding.group_set_id = group_set->groupSetId();
                point.group_bindings.push_back(std::move(binding));
            }
            registration.points.push_back(std::move(point));
        }
    }

    // HOST/DISK reuse is published after the asynchronous load completes.
    publishReuseLengths(result.reuse_len, 0, 0, 0);
    allocator_load_context_ = std::move(result.async_context);
    return absl::OkStatus();
}

void StreamCacheResource::clearCacheReuseState() {
    stream_->setReuseLength(0);
    stream_->setMtpTokenIndex(0);
    stream_->setInitialReuseLength(0);
    stream_->setHostReuseLength(0);
    stream_->setDiskReuseLength(0);
    stream_->setLocalReuseLength(0);
    stream_->setRemoteReuseLength(0);
}

void StreamCacheResource::recordCacheReuseMallocResult(const MallocResult& result) {
    cache_reuse_metrics_.device_input_length    = result.device_input_length;
    cache_reuse_metrics_.match_cost_time_us     = result.match_cost_time_us;
    cache_reuse_metrics_.report_match_cost_time = result.match_end_time_us > 0;
    malloc_begin_time_us_                       = result.malloc_begin_time_us;
    cache_reuse_metrics_.load_attempted         = result.load_attempted;
    if (!result.load_attempted) {
        if (result.match_end_time_us > 0) {
            cache_reuse_metrics_.match_to_ready_latency_us =
                std::max<int64_t>(currentTimeUs() - malloc_begin_time_us_, 0);
            cache_reuse_metrics_.report_match_to_ready_latency = true;
        }
        return;
    }

    // Metrics describe the current load attempt. A retry must not inherit the
    // previous attempt's terminal result or latency.
    cache_reuse_metrics_.load_success                  = false;
    cache_reuse_metrics_.report_load_metrics           = false;
    cache_reuse_metrics_.report_load_wait_latency      = false;
    cache_reuse_metrics_.load_wait_latency_us          = 0;
    cache_reuse_metrics_.report_match_to_ready_latency = false;
    cache_reuse_metrics_.match_to_ready_latency_us     = 0;
    cache_reuse_metrics_.load_prepare_latency_us       = result.load_prepare_latency_us;
    load_wait_begin_time_us_                           = currentTimeUs();
    if (!result.success) {
        clearCacheReuseState();
        cache_reuse_metrics_.load_success              = false;
        cache_reuse_metrics_.report_load_metrics       = true;
        cache_reuse_metrics_.match_to_ready_latency_us = std::max<int64_t>(currentTimeUs() - malloc_begin_time_us_, 0);
        cache_reuse_metrics_.report_match_to_ready_latency = true;
    }
}

absl::Status StreamCacheResource::finalizeAllocatorLoad() {
    const bool load_success  = allocator_load_context_->success();
    const auto error         = allocator_load_context_->errorInfo();
    const auto load_context  = std::dynamic_pointer_cast<LoadAsyncContext>(allocator_load_context_);
    auto       malloc_status = load_context == nullptr ? MallocStatus::NONE : load_context->mallocStatus();
    if (load_success) {
        RTP_LLM_CHECK(load_context != nullptr);
        const size_t total = load_context->matchedBlocks();
        const size_t local = load_context->localMatchedBlocks();
        const size_t host  = load_context->matchedBlocks(Tier::HOST);
        const size_t disk  = load_context->matchedBlocks(Tier::DISK);
        RTP_LLM_CHECK_WITH_INFO(total >= local && host <= local && disk <= local - host,
                                "invalid allocator reuse counts: total=%zu local=%zu host=%zu disk=%zu",
                                total,
                                local,
                                host,
                                disk);
        const int tokens = reuseBlockTokens();
        const size_t exact_total = load_context->matchedTokenEndpoint(static_cast<size_t>(tokens));
        RTP_LLM_CHECK_WITH_INFO(tokens > 0 && exact_total <= static_cast<size_t>(std::numeric_limits<int>::max()),
                                "allocator reuse token count exceeds int range: blocks=%zu tokens=%d",
                                total,
                                tokens);
        const size_t backend  = total - local;
        auto&        resource = batch_kv_cache_resource_->cacheResource(0);
        // A remote miss can select a pinned local short leaf after the remote
        // query started from an empty path. In that case the context's legacy
        // block counts are zero, while its exact endpoint is the DEVICE reuse.
        const size_t device_blocks = load_context->localFallbackSelected() ? exact_total / static_cast<size_t>(tokens) :
                                                                           local - host - disk;
        resource.setDeviceReuseBlockNum(device_blocks);
        resource.setMemoryReuseBlockNum(host);
        resource.setDiskReuseBlockNum(disk);
        resource.setStorageBackendReuseBlockNum(backend);
        publishReuseLengths(static_cast<int>(exact_total), host * tokens, disk * tokens, backend * tokens);
    } else if (resource_context_.role_type == RoleType::PREFILL && malloc_status == MallocStatus::NONE) {
        stream_->setHostReuseLength(0);
        stream_->setDiskReuseLength(0);
        if (!resource_context_.cache_manager->detachSharedBlocksForRecompute(batch_kv_cache_resource_,
                                                                             stream_->reuseLength())) {
            // Re-enter admission with no request refs if detaching the writable
            // suffix cannot fit. Never compute into cache/other-request blocks.
            resource_context_.cache_manager->free({batch_kv_cache_resource_, stream_->completeTokenIdsPtr()});
            clearCacheReuseState();
            malloc_status = MallocStatus::RETRYABLE_RESOURCE_EXHAUSTED;
        }
    } else {
        clearCacheReuseState();
    }
    if (!cache_reuse_metrics_.report_load_metrics) {
        const int64_t load_end_time_us                = currentTimeUs();
        cache_reuse_metrics_.load_success             = load_success;
        cache_reuse_metrics_.report_load_metrics      = true;
        cache_reuse_metrics_.report_load_wait_latency = true;
        cache_reuse_metrics_.load_wait_latency_us = std::max<int64_t>(load_end_time_us - load_wait_begin_time_us_, 0);
        cache_reuse_metrics_.match_to_ready_latency_us = std::max<int64_t>(load_end_time_us - malloc_begin_time_us_, 0);
        cache_reuse_metrics_.report_match_to_ready_latency = true;
    }
    allocator_load_context_.reset();

    if (load_success) {
        return absl::OkStatus();
    }
    if (malloc_status == MallocStatus::RETRYABLE_RESOURCE_EXHAUSTED) {
        return absl::UnavailableError("allocator load materialization is temporarily out of KV blocks");
    }
    if (malloc_status == MallocStatus::PERMANENT_RESOURCE_EXHAUSTED) {
        return absl::ResourceExhaustedError("allocator load materialization exceeds KV cache capacity");
    }
    if (malloc_status == MallocStatus::INTERNAL_ERROR) {
        return absl::InternalError("allocator load materialization failed");
    }
    if (resource_context_.role_type == RoleType::PREFILL) {
        return absl::OkStatus();
    }
    const std::string error_text = error.ToString();
    return absl::InternalError(error_text.empty() ? "allocator load failed" : "allocator load failed: " + error_text);
}

void StreamCacheResource::reportCacheReuseMetrics() {
    if (stream_->metrics_reporter_ == nullptr || !reuseCache()) {
        return;
    }
    cache_reuse_metrics_.kv_cache_reuse_length            = stream_->initialReuseLength();
    cache_reuse_metrics_.stream_cache_device_reuse_length = stream_->deviceReuseLength();
    cache_reuse_metrics_.stream_cache_memory_reuse_length = stream_->hostReuseLength();
    cache_reuse_metrics_.stream_cache_disk_reuse_length   = stream_->diskReuseLength();
    cache_reuse_metrics_.stream_cache_remote_reuse_length = stream_->remoteReuseLength();
    cache_reuse_metrics_.report_reuse_metrics             = true;
    kmonitor::MetricsTags tags;
    stream_->metrics_reporter_->report<RtpLLMCacheReuseMetrics, RtpLLMCacheReuseMetricsCollector>(
        &tags, &cache_reuse_metrics_);
}

std::optional<absl::Status> StreamCacheResource::pollAllocatorLoad() {
    if (!allocator_load_context_) {
        return absl::OkStatus();
    }
    if (!allocator_load_context_->done()) {
        return std::nullopt;
    }
    return finalizeAllocatorLoad();
}

absl::Status StreamCacheResource::waitForAllocatorLoad() {
    if (!allocator_load_context_) {
        return absl::OkStatus();
    }
    allocator_load_context_->waitDone();
    if (!allocator_load_context_->done()) {
        return absl::InternalError("allocator load context is non-terminal after waitDone");
    }
    return finalizeAllocatorLoad();
}

absl::Status StreamCacheResource::incrKVBlock(int seq_len_override) {
    RTP_LLM_PROFILE_FUNCTION();
    // TODO(xinfei.sxf) add reserver_blocks
    if (fake_inited_) {
        return absl::InternalError("fake inited not allow to incr block");
    }

    MallocInfo malloc_info;
    malloc_info.batch_kv_cache_resource      = batch_kv_cache_resource_;
    malloc_info.complete_token_ids           = stream_->completeTokenIdsPtr();
    malloc_info.request_id                   = stream_->streamId();
    malloc_info.verbose                      = malloc_failed_times_ >= 10 ? malloc_failed_times_ % 100 == 0 : true;
    malloc_info.reuse_cache                  = reuseCache();
    malloc_info.enable_cache_lookup          = enableCacheLookup();
    malloc_info.enable_remove_skipped_blocks = !(stream_->chunkedPrefillEnabled() && stream_->isContextStream());
    malloc_info.incr_seq_len_override        = seq_len_override;
    malloc_info.malloc_begin_time_us         = currentTimeUs();
    const int initial_reuse = stream_->initialReuseLength();
    // partialTailReuseEnabled() becomes false after a PREFILL-role stream
    // leaves context mode; the registration still identifies this request.
    // DSV4 publishes original full checkpoints at every reuseBlockTokens()
    // boundary, so a nonaligned initial G identifies its added short leaf.
    // LINEAR checkpoint spacing is a separate integration contract.
    if (prefix_cache_registration_ && initial_reuse > 0 && initial_reuse % reuseBlockTokens() != 0) {
        malloc_info.precise_resume_endpoint = static_cast<size_t>(initial_reuse);
    }
    if (batch_kv_cache_resource_->curBlocksNum() == 0) {
        if (!batch_kv_cache_resource_->cacheKeysInitialized()) {
            initCacheKeys(batch_kv_cache_resource_, malloc_info.complete_token_ids, seqSizePerBlock());
            malloc_info.cache_keys_initialized_now = true;
        }
    } else {
        updateCacheKeys(batch_kv_cache_resource_, malloc_info.complete_token_ids, seqSizePerBlock());
    }
    malloc_info.cache_keys_prepared = true;
    malloc_info.request_layout =
        makeRequestTokenSnapshot(*batch_kv_cache_resource_,
                                 *malloc_info.complete_token_ids,
                                 seq_len_override,
                                 batch_kv_cache_resource_->curBlocksNum() == 0 && malloc_info.cache_keys_initialized_now
                                     && resource_context_.cache_manager->needsPrefillHitSnapshot(),
                                 false);

    auto result = resource_context_.cache_manager->malloc(malloc_info);
    if (!result.success && prefix_cache_registration_
        && resource_context_.cache_manager->relinquishOptionalRegisteredSave(*prefix_cache_registration_, true)) {
        // A newly appended F destination yields before original/N points.
        result = resource_context_.cache_manager->malloc(malloc_info);
    }
    if (!result.success && prefix_cache_registration_
        && resource_context_.cache_manager->relinquishOptionalRegisteredSave(*prefix_cache_registration_)) {
        // The original running allocation retains its status semantics; remaining
        // optional save blocks yield before declaring an incremental shortfall.
        result = resource_context_.cache_manager->malloc(malloc_info);
    }
    if (!result.success) {
        malloc_failed_times_++;
        return absl::InternalError("malloc failed");
    }

    if (result.reuse_len > 0) {
        publishReuseLengths(result.reuse_len, 0, 0, 0);
    }
    if (result.async_context) {
        const bool aborted = resource_context_.cache_manager->abortPendingLoad(result.async_context);
        if (!aborted) {
            RTP_LLM_LOG_DEBUG("incremental allocator load was already committed before rejection");
        }
        return absl::FailedPreconditionError("async incremental KV block allocation is unsupported");
    }

    return absl::OkStatus();
}

bool StreamCacheResource::asyncLoadCache() {
    RTP_LLM_PROFILE_FUNCTION();
    return allocator_load_context_ != nullptr;
}

bool StreamCacheResource::loadCacheDone() {
    if (allocator_load_context_) {
        if (!allocator_load_context_->done()) {
            return false;
        }
        const ErrorInfo error   = allocator_load_context_->errorInfo();
        const bool      success = allocator_load_context_->success();
        const auto      status  = finalizeAllocatorLoad();
        if (!success && !absl::IsUnavailable(status)) {
            RTP_LLM_LOG_WARNING(
                "block tree load failed, stream=%ld error=%s", stream_->streamId(), error.ToString().c_str());
        }
        if (absl::IsUnavailable(status)) {
            ++malloc_failed_times_;
            stream_->generate_status_->clearLoadInitiated();
            reportMallocRetry();
        } else if (!status.ok()) {
            stream_->reportEventWithoutLock(
                StreamEvents::Error, ErrorCode::MALLOC_FAILED, std::string(status.message()));
        }
    }
    return true;
}

// TODO, delete it soon
int StreamCacheResource::curBlocksNum() const {
    return batch_kv_cache_resource_->curBlocksNum();
}

bool StreamCacheResource::isContextStream() const {
    RTP_LLM_CHECK_WITH_INFO(stream_ != nullptr, "StreamCacheResource::isContextStream called with null stream");
    return stream_->isContextStream();
}

const BatchKVCacheResource& StreamCacheResource::kvCache() const {
    batch_kv_cache_resource_->check();
    return *batch_kv_cache_resource_;
}

BatchKVCacheResource& StreamCacheResource::kvCacheMutable() {
    batch_kv_cache_resource_->check();
    return *batch_kv_cache_resource_;
}

void StreamCacheResource::setKVCache(const BatchKVCacheResource& kv_cache_resource) {
    *batch_kv_cache_resource_ = kv_cache_resource;
}

bool StreamCacheResource::updateKVBlock(const std::vector<int>& block_src_batch, bool copy_last_block) {
    return resource_context_.cache_manager->updateKVBlock(
        batch_kv_cache_resource_, block_src_batch, copy_last_block, block_update_mapping_);
}

bool StreamCacheResource::hasCacheKeys() const {
    return batch_kv_cache_resource_->hasCacheKeys();
}

const CacheKeysType& StreamCacheResource::cacheKeys(int32_t batch_id) const {
    return batch_kv_cache_resource_->cacheKeys(batch_id);
}

void StreamCacheResource::fakeInitKVBlock(size_t reserved_blocks) {
    fake_inited_ = true;
    batch_kv_cache_resource_->resetBatchSize(stream_->maxBatchSize());
    const auto topology = resource_context_.cache_manager ?
                              resource_context_.cache_manager->cacheConfig().topologyPtr() :
                              warmupCacheTopology();
    batch_kv_cache_resource_->initGroups(topology);

    reserved_blocks = std::max(1ul, reserved_blocks);
    batch_kv_cache_resource_->resizeBlocks(reserved_blocks, 0);
}

int StreamCacheResource::mallocFailedTimes() const {
    return malloc_failed_times_;
}

void StreamCacheResource::reportMallocRetry() const {
    if (!stream_->metrics_reporter_) {
        return;
    }
    RtpLLMCacheOperationMetricsCollector collector;
    collector.operation_type = RtpLLMCacheOperationMetricsCollector::OpType::MALLOC_RETRY;
    stream_->metrics_reporter_->report<RtpLLMCacheOperationMetrics, RtpLLMCacheOperationMetricsCollector>(nullptr,
                                                                                                          &collector);
}

bool StreamCacheResource::reuseCache() const {
    // AND logic: global REUSE_CACHE=1 AND per-request reuse_cache both must be true.
    // Per-request field flows frontend → FlexLB → engine via protobuf.
    return !stream_->generateConfig()->isPrefillOnly() && resource_context_.reuse_cache
           && (resource_context_.ignore_request_cache_switches || stream_->reuseCache());
}

bool StreamCacheResource::partialTailReuseEnabled() const {
    if (!(resource_context_.enable_prefill_partial_tail_reuse || resource_context_.enable_prefill_common_prefix_recovery)
        || resource_context_.role_type != RoleType::PREFILL
        || !resource_context_.enable_device_cache || resource_context_.cache_manager == nullptr || !reuseCache()
        || resource_context_.cache_manager->blockTreeCache() == nullptr || !stream_->isContextStream()) {
        return false;
    }
#if !USING_CUDA
    // Precise LINEAR state snapshots are supported on NVIDIA CUDA in the first release.
    for (const auto& group : resource_context_.cache_manager->cacheConfig().topology().groups()) {
        if (group.policy.group_type == CacheGroupType::LINEAR) {
            return false;
        }
    }
#endif
    return true;
}

bool StreamCacheResource::enableMemoryCache() const {
    // Local tiers are deployment policy; request fields remain wire-compatible only.
    return resource_context_.enable_memory_cache;
}

bool StreamCacheResource::enableDeviceCache() const {
    return resource_context_.enable_device_cache;
}

bool StreamCacheResource::enableDiskCache() const {
    return resource_context_.enable_disk_cache;
}

bool StreamCacheResource::enableCacheLookup() const {
    const bool any_global_tier = resource_context_.enable_device_cache || resource_context_.enable_memory_cache
                                 || resource_context_.enable_disk_cache || resource_context_.enable_remote_cache;
    return reuseCache() && any_global_tier;
}

Tier StreamCacheResource::storeTarget() const {
    if (!reuseCache()) {
        return Tier::NONE;
    }
    if (enableDeviceCache()) {
        return Tier::DEVICE;
    }
    if (enableMemoryCache()) {
        return Tier::HOST;
    }
    if (enableDiskCache()) {
        return Tier::DISK;
    }
    return Tier::NONE;
}

void StreamCacheResource::swapLinearBlocks(int32_t batch_id, size_t rhs, size_t lhs) {
    if (rhs == lhs) {
        return;
    }

    for (const auto& group : resource_context_.cache_manager->cacheConfig().topology().groups()) {
        if (group.policy.group_type == CacheGroupType::LINEAR) {
            batch_kv_cache_resource_->swapBlocks(batch_id, group.tag, rhs, lhs);
        }
    }
}

void StreamCacheResource::holdKVCacheForPDSep() {
    auto&       resource   = batch_kv_cache_resource_->cacheResource(0);
    const auto& cache_keys = resource.cacheKeys();
    auto        ref = resource_context_.cache_manager->incrKVCacheRef(resource, cache_keys, /*is_connector=*/true);
    if (ref) {
        pd_kvcache_ref_ = std::move(ref);
    }
}

void StreamCacheResource::releaseKVCacheForPDSep() {
    pd_kvcache_ref_.reset();
}
}  // namespace rtp_llm
