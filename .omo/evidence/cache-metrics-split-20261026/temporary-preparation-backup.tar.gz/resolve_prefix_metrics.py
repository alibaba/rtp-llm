# /// script
# requires-python = ">=3.10"
# dependencies = []
# ///
# Run: python3 /tmp/resolve_prefix_metrics.py
from pathlib import Path
import re
root=Path('/tmp/cache-metrics-prefix-candidate')
keep_ours={'rtp_llm/cpp/cache/Types.h':{0}, 'rtp_llm/cpp/cache/block_tree_cache/BlockTree.cc':{1}, 'rtp_llm/cpp/cache/block_tree_cache/BlockTreeCache.cc':{2}, 'rtp_llm/cpp/cache/block_tree_cache/store/BlockTreeStorer.cc':{0,1}, 'rtp_llm/cpp/engine_base/stream/StreamCacheResource.cc':{0}}
for name in (root/'conflicts.txt').read_text().splitlines():
 p=root/name
 chunks=re.split(r'<<<<<<<[^\n]*\n(.*?)=======\n(.*?)>>>>>>>[^\n]*\n',p.read_text(),flags=re.S)
 s=chunks[0]
 for i in range(1,len(chunks),3):
  s+=chunks[i if (i-1)//3 in keep_ours.get(name,set()) else i+1]+chunks[i+2]
 p.write_text(s)
def span(text: str,start: str,end: str,replacement: str='')->str:
 a=text.index(start);b=text.index(end,a);return text[:a]+replacement+text[b:]
p=root/'rtp_llm/cpp/cache/block_tree_cache/BlockTree.cc';s=p.read_text();s=span(s,'int64_t steadyTimeUs()', 'size_t matchingTokenPrefix');s=span(s,'using Validators =', '}  // namespace');s=span(s,'size_t BlockTree::contentMatchPos','std::vector<TreeNode*> BlockTree::findNode');p.write_text(s)
p=root/'rtp_llm/cpp/cache/KVCacheManager.cc';s=p.read_text();s=span(s,'    tree_kv_cache_config.enable_prefix_cache_observability =','    block_tree_cache_ =');p.write_text(s)
for name in ['rtp_llm/cpp/cache/CoordinatorCacheManager.cc','rtp_llm/cpp/cache/CoordinatorCacheManager.h','rtp_llm/cpp/cache/block_tree_cache/load/BlockTreeLoader.h']:
 p=root/name;s=p.read_text();s=re.sub(r'^.*(?:match_observation|PrefixCacheMatchObservation).*\n','',s,flags=re.M);s=s.replace('cache_keys, valid_prefix, request_tokens, partial_tail','cache_keys, valid_prefix, partial_tail');p.write_text(s)
p=root/'rtp_llm/cpp/cache/CoordinatorCacheManager.cc';s=p.read_text();s=re.sub(r'\s*block_tree_cache_->observePublicationSkipped\([^;]+;','',s);s=re.sub(r',\s*insert_info.prefix_plan_state','',s);s=re.sub(r',\s*insert_info.observation_request_id','',s);s=s.replace('                                      &fork_segments,\n                                      nullptr,\n                                      &fork_ends,','                                      &fork_segments,\n                                      &fork_ends,');s=s.replace('        } else {\n        }','        }');p.write_text(s)
for name in ['rtp_llm/cpp/cache/block_tree_cache/BlockTreeCache.cc','rtp_llm/cpp/cache/block_tree_cache/BlockTreeCache.h','rtp_llm/cpp/cache/block_tree_cache/store/BlockTreeStorer.cc','rtp_llm/cpp/cache/block_tree_cache/store/BlockTreeStorer.h']:
 p=root/name;s=p.read_text();s=re.sub(r',\s*PrefixCachePlanState\*\s+prefix_plan_state(?: = nullptr)?','',s);s=re.sub(r',\s*std::optional<int64_t> observation_request_id(?: = std::nullopt)?','',s);s=re.sub(r',\s*prefix_plan_state','',s);s=re.sub(r',\s*observation_request_id','',s);s=re.sub(r'    void observePublicationSkipped\([^;]+;\n','',s);p.write_text(s)
p=root/'rtp_llm/cpp/cache/block_tree_cache/store/BlockTreeStorer.cc';s=p.read_text();s=span(s,'    const bool plan_reached','    const BlockTreeInsertResult insert_result');s=span(s,'    const auto unfulfilled','    const bool tree_data_mutated');p.write_text(s)
p=root/'rtp_llm/cpp/cache/block_tree_cache/load/BlockTreeLoader.cc';s=p.read_text();s=span(s,'PrefixCacheMatchObservation makeMatchObservation','BlockTreeMatchResult BlockTreeLoader::matchLocked');s=span(s,'    bool authenticated_scan = false;','    if (partial_tail != nullptr');s=s.replace('        authenticated_scan = true;\n        const int64_t match_begin_time_us = currentTimeUs();\n','');s=span(s,'        if (local && tree_->observabilityEnabled())','        if (local.has_value() && storage_backend_');p.write_text(s)
