import com.sun.source.tree.*;
import com.sun.source.util.*;
import javax.tools.*;
import java.nio.file.*;
import java.util.*;
public class SourceInventory {
  static String cell(Object o) { return String.valueOf(o).replace("\t", " ").replace("\n", " ").replace("\r", " "); }
  public static void main(String[] args) throws Exception {
    Path root = Path.of(args[0]).toAbsolutePath().normalize();
    var files = Files.readAllLines(Path.of(args[1])).stream().filter(s -> s.contains("/src/main/java/") && s.endsWith(".java")).map(root::resolve).map(Path::toFile).toList();
    var compiler = ToolProvider.getSystemJavaCompiler();
    try (var manager = compiler.getStandardFileManager(null, null, null)) {
      var task = (JavacTask) compiler.getTask(null, manager, null, List.of("-proc:none"), null, manager.getJavaFileObjectsFromFiles(files));
      var trees = Trees.instance(task);
      System.out.println("file\tline\towner\tkind\tname\tdeclaration");
      for (var unit : task.parse()) {
        String file = root.relativize(Path.of(unit.getSourceFile().toUri())).toString();
        new TreeScanner<Void, String>() {
          long line(Tree t) { return unit.getLineMap().getLineNumber(trees.getSourcePositions().getStartPosition(unit, t)); }
          void row(Tree t, String owner, String kind, String name, Object declaration) { System.out.printf("%s\t%d\t%s\t%s\t%s\t%s%n", file, line(t), cell(owner), kind, name, cell(declaration)); }
          public Void visitClass(ClassTree tree, String parent) {
            String name = tree.getSimpleName().toString();
            if (name.isEmpty()) name = "anonymous@" + line(tree);
            String owner = parent == null ? name : parent + "$" + name;
            row(tree, owner, tree.getKind().name(), name, tree.getModifiers() + " extends " + tree.getExtendsClause() + " implements " + tree.getImplementsClause());
            for (var member : tree.getMembers()) {
              if (member instanceof VariableTree field) row(field, owner, "FIELD", field.getName().toString(), field.getModifiers() + " " + field.getType());
              if (member instanceof MethodTree method) row(method, owner, "METHOD", method.getName().toString(), method.getModifiers() + " " + method.getReturnType() + " (" + method.getParameters() + ") throws " + method.getThrows());
              scan(member, owner);
            }
            return null;
          }
        }.scan(unit, null);
      }
    }
  }
}
