import org.objectweb.asm.*;
import java.nio.file.*;
import java.util.*;
public class BytecodeAudit {
  record Key(String owner,String name,String descriptor) {}
  static class Member { int access; String annotations=""; int mainReads, testReads, mainWrites, testWrites; Set<String> mainReaders=new TreeSet<>(), testReaders=new TreeSet<>(), mainWriters=new TreeSet<>(), testWriters=new TreeSet<>(); Member(int a){access=a;} }
  static Map<Key,Member> fields=new TreeMap<>(Comparator.comparing(Object::toString));
  static Map<Key,Member> methods=new TreeMap<>(Comparator.comparing(Object::toString));
  static List<Path> classes=new ArrayList<>();
  static Set<String> owners=new HashSet<>();
  static boolean tests;
  static String currentCaller;
  static Map<String,List<String>> parents=new HashMap<>();
  static boolean subtype(String child,String parent){if(child.equals(parent))return true;for(String p:parents.getOrDefault(child,List.of()))if(subtype(p,parent))return true;return false;}
  static Key resolve(Map<Key,Member> map,String o,String n,String d){Key key=new Key(o,n,d);if(map.containsKey(key))return key;for(String p:parents.getOrDefault(o,List.of())){Key k=resolve(map,p,n,d);if(k!=null)return k;}return null;}

  static void useMethod(String o,String n,String d){Key resolved=resolve(methods,o,n,d);Set<Key> used=new HashSet<>();if(resolved!=null)used.add(resolved);for(Key k:methods.keySet())if(k.name.equals(n)&&k.descriptor.equals(d)&&subtype(k.owner,o))used.add(k);for(Key k:used){Member m=methods.get(k);if(tests){m.testReads++;m.testReaders.add(currentCaller);}else{m.mainReads++;m.mainReaders.add(currentCaller);}}}
  static void useField(int op,String o,String n,String d){Key key=resolve(fields,o,n,d);Member m=key==null?null:fields.get(key); if(m!=null){boolean write=op==Opcodes.PUTFIELD||op==Opcodes.PUTSTATIC;if(tests){if(write){m.testWrites++;m.testWriters.add(currentCaller);}else{m.testReads++;m.testReaders.add(currentCaller);}}else{if(write){m.mainWrites++;m.mainWriters.add(currentCaller);}else{m.mainReads++;m.mainReaders.add(currentCaller);}}}}
  static void handle(Object value){if(value instanceof Handle h){if(h.getTag()<=4)useField(switch(h.getTag()){case 1->Opcodes.GETFIELD;case 2->Opcodes.GETSTATIC;case 3->Opcodes.PUTFIELD;default->Opcodes.PUTSTATIC;},h.getOwner(),h.getName(),h.getDesc());else useMethod(h.getOwner(),h.getName(),h.getDesc());}else if(value instanceof ConstantDynamic c){handle(c.getBootstrapMethod());for(int i=0;i<c.getBootstrapMethodArgumentCount();i++)handle(c.getBootstrapMethodArgument(i));}}
  public static void main(String[] args)throws Exception{
    Path root=Path.of(args[0]);
    for(String s:Files.readAllLines(Path.of(args[1]))) if(s.contains("/src/main/java/")&&s.endsWith(".java"))owners.add(s.substring(s.indexOf("/src/main/java/")+15,s.length()-5));
    try(var stream=Files.walk(root)){stream.filter(p->p.toString().endsWith(".class")&&(p.toString().contains("/target/classes/")||p.toString().contains("/target/test-classes/"))).forEach(classes::add);}
    for(Path p:classes){if(p.toString().contains("/test-classes/"))continue;new ClassReader(Files.readAllBytes(p)).accept(new ClassVisitor(Opcodes.ASM9){String owner;boolean included;
      public void visit(int v,int a,String n,String sig,String sup,String[] it){owner=n;var ps=new ArrayList<String>();if(sup!=null)ps.add(sup);ps.addAll(Arrays.asList(it));parents.put(n,ps);included=owners.contains(n.split("\\$",2)[0]);}
      public FieldVisitor visitField(int a,String n,String d,String sig,Object value){if(!included||(a&Opcodes.ACC_SYNTHETIC)!=0)return null;Member m=new Member(a);fields.put(new Key(owner,n,d),m);return new FieldVisitor(Opcodes.ASM9){public AnnotationVisitor visitAnnotation(String desc,boolean visible){m.annotations+=desc;return null;}};}
      public MethodVisitor visitMethod(int a,String n,String d,String sig,String[] ex){if(!included||(a&Opcodes.ACC_SYNTHETIC)!=0)return null;Member m=new Member(a);methods.put(new Key(owner,n,d),m);return new MethodVisitor(Opcodes.ASM9){public AnnotationVisitor visitAnnotation(String desc,boolean visible){m.annotations+=desc;return null;}};}
    },ClassReader.SKIP_CODE);}
    for(Path p:classes){tests=p.toString().contains("/test-classes/");var reader=new ClassReader(Files.readAllBytes(p));String owner=reader.getClassName();reader.accept(new ClassVisitor(Opcodes.ASM9){public MethodVisitor visitMethod(int a,String n,String d,String sig,String[] ex){currentCaller=owner+"."+n+d;return new MethodVisitor(Opcodes.ASM9){public void visitFieldInsn(int op,String o,String n,String d){useField(op,o,n,d);}public void visitMethodInsn(int op,String o,String n,String d,boolean it){useMethod(o,n,d);}public void visitInvokeDynamicInsn(String n,String d,Handle b,Object...a){handle(b);for(Object x:a)handle(x);}public void visitLdcInsn(Object value){handle(value);}};}},ClassReader.SKIP_DEBUG|ClassReader.SKIP_FRAMES);}
    System.out.println("kind\towner\tname\tdescriptor\taccess\tmain_reads\ttest_reads\tmain_writes\ttest_writes\tannotations\tmain_readers\ttest_readers\tmain_writers\ttest_writers");
    for(var collection:List.of(fields,methods))for(var e:collection.entrySet()){var k=e.getKey();var m=e.getValue();System.out.printf("%s\t%s\t%s\t%s\t%d\t%d\t%d\t%d\t%d\t%s\t%s\t%s\t%s\t%s%n",collection==fields?"field":"method",k.owner,k.name,k.descriptor,m.access,m.mainReads,m.testReads,m.mainWrites,m.testWrites,m.annotations,String.join(";",m.mainReaders),String.join(";",m.testReaders),String.join(";",m.mainWriters),String.join(";",m.testWriters));}
    System.err.printf("Scanned %d class files; %d tracked production types; %d fields; %d methods%n",classes.size(),owners.size(),fields.size(),methods.size());
  }
}
