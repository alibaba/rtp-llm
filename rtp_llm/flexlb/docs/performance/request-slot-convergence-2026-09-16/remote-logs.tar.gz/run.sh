#!/usr/bin/env bash
set -uo pipefail
run_dir=/data0/luoli.hn/work/rtp_llm_4/flexlb-request-slot-validation-20260916-181450
mkdir -p "$run_dir/logs"
exec > "$run_dir/runner.log" 2>&1
trap 'code=$?; printf "%s\n" "$code" > "$run_dir/runner.exit"' EXIT
export JAVA_HOME=/usr/lib/jvm/java-21
export PATH="$JAVA_HOME/bin:$PATH"
unset MAVEN_ARGS MAVEN_CONFIG JAVA_TOOL_OPTIONS JDK_JAVA_OPTIONS
export GIT_CONFIG_COUNT=1
export GIT_CONFIG_KEY_0=safe.directory
export GIT_CONFIG_VALUE_0="$run_dir/source/rtp_llm/flexlb"
ulimit -n 65535
cd "$run_dir/source" || exit 90
sha256sum -c "$run_dir/source.sha256" > "$run_dir/logs/source-before.log" || exit 91
{ date -Is; java -version; uname -a; nproc; cat /sys/fs/cgroup/cpu.max; uptime; } > "$run_dir/logs/environment.txt" 2>&1
ps -eo pid,comm,args | awk '$2 == "java" && /surefire|MavenCli|JavaMockEngineCluster|plexus.classworlds/ {print; found=1} END {exit found}' > "$run_dir/logs/java-before.txt" || exit 92
ss -ltn > "$run_dir/logs/listeners-before.txt"
cd rtp_llm/flexlb || exit 90
git init -q && git add . && git -c user.name='Validation Snapshot' -c user.email='validation@localhost' commit -qm 'Current workspace snapshot for remote validation' || exit 93
./mvnw -B -P 'opensource,!internal' -pl flexlb-sync -am test > "$run_dir/logs/unit-tests.log" 2>&1
unit_status=$?
printf '%s\n' "$unit_status" > "$run_dir/logs/unit-tests.exit"
mkdir -p "$run_dir/logs/unit-reports"
find . -path '*/target/surefire-reports/TEST-*.xml' -exec cp {} "$run_dir/logs/unit-reports/" \;
if [ "$unit_status" != 0 ]; then exit "$unit_status"; fi
export MAVEN_CONFIG='-Dflexlb.perf.engine-matrix-first-prefill-grpc-port=10001'
printf '%s\n' "$MAVEN_CONFIG" > "$run_dir/logs/perf-maven-args.txt"
bash tools/run_queue_performance.sh "$run_dir/logs/perf"
perf_status=$?
printf '%s\n' "$perf_status" > "$run_dir/logs/perf.exit"
cd "$run_dir/source"
sha256sum -c "$run_dir/source.sha256" > "$run_dir/logs/source-after.log" || exit 94
date -Is
uptime
exit "$perf_status"
