#!/usr/bin/env bash
set -uo pipefail
run_dir=/data0/luoli.hn/work/rtp_llm_4/flexlb-request-terminal-validation-20260914-2205
exec > "$run_dir/runner.log" 2>&1
export JAVA_HOME=/usr/lib/jvm/java-21
export PATH="$JAVA_HOME/bin:$PATH"
cd "$run_dir/source/flexlb" || exit 90
sha256sum -c "$run_dir/source.sha256" > "$run_dir/source-check.log" || exit 91
java -version
ulimit -n 65535
uptime
ps -eo pid,comm,args | awk '$2 == "java" && /surefire|MavenCli|JavaMockEngineCluster/ {print; found=1} END {exit found}' || exit 92
# An isolated Git repository makes the unchanged performance script record this exact source snapshot.
git init -q || exit 93
git add . || exit 93
git -c user.name='Validation Snapshot' -c user.email='validation@localhost' commit -qm 'Snapshot for remote request terminal validation' || exit 93
bash tools/run_queue_performance.sh "$run_dir/perf"
result=$?
printf '%s\n' "$result" > "$run_dir/perf.exit"
uptime
exit "$result"
